import { Router } from 'express';
import {
  TwilioAccessTokenController,
  CreateTokenTeacherController,
} from '../controllers';
import {
  ensureAuthenticatedMiddleware,
  expressValidatorMiddleware,
} from '../middlewares';
import twilioTokenMiddleware from '../middlewares/twilioTokenMiddleware';

const tokenRouter = Router();

tokenRouter.post(
  '/:classroom_id',
  (req, res, next) => {
    // Sanitizando o campo de CPF para validação
    // if (req.body.cpf) {
    //   req.body.cpf  = req.body.cpf.replace(/\./g,'');
    //   req.body.cpf  = req.body.cpf.replace(/\-/g,'');
    // }
    next();
  },
  twilioTokenMiddleware.storeRules,
  expressValidatorMiddleware.result,
  TwilioAccessTokenController.store,
);

tokenRouter.post(
  '/teacher/:classroom_id',
  ensureAuthenticatedMiddleware,
  expressValidatorMiddleware.result,
  CreateTokenTeacherController.store,
);

export default tokenRouter;
