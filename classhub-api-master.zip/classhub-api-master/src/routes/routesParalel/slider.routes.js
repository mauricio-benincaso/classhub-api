import { Router } from 'express';
import { SliderController } from '../controllers';

const sliderRouter = Router();

sliderRouter.get('/sequence/:sequenceId/frames', SliderController.show);

export default sliderRouter;
