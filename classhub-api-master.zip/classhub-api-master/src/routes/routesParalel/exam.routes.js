import { Router } from 'express';
import {
  ExamController,
  FrameController,
  SequenceController,
} from '../controllers';

const examRouter = Router();

examRouter.get('/', ExamController.index);
examRouter.get('/:examId/sequences', ExamController.show);
examRouter.get(
  '/:examId/sequences/:sequenceId/frames',
  SequenceController.show,
);
examRouter.get(
  '/:examId/sequences/:sequenceId/frames/:frameId',
  FrameController.show,
);

export default examRouter;
