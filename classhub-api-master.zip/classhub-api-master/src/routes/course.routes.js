import { Router } from 'express';
import { expressValidatorMiddleware, courseMiddleware } from '../middlewares';
import { CourseController } from '../controllers';
import { MulterHelper } from '../helpers';
import isAdministratorMiddleware from '../middlewares/isAdministratorMiddleware';

const courseRouter = Router();

const upload = MulterHelper.getUpload();

courseRouter.get(
  '/',
  expressValidatorMiddleware.result,
  CourseController.index,
);
courseRouter.get(
  '/:id',
  courseMiddleware.showRules,
  expressValidatorMiddleware.result,
  CourseController.show,
);
courseRouter.post(
  '/',
  upload.single('file'),
  isAdministratorMiddleware.check,
  courseMiddleware.storeRules,
  expressValidatorMiddleware.result,
  CourseController.store,
);
courseRouter.delete(
  '/:id',
  isAdministratorMiddleware.check,
  expressValidatorMiddleware.result,
  courseMiddleware.destroyRules,
  CourseController.destroy,
);
courseRouter.put(
  '/:id',
  upload.single('file'),
  isAdministratorMiddleware.check,
  courseMiddleware.updateRules,
  expressValidatorMiddleware.result,
  CourseController.update,
);

export default courseRouter;
