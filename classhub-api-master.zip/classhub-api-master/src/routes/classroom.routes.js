import { Router } from 'express';
import {
  expressValidatorMiddleware,
  classroomMiddleware,
  ensureAuthenticatedMiddleware,
  isTeacherMiddleware,
  copyClassroomMiddleware,
} from '../middlewares';
import {
  ClassroomController,
  ClassroomTwilioTokenController,
  CopyClassroomController,
  TransferClassroomController,
} from '../controllers';

const classroomRouter = Router();
// Create classroom
classroomRouter.post(
  '/',
  ensureAuthenticatedMiddleware,
  classroomMiddleware.storeRules,
  expressValidatorMiddleware.result,
  ClassroomController.store,
);
// Update Classroom
classroomRouter.put(
  '/:id',
  ensureAuthenticatedMiddleware,
  classroomMiddleware.updateRules,
  expressValidatorMiddleware.result,
  ClassroomController.update,
);

// Delete Classroom
classroomRouter.delete(
  '/:id',
  ensureAuthenticatedMiddleware,
  classroomMiddleware.destroyRules,
  expressValidatorMiddleware.result,
  ClassroomController.destroy,
);

// List Classrooms
classroomRouter.get(
  '/',
  ensureAuthenticatedMiddleware,
  ClassroomController.index,
);

// Show one Classroom
classroomRouter.get(
  '/:id',
  // TODO TEST THE TOKEN RECEIVED
  // ensureAuthenticatedMiddleware,
  // studentValidationMiddleware,
  classroomMiddleware.showRules,
  expressValidatorMiddleware.result,
  ClassroomController.show,
);

// Show one Classroom
classroomRouter.get(
  '/:id/token',
  isTeacherMiddleware.check,
  expressValidatorMiddleware.result,
  ClassroomController.show,
);

// Copy Classroom to another Course
classroomRouter.post(
  '/copy',
  ensureAuthenticatedMiddleware,
  isTeacherMiddleware.check,
  copyClassroomMiddleware.storeRules,
  expressValidatorMiddleware.result,
  CopyClassroomController.copy,
);

// Transfer Classroom to another Teacher or Course
classroomRouter.post(
  '/:id/transfer/:targetUserId',
  ensureAuthenticatedMiddleware,
  expressValidatorMiddleware.result,
  TransferClassroomController.transfer,
);

classroomRouter.get('/:id/twilio-token', ClassroomTwilioTokenController.index);

export default classroomRouter;
