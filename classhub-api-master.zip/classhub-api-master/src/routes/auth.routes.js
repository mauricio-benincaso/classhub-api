import { Router } from 'express';
import { auth } from 'firebase-admin';

import {
  AuthSessionController,
  AuthRequestRecoverCodeController,
  AuthVerifyRecoverCodeController,
  AuthResetPasswordController,
  AuthForgotPasswordController,
} from '../controllers';

import {
  authSessionMiddleware,
  expressValidatorMiddleware,
  authResetPasswordMiddleware,
  authVerifyRecoverCodeMiddleware,
  authRequestRecoverCodeMiddleware,
  authForgotPasswordMiddleware,
} from '../middlewares';

const authRouter = Router();

authRouter.post(
  '/session',
  authSessionMiddleware.storeRules,
  expressValidatorMiddleware.result,
  AuthSessionController.store,
);

authRouter.post(
  '/request-recover-code',
  authRequestRecoverCodeMiddleware.storeRules,
  expressValidatorMiddleware.result,
  AuthRequestRecoverCodeController.store,
);

authRouter.post(
  '/verify-recover-code',
  authVerifyRecoverCodeMiddleware.storeRules,
  expressValidatorMiddleware.result,
  AuthVerifyRecoverCodeController.store,
);

authRouter.post(
  '/forgot-password',
  authForgotPasswordMiddleware.storeRules,
  expressValidatorMiddleware.result,
  AuthForgotPasswordController.store,
);

authRouter.patch(
  '/reset-password',
  authResetPasswordMiddleware.storeRules,
  expressValidatorMiddleware.result,
  AuthResetPasswordController.update,
);

export default authRouter;
