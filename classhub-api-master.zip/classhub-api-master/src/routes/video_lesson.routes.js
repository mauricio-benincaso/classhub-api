import { Router } from 'express';
import { MulterHelper } from '../helpers';
import {
  videoLessonMiddleware,
  expressValidatorMiddleware,
} from '../middlewares';
import { VideoLessonController } from '../controllers';

const videoLessonRouter = Router();

const upload = MulterHelper.getUpload();

videoLessonRouter.post(
  '/',
  upload.single('file'),
  videoLessonMiddleware.storeRules,
  expressValidatorMiddleware.result,
  VideoLessonController.store,
);

videoLessonRouter.put(
  '/:id',
  upload.single('file'),
  videoLessonMiddleware.updateRules,
  expressValidatorMiddleware.result,
  VideoLessonController.update,
);

videoLessonRouter.delete(
  '/:id',
  videoLessonMiddleware.destroyRules,
  expressValidatorMiddleware.result,
  VideoLessonController.destroy,
);

videoLessonRouter.get(
  '/',
  expressValidatorMiddleware.result,
  VideoLessonController.index,
);

videoLessonRouter.get(
  '/:id',
  videoLessonMiddleware.showRules,
  expressValidatorMiddleware.result,
  VideoLessonController.show,
);

export default videoLessonRouter;
