import { Router } from 'express';
import { MulterHelper } from '../helpers';
import { sequenceMiddleware, expressValidatorMiddleware } from '../middlewares';
import { SequenceController } from '../controllers';

const sequenceRouter = Router();

const upload = MulterHelper.getUpload();

sequenceRouter.post(
  '/',
  upload.single('file'),
  sequenceMiddleware.storeRules,
  expressValidatorMiddleware.result,
  SequenceController.store,
);

sequenceRouter.delete(
  '/:id',
  sequenceMiddleware.destroyRules,
  expressValidatorMiddleware.result,
  SequenceController.destroy,
);

sequenceRouter.put(
  '/:id',
  sequenceMiddleware.updateRules,
  expressValidatorMiddleware.result,
  SequenceController.update,
);

export default sequenceRouter;
