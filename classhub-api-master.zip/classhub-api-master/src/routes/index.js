import { Router } from "express";
// import examRouter from "./exam.routes";
import fileRouter from "./file.routes";
// import sliderRouter from "./slider.routes";
import tokenRouter from "./token.routes";
import courseRouter from "./course.routes";
import authRouter from "./auth.routes";
import casoRouter from "./caso.routes";
import sequenceRouter from "./sequence.routes";
import videoLessonRouter from "./video_lesson.routes";
import ensureAuthenticatedMiddleware from "../middlewares/ensureAuthenticatedMiddleware";
import isTeacherMiddleware from "../middlewares/isTeacherMiddleware";
import classroomRouter from "./classroom.routes";
import taskRouter from "./task.routes";
import userRouter from "./user.routes";
import cors from "cors";
import isAdministratorMiddleware from "../middlewares/isAdministratorMiddleware";

const routes = Router();

routes.use(cors());

routes.get("/", (request, response) => {
  return response.json({
    Status: {
      Project: "ClassHub",
      Version: "1.0.3",
      Status: "Online",
    },
    Author1: {
      Author: "Augusto Vinicius",
      Github: "https://github.com/adoidadox2",
    },
    Author2: {
      Author: "Carlos Gabriel",
      Github: "https://github.com/carlossgabriel",
    },
    Author3: {
      Author: "Paulo Lima",
      Github: "https://github.com/prmlimajr",
    },
    Author4: {
      Author: "Farias",
      Github: "https://github.com/e-farias",
    },
    Author4: {
      Author: 'Farias',
      Github: 'https://github.com/e-farias',
    },
  });
});

routes.use("/auth", authRouter);
routes.use("/files", fileRouter);
// routes.use("/exams", examRouter);
// routes.use("/slider", sliderRouter);
routes.use("/token", tokenRouter);
routes.use(
  "/users",
  ensureAuthenticatedMiddleware,
  // isAdministratorMiddleware.check,
  userRouter,
);
routes.use("/courses", ensureAuthenticatedMiddleware, courseRouter);
routes.use("/classrooms", classroomRouter);
routes.use(
  "/casos",
  // ensureAuthenticatedMiddleware,
  // /casosisTeacherMiddleware.check,
  casoRouter,
);
routes.use(
  "/tasks",
  ensureAuthenticatedMiddleware,
  isTeacherMiddleware.check,
  taskRouter,
);
routes.use(
  "/sequences",
  ensureAuthenticatedMiddleware,
  isTeacherMiddleware.check,
  sequenceRouter,
);
routes.use(
  "/video_lessons",
  ensureAuthenticatedMiddleware,
  isTeacherMiddleware.check,
  videoLessonRouter,
);

export default routes;
