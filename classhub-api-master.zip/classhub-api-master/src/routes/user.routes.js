import { Router } from 'express';
import { MulterHelper } from '../helpers';
import {
  expressValidatorMiddleware,
  userMiddleware,
  isTeacherMiddleware,
  isAdministratorMiddleware,
  adminUpdateUserPasswordMiddleware,
} from '../middlewares';
import {
  UserController,
  AdminUpdateUserPasswordController,
} from '../controllers';

const userRouter = Router();

const upload = MulterHelper.getUpload();

userRouter.post(
  '/',
  upload.single('file'),
  isAdministratorMiddleware.check,
  UserController.store,
);

userRouter.get(
  '/',
  isAdministratorMiddleware.check,
  expressValidatorMiddleware.result,
  UserController.index,
);

userRouter.get('/:id', expressValidatorMiddleware.result, UserController.show);

userRouter.put(
  '/:id',
  upload.single('file'),
  userMiddleware.updateRules,
  expressValidatorMiddleware.result,
  UserController.update,
);

userRouter.delete(
  '/:id',
  isAdministratorMiddleware.check,
  userMiddleware.destroyRules,
  expressValidatorMiddleware.result,
  UserController.destroy,
);

// TODO TEST UPDATE PASSWORD
userRouter.patch(
  '/:id/password',
  adminUpdateUserPasswordMiddleware.updateRules,
  expressValidatorMiddleware.result,
  AdminUpdateUserPasswordController.update,
);
export default userRouter;
