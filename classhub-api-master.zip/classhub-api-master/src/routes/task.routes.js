import { Router } from 'express';

import { taskMiddleware, expressValidatorMiddleware } from '../middlewares';
import { TaskController } from '../controllers';

const taskRouter = Router();

taskRouter.get('/', expressValidatorMiddleware.result, TaskController.index);

taskRouter.get('/:id', expressValidatorMiddleware.result, TaskController.show);

taskRouter.post(
  '/',
  taskMiddleware.storeRules,
  expressValidatorMiddleware.result,
  TaskController.store,
);

taskRouter.delete(
  '/:id',
  taskMiddleware.destroyRules,
  expressValidatorMiddleware.result,
  TaskController.destroy,
);

taskRouter.put(
  '/:id',
  taskMiddleware.updateRules,
  expressValidatorMiddleware.result,
  TaskController.update,
);

export default taskRouter;
