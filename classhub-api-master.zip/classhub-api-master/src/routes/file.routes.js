import { Router } from 'express';
import { FileController } from '../controllers';
import { MulterHelper } from '../helpers';

const fileRouter = Router();

const upload = MulterHelper.getUpload();

fileRouter.get('/', FileController.create);
fileRouter.post('/', upload.single('file'), FileController.store);

export default fileRouter;
