import { Router } from 'express';
import { MulterHelper } from '../helpers';
import {
  casoMiddleware,
  ensureAuthenticatedMiddleware,
  expressValidatorMiddleware,
} from '../middlewares';
import { CasoController } from '../controllers';

const casoRouter = Router();

const upload = MulterHelper.getUpload();

casoRouter.get('/', expressValidatorMiddleware.result, CasoController.index);

casoRouter.get('/:id', expressValidatorMiddleware.result, CasoController.show);

casoRouter.post(
  '/',
  upload.array('files'),
  ensureAuthenticatedMiddleware,
  expressValidatorMiddleware.result,
  casoMiddleware.storeRules,
  CasoController.store,
);

casoRouter.delete(
  '/:id',
  ensureAuthenticatedMiddleware,
  expressValidatorMiddleware.result,
  casoMiddleware.destroyRules,
  CasoController.destroy,
);

casoRouter.put(
  '/:id',
  upload.array('files'),
  ensureAuthenticatedMiddleware,
  expressValidatorMiddleware.result,
  casoMiddleware.updateRules,
  CasoController.update,
);

/**
 * Método: POST
 * Descrição: Esta rota é destinada para o envio de medias para um caso;
 * Parâmetros:
 * [query param] id: id do caso que conterá as midias.
 * [form data] files: arquivos que serão enviados (somente os tipos permitidos serão enviados para o storage)
 * [form data] name: nome das midias. Se forem enviados mais que um arquivo, todos eles terão o mesmo nome.
 */
casoRouter.post(
  '/:id/medias',
  upload.fields([{ name: 'files' }, { name: 'name' }]),
  ensureAuthenticatedMiddleware,
  casoMiddleware.uploadMediaRules,
  expressValidatorMiddleware.result,
  CasoController.uploadMedia,
);

/**
 * Método: GET
 * Descrição: Esta rota é destinada à listagem das medias de um caso;
 * Parâmetros:
 * [query param] id: id do caso que contem as midias.
 * [query string] grouped_by: campo que será utilizado para agrupar as midias.
 */
casoRouter.get(
  '/:id/medias',
  expressValidatorMiddleware.result,
  CasoController.getMedias,
);

/**
 * Método: DELETE
 * Descrição: Esta rota é destinada à deleção de uma media de um caso;
 * Parâmetros:
 * [query param] id: id do caso que contem a midia.
 * [query string] id_media: Id da midia a ser apagada.
 */
casoRouter.delete(
  '/:id/media/:id_media',
  expressValidatorMiddleware.result,
  CasoController.deleteMedia,
);

/**
 * Método: POST
 * Descrição: Esta rota é destinada para o envio de DICOM`s para um caso;
 * Parâmetros:
 * [query param] id: id do caso que conterá os DICOM`s.
 * [form data] files: arquivos que serão enviados (DICOM`s através de .zip)
 */
casoRouter.post(
  '/:id/dicons',
  upload.fields([{ name: 'files' }]),
  ensureAuthenticatedMiddleware,
  casoMiddleware.uploadMediaRules,
  expressValidatorMiddleware.result,
  CasoController.uploadDicons,
);

export default casoRouter;
