// Get recursive files
export default function getRecursiveFiles(dir, ext) {
  let files = [];

  const readDir = (dir, ext) => {
    const filesInDir = fs.readdirSync(dir);
    filesInDir.forEach((file) => {
      const filePath = path.join(dir, file);
      if (fs.statSync(filePath).isDirectory()) {
        readDir(filePath, ext);
      } else {
        if (file.endsWith(ext)) {
          files.push(filePath);
        }
      }
    });
  };

  readDir(dir, ext);

  return files;
};
