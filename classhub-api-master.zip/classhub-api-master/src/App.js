import 'express-async-errors';
import express from 'express';
import path from 'path';

import routes from './routes';
import { AppError } from './errors';
import { FirebaseHelper } from './helpers';
import './databases';

class App {
  constructor() {
    this.server = express();

    this.middlewares();
    this.routes();
    this.errors();
    this.views();
    this.firebase();
    this.public();
  }

  middlewares() {
    this.server.use(express.json());
  }

  routes() {
    this.server.use(routes);
  }

  views() {
    this.server.set('view engine', 'ejs');
    this.server.set('views', path.join(__dirname, '/src'));
  }

  errors() {
    this.server.use((e, req, res, next) => {
      if (e instanceof AppError) {
        const result = {};

        if (e.message) {
          result.message = e.message;
        }

        if (e.data) {
          result.data = e.data;
        }

        return res.status(e.statusCode).json(result);
      }

      console.error(e);

      return res.status(500).json({ message: 'Internal server error' });
    });
  }

  firebase() {
    FirebaseHelper.initialize();
  }

  public() {
    const publicPath = path.join(__dirname, '/public');
    this.server.use(express.static(publicPath));
  }
}

export default new App().server;
