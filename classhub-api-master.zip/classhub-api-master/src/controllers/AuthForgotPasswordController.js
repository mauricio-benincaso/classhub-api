import { User, Token } from "../models";
import uuid from "uuid-v4";
import { sendEmailHelper } from "../helpers";
import path from "path";

class AuthForgotPasswordController {
  async store(request, response) {
    
    const {
      body: { email },
    } = request;
    
    let user;
    let link;
    let token;
    const clientURL = process.env.CLIENT_URL;

    // Check user account
    try {

      user = await User.findOne({
        where: {
          email,
        },
      });

      if (!user) {
        return response.status(404).json({
          message: "Usuário não encontrado",
        });
      }
      if (user.status == false) {
        return response.status(406).json({
          statusCode: 406,
          message: "Usuário inativo.",
        });
      }

    } catch (error) {
      console.log(`🚨 checkUserAccountError: \n${error}\n`);
      return response.status(500).json({
        message: "Erro ao verificar conta",
      });
    }

    // Generate user account recover link
    try {

      token = await Token.findOne({
        where: {
          user_id: user.id,
        },
      });

      if (token) {
        await token.destroy();
      }

      token = await Token.create({
        user_id: user.id,
        token_code: uuid(),
        createdAt: Date.now(),
        token_expires: Date.now() + 630000,
      });

      link = `${clientURL}/pages/auth/reset-password?token=${token.token_code}`;
      
    } catch (error) {
      console.log(`🚨 generateUserAccountRecoverLinkError: \n${error}\n`);
      return response.status(500).json({
        message: 'Erro ao criar link de recuperação.',
      });
    }

    // Send account recover email
    try {

      const emailSend = await sendEmailHelper(
        user.email,
        'Password Reset Request',
        {
          name: user.name,
          link: link,
          logo: `${process.env.SERVER_HOST}/img/classhub-logo.png`,
        },
        '../tools/template/requestResetPassword.handlebars',
      );

      if (emailSend.statusCode = 200) {
        return response.status(200).json({
          message: 'Email enviado'
        });
      } else {
        return response.status(500).json({
          message: emailSend.log,
        });
      }


    } catch (error) {
      console.log(`🚨 sendAccountRecoverEmailError: \n${error}\n`);
      return response.status(500).json({
        message: "Erro ao enviar email de recuperação.",
      });
    }

  }
  // Method to fire the emails with expiration time token
}

export default new AuthForgotPasswordController();
