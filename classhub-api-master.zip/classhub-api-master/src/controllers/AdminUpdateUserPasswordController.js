import { User } from '../models';
import { AppError } from '../errors';

class AdminUpdateUserPasswordController {
  async update(request, response) {
    const {
      params: { id },
      body: { password },
    } = request;

    let user;
    try {
      user = await User.findOne({ where: { id } });
    } catch (e) {
      throw new AppError(
        'Não foi encontrado nenhum registro com esse id.',
        e.toString(),
      );
    }
    try {
      await user.update({ password });
    } catch (e) {
      throw new AppError('Não foi possível atualizar a senha');
    }

    return response
      .json({
        message: 'Senha atualizada com sucesso.',
      })
      .status(200);
  }
}

export default new AdminUpdateUserPasswordController();
