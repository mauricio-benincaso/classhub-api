import { User } from '../models';
import { AppError } from '../errors';
import { JwtHelper } from '../helpers';

class AuthSessionController {
  async store(request, response) {
    const { email, password } = request.body;

    const user = await User.findOne({
      where: { email },
      attributes: [
        'name',
        'email',
        'id',
        'role_id',
        'password',
        'status',
        'profile_picture',
      ],
    });

    if (!user) {
      // throw new AppError('Verifique os dados informados e tente novamente');

      return response.status(400).json({
        errorUser: true,
        message: 'O email inserido não corresponde a nenhuma conta',
      });
    }

    if (!user.validatePassword(password)) {

      return response.status(400).json({
        errorPassword: true,
        message: 'Senha incorreta',
      });
    }

    if (user.status == false) {
      return response.status(401).json({
        message: 'Usuário inativo.',
      });
    }

    return response
      .json({
        message: 'Sessão criada com sucesso',
        data: {
          user: {
            name: user.name,
            email: user.email,
            role_id: user.role_id,
            profile_picture: user.profile_picture,
            id: user.id,
          },
          token: JwtHelper.sign({
            id: user.id,
            roleId: user.role_id,
          }),
        },
      })
      .status(200);
  }
}

export default new AuthSessionController();
