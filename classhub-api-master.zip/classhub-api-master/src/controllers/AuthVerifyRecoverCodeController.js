import { User } from '../models';
import { AppError } from '../errors';
import { TwilioHelper } from '../helpers';

class AuthVerifyRecoverCodeController {
  async store(request, response) {
    let check;

    const { email, code } = request.body;

    const user = await User.findOne({ where: { email } });

    if (!user) {
      throw new AppError('Verifique o código informado e tente novamente');
    }

    if (user.status == false) {
      throw new AppError(
        'O usuário desativado não pode solicitar uma nova senha',
        null,
        401,
      );
    }

    try {
      check = await TwilioHelper.checkCode(user.email, code);
    } catch (e) {
      throw new AppError('Verifique o código informado e tente novamente');
    }

    if (check.status !== 'approved') {
      throw new AppError('Verifique o código informado e tente novamente');
    }

    return response.json({
      message: 'Código verificado com sucesso',
      verified: true,
    });
  }
}

export default new AuthVerifyRecoverCodeController();
