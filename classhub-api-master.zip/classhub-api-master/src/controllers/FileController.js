/* eslint-disable no-unused-vars */
/* eslint-disable no-await-in-loop */
import decompress from 'decompress';
import path from 'path';
import { Promise } from 'bluebird';
import fs from 'fs';
import { AppError } from '../errors';
import { DicomParserHelper, FirebaseHelper } from '../helpers';
import ConvertToJpeg from '../tools/ConvertToJpeg';
import { Sequence, Frame } from '../models';

class FileController {
  create(request, response) {
    return response.render('../views/upload');
  }

  async store(request, response) {
    const { file } = request;

    // return response.json({ });
    const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
    let pathArray;
    let createdFrame;
    let sequenceFrameMatrix;
    let transaction;
    let descompactedFiles;
    let createdSequence;
    let foundSequence;

    // Descompact files and return the files names, the order of the frame on its sequence
    try {
      descompactedFiles = await decompress(
        path.resolve(__dirname, '..', 'tmp', file.originalname),
        'input_data',
      );

      pathArray = descompactedFiles
        .filter(descompactedFile => {
          return descompactedFile.type !== 'directory';
        })
        .map(descompactedFile => {
          return descompactedFile.path;
        });

      sequenceFrameMatrix = pathArray.map(singlePath => {
        const [folder, dcmFile] = singlePath.split('/');
        const [x, sequel, frame] = dcmFile.split('-');
        const frameName = frame.replace('.dcm', '');
        const fileToJpeg = dcmFile.replace('.dcm', '.jpg');

        return [sequel, frameName, fileToJpeg, dcmFile];
      });
    } catch (e) {
      console.log(e);
      throw new AppError('Não foi possível descompactar os DICONS');
    }

    if (!pathArray.length) {
      throw new AppError('Nenhum arquivo foi encontrado');
    }

    const [folder, x] = pathArray[0].split('/');

    // Convert the batch of files into JPG by calling the python function
    for (const singlePath of pathArray) {
      await ConvertToJpeg.execute(singlePath);
    }

    try {
      transaction = await Frame.sequelize.transaction();

      createdFrame = await Frame.create({ name: folder }, { transaction });
    } catch (e) {
      if (transaction) await transaction.rollback();
      throw new AppError(`Não foi possivel salvar o frame  ${e.toString()}`);
    }

    for (const [sequel, frame, fileToJpeg, dcmFile] of sequenceFrameMatrix) {
      let url;

      try {
        [foundSequence, createdSequence] = await Sequence.findOrCreate({
          where: {
            name: sequel,
            frame_id: createdFrame.id,
          },
          defaults: {
            name: sequel,
            frame_id: createdFrame.id,
          },
          transaction,
        });
      } catch (e) {
        console.log(e);
        if (transaction) await transaction.rollback();
        throw new AppError(
          `Não foi possivel criar a sequencia de frames ${e.toString()}`,
        );
      }

      try {
        url = await FirebaseHelper.uploadFile(
          path.resolve(
            __dirname,
            '..',
            '..',
            'output_data',
            folder,
            fileToJpeg,
          ),
          `frames/${createdFrame.id}/${foundSequence.id}`,
          frame,
        );
      } catch (e) {
        console.log(e);
        throw new AppError(`Não foi possivel criar o frame  ${e.toString()}`);
      }

      try {
        await Frame.create(
          {
            name: frame,
            sequence_id: foundSequence.id,
            src: url,
            data: DicomParserHelper.magicMaker(
              path.resolve(
                __dirname,
                '..',
                '..',
                'input_data',
                folder,
                dcmFile,
              ),
            ),
          },
          { transaction },
        );
      } catch (e) {
        console.log(e);
        if (transaction) await transaction.rollback();
        throw new AppError(`Não foi possivel criar o frame  ${e.toString()}`);
      }
    }

    await transaction.commit();

    return response.redirect('/frames');
  }
}

export default new FileController();
