import { Promise } from 'bluebird';
import path from 'path';
import { Op } from 'sequelize';
import uuid from 'uuid-v4';
import { User, UserCourse, Course, Role, Classroom } from '../models';
import { AppError } from '../errors';
import { PaginateHelper, FirebaseHelper, BcryptHelper } from '../helpers';

class UserController {
  async store(request, response) {
    const {
      body: { name, email, password, role_id, status, course_ids, master },
      sequelize,
    } = request;

    let transaction;
    let createdUser;
    let createdUserRole;

    if (await User.findOne({ where: { email } })) {
      throw new AppError(
        'Email já está em uso, faça login para acessar o sistema',
      );
    }

    try {
      transaction = await User.sequelize.transaction();
    } catch (e) {
      if (transaction) await transaction.rollback();
      throw new AppError('Não foi possível inicializar a transaction.');
    }

    try {
      createdUser = await User.create(
        {
          name,
          email,
          password,
          role_id,
          status,
          master,
        },
        { transaction },
      );
    } catch (e) {
      if (transaction) await transaction.rollback();

      throw new AppError(
        'Não foi possível criar este usuário. Verifique os dados informados e tente novamente.',
        e.toString(),
      );
    }

    // Gets the Role from the createdUser
    try {
      createdUserRole = await Role.findOne({
        where: { id: createdUser.role_id },
        attributes: ['label'],
        transaction,
      });
    } catch (e) {
      throw new AppError(
        'Erro ao verificar o tipo de usuário criado.',
        e.toString(),
      );
    }

    // Link the user to their courses if its a teacher
    if (createdUserRole.label == 'Professor') {
      // find all courses and link them to the user master
      if (createdUser.master === true) {
        const courses = await Course.findAll({
          where: { deleted_at: null },
          transaction,
        });

        await Promise.map(courses, async course => {
          await UserCourse.create(
            {
              user_id: createdUser.id,
              course_id: course.id,
            },
            { transaction },
          );
        });

        await transaction.commit();

        return response.json({
          message: 'Usuário criado com sucesso',
          data: {
            name: createdUser.name,
            email: createdUser.email,
            role_id,
            status: createdUser.status,
          },
          course_ids,
        });
      }

      try {
        await Promise.map(course_ids, async course_id => {
          let createdUserCourse;

          try {
            createdUserCourse = await UserCourse.create(
              {
                id: uuid(),
                user_id: createdUser.id,
                course_id,
              },
              { transaction, fields: ['id', 'user_id', 'course_id'] },
            );
          } catch (e) {
            throw new AppError(
              'Não foi possível atrelar este usuário aos cursos informados. Confira os dados e tente novamente',
              e.toString(),
            );
          }
          return createdUserCourse;
        });
      } catch (e) {
        if (transaction) await transaction.rollback();
        throw new AppError(
          'Não foi possível atrelar este usuário no curso. Verifique o array de cursos e tente novamente',
          e.toString(),
        );
      }
    }

    await transaction.commit();

    return response.json({
      message: 'Usuário criado com sucesso',
      data: {
        name: createdUser.name,
        email: createdUser.email,
        role_id,
        status: createdUser.status,
      },
      course_ids,
    });
  }

  async index(request, response) {
    const {
      query: { page, pageSize, search, role_id },
    } = request;

    let users;
    let total_pages;

    const { offset, limit } = PaginateHelper.paginate(page, pageSize);

    if (!search) {
      try {
        users = await User.findAndCountAll({
          offset,
          limit,
          attributes: [
            'id',
            'name',
            'email',
            'role_id',
            'status',
            'profile_picture',
          ],
          include: [
            {
              model: Course,
              as: 'courses',
              attributes: ['id', 'title'],
              through: {
                where: { deleted_at: null },
              },
            },
          ],
        });
      } catch (e) {
        throw new AppError(
          'Não foi possível listar os usuários ',
          e.toString(),
        );
      }
    } else {
      try {
        users = await User.findAndCountAll({
          where: {
            name: { [Op.iLike]: `%${search}%` },
          },
          offset,
          limit,
          attributes: [
            'id',
            'name',
            'email',
            'role_id',
            'status',
            'profile_picture',
          ],
          include: [
            {
              model: Course,
              as: 'courses',
              attributes: ['id', 'title'],
              through: {
                where: { deleted_at: null },
              },
            },
          ],
        });
      } catch (e) {
        throw new AppError(
          'Não foi possível listar os usuários ',
          e.toString(),
        );
      }
    }

    if (role_id) {
      try {
        users = await User.findAndCountAll({
          where: {
            role_id,
          },
          offset,
          limit,
          attributes: ['id', 'name', 'email', 'role_id', 'status'],
          include: [
            {
              model: Course,
              where: { deleted_at: null },
              as: 'courses',
              attributes: ['id', 'title'],
              through: {
                where: { deleted_at: null },
              },
            },
          ],
        });
      } catch (e) {
        throw new AppError(
          'Não foi possível listar os usuários ',
          e.toString(),
        );
      }
    }

    if (search && role_id) {
      try {
        users = await User.findAndCountAll({
          where: {
            name: { [Op.iLike]: `%${search}%` },
            role_id,
          },
          offset,
          limit,
          attributes: ['id', 'name', 'email', 'role_id', 'status'],
          include: [
            {
              model: Course,
              as: 'courses',
              attributes: ['id', 'title'],
              through: {
                where: { deleted_at: null },
              },
            },
          ],
        });
      } catch (e) {
        throw new AppError(
          'Não foi possível listar os usuários ',
          e.toString(),
        );
      }
    }

    if (!users) {
      throw new AppError('Nenhum usuário encontrado');
    }

    total_pages = PaginateHelper.getTotalPages(users.count, pageSize);

    return response.json({
      message: 'Usuários listados com sucesso',
      data: users,
      users_total: users.count,
      current_page: page,
      total_pages,
    });
  }

  async show(request, response) {
    const {
      params: { id },
    } = request;

    const user = await User.findOne({
      where: { id },
      attributes: ['name', 'email', 'profile_picture', 'role_id'],
    });

    const userCourses = await UserCourse.findAll({
      where: { user_id: id },
      attributes: ['course_id'],
    });

    const listOfIds = userCourses.map(singleCourse => singleCourse.course_id);

    const courses = await Course.findAll({
      where: { id: listOfIds },
      attributes: ['title'],
    });

    if (!user) {
      throw new AppError('Usuário não encontrado');
    }

    return response.json({
      message: 'Usuário encontrado',
      data: user,
      courses,
    });
  }

  async update(request, response) {
    const {
      params: { id },
      body: {
        name,
        email,
        status,
        role_id,
        password,
        course_ids,
        password_confirmation,
      },
      file,
      sequelize,
    } = request;

    const passwordValidation = new RegExp(
      '^(((?=.*[a-z])(?=.*[A-Z]))|((?=.*[a-z])(?=.*[0-9]))|((?=.*[A-Z])(?=.*[0-9])))(?=.{8,})',
    );

    let user;
    let uploadFile;
    let transaction;
    let listOfCoursesToUpdate;

    // Initialize the transaction
    try {
      transaction = await User.sequelize.transaction();
    } catch (e) {
      console.log(e);
      throw new AppError('Não foi possível iniciar a transação');
    }

    // Professor
    if (
      sequelize.user.roles.label === 'Professor' &&
      id === sequelize.user.id
    ) {
      let encryptedPassword;
      let validPassword;
      let updatedUser;

      // Find the user
      try {
        user = await User.findOne({
          where: { id, master: false },
          attributes: ['name', 'email', 'status', 'profile_picture', 'role_id'],
          transaction,
          raw: true,
        });
      } catch (e) {
        throw new AppError(
          'Usuário não encontrado ou não pode ser editado',
          e.toString(),
        );
      }

      // Check if the password is valid
      if (password) {
        validPassword = passwordValidation.test(password);
        if (
          validPassword &&
          password_confirmation &&
          password === password_confirmation
        ) {
          try {
            encryptedPassword = BcryptHelper.hash(password);
          } catch (e) {
            throw new AppError(
              'Não foi possível atualizar os dados do usuário',
              e.toString(),
            );
          }
        } else {
          if (transaction) await transaction.rollback();

          throw new AppError('Não foi possível atualizar os dados do usuário');
        }
      }

      // Profile Picture upload
      if (file) {
        const uploadFileName = path.basename(file.path);
        try {
          uploadFile = await FirebaseHelper.uploadFile(
            path.resolve(__dirname, '..', 'tmp', uploadFileName),
            `profilePicture/${user.email}`,
            uploadFileName,
          );
        } catch (e) {
          throw new AppError(
            'Não foi posssível realizar o upload da foto de perfil.',
            e.toString(),
          );
        }
      }

      const dataToUpdate = {
        name: name || user.name,
        email: email || user.email,
        password: encryptedPassword || user.password,
        profile_picture: uploadFile || user.profile_picture,
      };

      // Update User
      try {
        const aux = await User.update(dataToUpdate, {
          where: { id, master: false },
          attributes: [
            'name',
            'email',
            'role_id',
            'id',
            'status',
            'profile_picture',
          ],
          returning: true,
          transaction,
          raw: true,
        });

        updatedUser = aux.pop().shift();
      } catch (e) {
        if (transaction) await transaction.rollback();

        throw new AppError('Não foi possível atualizar o usuário');
      }

      try {
        await transaction.commit();

        return response.json({
          message: 'Usuário atualizado com sucesso',
          data: {
            name: updatedUser.name,
            email: updatedUser.email,
            id: updatedUser.id,
            role_id: updatedUser.role_id,
            profile_picture: updatedUser.profile_picture,
          },
        });
      } catch (e) {
        if (transaction) await transaction.rollback();

        throw new AppError('Falha ao atualizar o usuário', e.toString());
      }

      // Administrador
    } else if (sequelize.user.roles.label === 'Administrador') {
      let validPassword;
      let encryptedPassword;

      // Find the user
      try {
        user = await User.findOne({
          where: { id, master: false },
          attributes: ['name', 'email', 'status', 'profile_picture', 'role_id'],
          raw: true,
          transaction,
        });
      } catch (e) {
        if (transaction) await transaction.rollback();

        throw new AppError('Usuário não encontrado.', e.toString());
      }

      // Check if the password is valid
      if (password) {
        validPassword = passwordValidation.test(password);
        if (
          validPassword &&
          password_confirmation &&
          password === password_confirmation
        ) {
          try {
            encryptedPassword = BcryptHelper.hash(password);
          } catch (e) {
            throw new AppError(
              'Não foi possível atualizar os dados do usuário',
              e.toString(),
            );
          }
        } else {
          if (transaction) await transaction.rollback();

          throw new AppError('Não foi possível atualizar os dados do usuário');
        }
      }

      // Upload Profile Picture
      if (file) {
        const uploadFileName = path.basename(file.path);
        try {
          uploadFile = await FirebaseHelper.uploadFile(
            path.resolve(__dirname, '..', 'tmp', uploadFileName),
            `profilePicture/${user.email}`,
            uploadFileName,
          );
        } catch (e) {
          throw new AppError(
            'Não foi posssível realizar o upload da foto de perfil.',
            e.toString(),
          );
        }
      }

      const dataToUpdate = {
        name: name || user.name,
        email: email || user.email,
        status: status || user.status,
        role_id: role_id || user.role_id,
        password: encryptedPassword || user.password,
        profile_picture: uploadFile || user.profile_picture,
      };

      let updatedUser;

      try {
        const aux = await User.update(dataToUpdate, {
          where: { id, master: false },
          attributes: [
            'name',
            'email',
            'status',
            'role_id',
            'password',
            'profile_picture',
            'id',
          ],
          returning: true,
          transaction,
        });

        updatedUser = aux.pop().shift();
      } catch (e) {
        if (transaction) await transaction.rollback();
        throw new AppError('Não foi possível atualizar o usuário');
      }

      // Update the userCourse list
      if (course_ids) {
        let toBeCreated;
        if (typeof course_ids === 'string') {
          const course_idsArray = [course_ids];
          toBeCreated = course_idsArray;
        } else {
          toBeCreated = [...course_ids];
        }

        try {
          listOfCoursesToUpdate = await UserCourse.findAll({
            where: { user_id: updatedUser.id },
            attributes: ['course_id'],
            transaction,
            raw: true,
          });
        } catch (e) {
          if (transaction) await transaction.rollback();
          throw new AppError('Não foi possível atualizar os cursos do usuário');
        }
        const listOfIds = listOfCoursesToUpdate.map(
          singleUser => singleUser.course_id,
        );

        let toBeDeleted = [];

        listOfIds.map(id => {
          if (course_ids.includes(id)) {
            toBeDeleted.push(id);
            toBeCreated = toBeCreated.filter(createId => createId !== id);
          }
        });

        try {
          if (toBeDeleted.length > 0) {
            await UserCourse.destroy({
              where: {
                course_id: {
                  [Op.in]: toBeDeleted,
                },
                user_id: id,
              },
              transaction,
            });
          }
        } catch (e) {
          if (transaction) await transaction.rollback();
          throw new AppError('Não foi possível atualizar os cursos do usuário');
        }

        try {
          if (toBeCreated.length > 0) {
            await Promise.map(toBeCreated, async c_id => {
              await UserCourse.create(
                {
                  user_id: id,
                  course_id: c_id,
                },
                { transaction },
              );
            });
          }
        } catch (error) {
          if (transaction) await transaction.rollback();
          throw new AppError('Não foi possível atualizar os cursos do usuário');
        }
      }

      try {
        await transaction.commit();

        return response.json({
          message: 'Usuário atualizado com sucesso',
          data: {
            name: updatedUser.name,
            email: updatedUser.email,
            id: updatedUser.id,
            role_id: updatedUser.roleId,
            profile_picture: updatedUser.profile_picture,
          },
        });
      } catch (e) {
        if (transaction) await transaction.rollback();

        throw new AppError('Falha ao atualizar o usuário', e.toString());
      }

      // Professor tentando acessar outro usuário
    } else {
      throw new AppError('Usuário não encontrado.');
    }
  }

  async destroy(request, response) {
    const {
      params: { id },
    } = request;

    const userFound = await User.findOne({
      where: { id },
      include: [
        {
          model: Course,
          as: 'courses',
          include: [
            {
              model: Classroom,
              as: 'classrooms',
              attributes: ['id', 'title'],
            },
          ],
        },
        {
          model: Role,
          as: 'roles',
          attributes: ['id', 'label'],
        },
        {
          model: Classroom,
          attributes: ['id', 'title'],
        },
      ],
    });

    if (userFound.master === true) {
      throw new AppError('Não é possível deletar o usuário do tipo master.');
    }

    // Transfer classrooms to the master Teacher when deleting a teacher
    if (userFound && userFound.roles.label === 'Professor') {
      // transfer classrooms to the master Teacher
      if (userFound.classrooms.length > 0) {
        let masterTeacher;
        try {
          masterTeacher = await User.findOne({
            where: {
              master: true,
            },
          });
        } catch (e) {
          console.log(e);
          throw new AppError(
            'Não foi encontrado nenhum usuário do tipo Master para transferir as aulas',
          );
        }

        try {
          const { classrooms } = userFound;

          await Promise.map(classrooms, async classroom => {
            classroom.update({ user_id: masterTeacher.id });
          });
        } catch (e) {
          console.log(e);
          throw new AppError(
            'Não foi possível transferir as aulas do professor',
          );
        }
      }

      try {
        // destroy the teacher
        await UserCourse.destroy({
          where: {
            user_id: userFound.id,
          },
        });
        await User.destroy({ where: { id } });
      } catch (e) {
        throw new AppError('Não foi possível deletar o usuário.', e.toString());
      }
      return response.json({ message: 'Usuário deletado' });
    } else if (userFound.roles.label === 'Administrador') {
      try {
        await User.destroy({ where: { id } });
      } catch (e) {
        throw new AppError('Não foi possível deletar o usuário.', e.toString());
      }
      return response.json({ message: 'Usuário deletado' });
    }
  }
}

export default new UserController();
