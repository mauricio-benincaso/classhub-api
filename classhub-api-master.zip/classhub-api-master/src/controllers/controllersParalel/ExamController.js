import { Exam, Sequence } from '../models';
import { AppError } from '../errors';

class ExamController {
  async index(request, response) {
    let exams;

    try {
      exams = await Exam.findAll({ attributes: ['id', 'name', 'created_at'] });
    } catch (e) {
      console.log(e);
      throw new AppError('Não foi possível listar os exames');
    }

    if (!exams.length) {
      throw new AppError('Nenhum exame encontrada');
    }

    return response.render('../views/examsIndex', { exams });
  }

  async show(request, response) {
    const { examId } = request.params;
    let exam;

    try {
      exam = await Exam.findOne({
        where: { id: examId },
        attributes: ['id', 'name'],
        include: [
          {
            model: Sequence,
            attributes: ['id', 'name', 'created_at'],
          },
        ],
      });
    } catch (e) {
      throw new AppError('Não foi possível mostrar o exame selecionado');
    }

    if (!exam) {
      throw new AppError('O exame não foi encontrado');
    }

    return response.render('../views/sequencesIndex', {
      exam: { id: exam.id, name: exam.name },
      sequences: exam.sequences,
});
  }
}

export default new ExamController();
