import { Frame } from '../models';
import { AppError } from '../errors';

class SliderController {
  async show(request, response) {
    const { sequenceId } = request.params;
    let frames;

    try {
      frames = await Frame.findAll({
        where: { sequence_id: sequenceId },
        attributes: ['id', 'name', 'src'],
      });
    } catch (e) {
      console.log(e);
      throw new AppError('Não foi possível mostrar os frames selecionados');
    }

    if (!frames.length) {
      throw new AppError('Os frames não foram encontrados');
    }

    return response.json({
      message: 'Frames capturados com sucesso',
      data: frames,
    });
  }
}
export default new SliderController();
