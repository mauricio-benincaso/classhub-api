import { User } from '../models';
import { AppError } from '../errors';
import { TwilioHelper } from '../helpers';

class AuthRequestRecoverCodeController {
  async store(request, response) {
    const verifications = {
      email: false,
    };

    const { email } = request.body;

    const user = await User.findOne({ where: { email } });

    if (!user) {
      throw new AppError('Usuário não encontrado, tente novamente');
    }

    if (user.status == false) {
      return response.status(400).json({
        message: 'Usuário inativo.',
      });
    }

    try {
      await TwilioHelper.requestCode(user.email, {
        substitutions: {
          name: user.name,
        },
      });

      verifications.email = true;
    } catch (e) {
      verifications.email = false;
    }

    if (verifications.email) {
      return response.json({
        message: 'Código de verificação enviado com sucesso.',
        data: {
          user: {
            id: user.id,
            name: user.name,
            email: user.email,
          },
          verifications,
        },
      });
    }

    throw new AppError(
      'Não foi possível solicitar seu código de verificação.',
      null,
      500,
    );
  }
}

export default new AuthRequestRecoverCodeController();
