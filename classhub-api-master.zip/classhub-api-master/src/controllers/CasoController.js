import decompress from 'decompress';
import fs, { createReadStream } from 'fs';
// import { v4 as uuidv4 } from 'uuid';
// import ConvertToJpeg from '../tools/ConvertToJpeg';
import { Op, Sequelize } from 'sequelize';
import path from 'path';
// import { Promise } from 'bluebird';
import mimetypes from 'mime-types';
// import extract from 'extract-zip';
import FormData from 'form-data';
// import { createReadStream } from 'fs';
import axios from 'axios';
import { Promise, Promise as PromiseBluebird } from 'bluebird';
import fsExtra from 'fs-extra';
import dicomParser from 'dicom-parser';
// import { promiseImpl } from 'ejs';
// import { forEach } from 'lodash';
import JSZip from 'jszip';
import { Caso, Frame, Media, Sequence, Task } from '../models';
import { PaginateHelper, FirebaseHelper, DicomHelper } from '../helpers';
import { AppError } from '../errors';

class CasoController {
  async index(request, response) {
    const {
      query: { page, pageSize, search, classroom_id },
    } = request;
    const { offset, limit } = PaginateHelper.paginate(page, pageSize);

    let casos;
    let total_pages;
    let medias;

    if (!classroom_id) {
      throw new AppError('Informe o id da Aula!');
    }

    if (!search) {
      try {
        casos = await Caso.findAndCountAll({
          where: { classroom_id },
          attributes: [
            'id',
            'name',
            'description',
            'classroom_id',
            'created_at',
          ],
          // order: [['created_at', 'DESC']],
          offset,
          limit,
          // include: [
          //   {
          //     model: Media,
          //     attributes: ['id', 'url', 'thumbnail', 'media_type_id'],
          //   },
          //   {
          //     model: Task,
          //     attributes: ['name', 'description', 'objective', 'order'],
          //   },
          // ],
        });
      } catch (e) {
        throw new AppError(
          'Não foi possível listar os casos do banco de dados',
          e.toString(),
        );
      }
    } else {
      try {
        casos = await Caso.findAndCountAll({
          where: {
            name: { [Op.iLike]: `%${search}%` },
            classroom_id,
          },
          // attributes: ['id', 'name', 'description', 'user_id'],
          // attributes: ['id', 'name', 'description', 'user_id', 'classroom_id'],
        });
      } catch (e) {
        throw new AppError(
          'Não foi possível buscar os casos do banco de dados',
        );
      }
    }

    if (!casos) {
      throw new AppError('Nenhum caso encontrado');
    }

    total_pages = PaginateHelper.getTotalPages(casos.count, pageSize);

    return response.json({
      message: 'Casos listados com sucesso',
      casos: casos.rows,
      casos_total: casos.count,
      current_page: page,
      total_pages,
    });
  }

  async show(request, response) {
    const { id } = request.params;
    let caso;

    try {
      caso = await Caso.findOne({
        where: { id },
        attributes: ['id', 'name', 'description', 'classroom_id'],
        include: [
          {
            model: Media,
            attributes: [
              'id',
              'url',
              'thumbnail',
              'media_type_id',
              'caso_id',
              'name',
            ],
          },
          {
            model: Task,
            attributes: [
              'id',
              'name',
              'description',
              'objective',
              'order',
              'caso_id',
            ],
          },
          {
            model: Sequence,
            attributes: [
              'id',
              'name',
              'order',
              'caso_id',
              'ohif_server_response',
              'ohif_parent_study_id',
            ],
            include: [
              {
                model: Frame,
                attributes: ['id', 'order', 'data', 'uri'],
              },
            ],
          },
        ],
      });
    } catch (e) {
      throw new AppError(
        'Não foi possível mostrar o caso selecionado.',
        e.toString(),
      );
    }

    if (!caso) {
      throw new AppError('O Caso não foi encontrado.');
    }

    return response.json({
      message: 'Caso listado: ',
      data: {
        caso,
      },
    });
  }

  async store(request, response) {

    const {
      body: { name, description, classroom_id, tasks, sequences },
      files,
    } = request;

    const messages = {
      success: 'Caso criado com sucesso.',
      error: {
        creatingCaso:
          'Não foi possível criar o Caso. Verifique os dados e tente novamente.',
        creatingMedia:
          'Não foi possível adicionar as Mídias no banco. Verifique os dados e tente novamente.',
      },
      alreadyExists:
        'Já existe um Caso com este nome nesta aula, verifique os dados e tente novamente.',
      uploadError:
        'Não foi possível realizar o upload da mídia, verifique os dados e tente novamente.',
    };

    let medias = [];
    let fileArray = !!files ? files : [];
    let createdCaso;
    let filesUploadUrl;
    let transaction;
    let descompactedFiles;
    let sequencesCreated = [];
    let pathArray = [];

    // Find Caso by name to know if it exists
    if (await Caso.findOne({ where: { name, classroom_id } })) {
      throw new AppError(messages.alreadyExists);
    }

    // Initialize the transaction
    try {
      transaction = await Caso.sequelize.transaction();
    } catch (e) {
      throw new AppError(messages.error.creatingCaso);
    }

    // Create the Caso
    try {
      createdCaso = await Caso.create(
        {
          name,
          description,
          classroom_id,
        },
        { transaction },
      );
    } catch (e) {
      throw new AppError(messages.error.creatingCaso, e.toString());
    }

    // Parses the tasks so it can iterate through it
    const tasksToBeCreated = JSON.parse(tasks);

    // Create the Tasks
    let i = 0;
    let createdTask = await Promise.map(tasksToBeCreated, async task => {

      i++;

      if (task.name.length > 0) {
        if (task.order == '') {
          const singleTask = await Task.create(
            {
              name: task.name,
              order: i,
              description: task.description,
              objective: task.objective,
              caso_id: createdCaso.id,
            },
            { transaction },
          );
        } else {
          const singleTask = await Task.create(
            {
              name: task.name,
              order: parseInt(task.order),
              description: task.description,
              objective: task.objective,
              caso_id: createdCaso.id,
            },
            { transaction },
          );
        }
      }

    });

    let zipArray = [];
    let mediasArray = [];

    // Store the general medias and the zips in separate arrays
    await Promise.map(fileArray, async singleFile => {

      if (singleFile.mimetype.includes('zip')) {
        zipArray.push(singleFile);
      }

      const mediasExtensions = ['png', 'jpg', 'jpeg', 'pdf', 'mp4'];

      if (mediasExtensions.includes(mimetypes.extension(singleFile.mimetype))) {
        mediasArray.push(singleFile);
      }
    });

    // Upload Medias
    if (mediasArray.length > 0) {
      await Promise.map(mediasArray, async singleFile => {

        let uploadFileName = path.basename(singleFile.path);

        // get mime type of file and pass it to the upload function
        const mimeType = mimetypes.lookup(singleFile.path);

        // Upload Medias to Firebase
        try {
          filesUploadUrl = await FirebaseHelper.uploadFile(
            path.resolve(__dirname, '..', 'tmp', uploadFileName),
            `caso/${createdCaso.dataValues.id}`,
            uploadFileName,
            mimeType,
          );
        } catch (e) {
          throw new AppError(messages.uploadError, e.toString());
        }

        // Saves the uploaded medias into the database
        try {
          let media = await Media.create(
            {
              caso_id: createdCaso.dataValues.id,
              url: filesUploadUrl,
              media_type_id: '1',
              thumbnail: '',
            },
            { transaction },
          );

          medias.push(media);
        } catch (e) {
          if (transaction) await transaction.rollback();

          throw new AppError(messages.error.creatingMedia, e.toString());
        }
      });
    }

    await transaction.commit();

    return response.json({
      message: messages.success,
      data: {
        caso: createdCaso.id,
        classroom_id,
        name: createdCaso.name,
        description: createdCaso.description,
        medias,
        sequences: sequencesCreated,
      },
    });
  }

  async destroy(request, response) {
    const {
      params: { id },
    } = request;

    let transaction;

    const messages = {
      success: 'Caso deletado com sucesso',
      error:
        'O Caso informado não pôde ser deletado. Verifique os dados e tente novamente',
      notFound:
        'O Caso informado não foi encontrado no banco de dados. Verifique os dados e tente novamente.',
    };

    // Initialize the transaction from "Caso"
    try {
      transaction = await Caso.sequelize.transaction();
    } catch (e) {
      throw new AppError(messages.error);
    }

    try {

      const casoFound = await Caso.findOne({
        where: { id },
      });

      if (casoFound) {
        // Find medias to delete
        let mediasToDelete = await Media.findAll({
          where: { caso_id: casoFound.id },
          attributes: ['id'],
        });

        // Delete medias
        mediasToDelete.forEach(async media => {
          const deletedMedia = await Media.destroy(
            {
              where: { id: media.id },
            },
            { transaction },
          );
        });

        // Find tasks to delete
        let tasksToDelete = await Task.findAll({
          where: { caso_id: casoFound.id },
          attributes: ['id'],
        });

        // Delete tasks
        tasksToDelete.forEach(async task => {
          const deletedTask = await Task.destroy(
            {
              where: { id: task.id },
            },
            { transaction },
          );
        });

        // Find sequences to delete
        let sequencesToDelete = await Sequence.findAll({
          where: { caso_id: casoFound.id },
          attributes: ['id'],
        });

        // Delete sequences from Orthanc
        try {

          const sequence = await Sequence.findOne({
            where: { caso_id: id },
          });

          const patientID = sequence.ohif_server_response.PatientID;
          await DicomHelper.deleteOrthancPatient(patientID);

        } catch (deleteError) {
          console.log("Delete sequences from Orthanc Error:", deleteError);
        }

        // Delete sequences from ClassHub - API
        sequencesToDelete.forEach(async sequence => {
          const deletedSequence = await Sequence.destroy(
            {
              where: { id: sequence.id },
            },
            { transaction },
          );

          let framesToDelete = await Frame.findAll(
            {
              where: { sequence_id: sequence.id },
            },
            { transaction },
          );

          framesToDelete.forEach(async frame => {
            const deletedFrame = await Frame.destroy({
              where: { id: frame.id },
            });
          });
        });

        // Delete caso
        await Caso.destroy({ where: { id } }, { transaction });

        await transaction.commit();

        return response.json({ message: messages.success });
      } else {
        return response.json({ message: messages.notFound });
      }

    } catch (e) {
      if (transaction) await transaction.rollback();
      throw new AppError(messages.error, e.toString());
    }

  }

  async update(request, response) {
    const {
      files,
      params: { id },
      body: {
        name,
        description,
        filesToDelete,
        tasks,
        tasksToDelete,
        sequences,
        sequencesToUpdate,
        sequenceToDelete,
      },
    } = request;

    let transaction;
    let casoToUpdate;
    let filesUploadUrl;
    let descompactedFiles;
    let sequence;
    let pathArray = [];

    const messages = {
      notFound:
        'Caso não encontrado ou você não tem permissão para acessar este recurso.',
      error:
        'Não foi possível atualizar este Caso. Verifique os dados e tente novamente.',
      success: 'Caso atualizado com sucesso.',
      uploadError:
        'Não foi possível realizar o upload da mídia, verifique os dados e tente novamente.',
      deleteMediaError:
        'Não foi possível deletar as mídias selecionadas. Verifique os dados informados e tente novamente.',
      deleteTaskError:
        'Não foi possível deletar as tarefas selecionadas. Verifique os dados informados e tente novamente.',
    };

    // Find the Caso from Id
    try {

      casoToUpdate = await Caso.findOne({
        where: { id },
        attributes: ['id', 'name', 'description'],
      });

    } catch (e) {
      throw new AppError(messages.notFound, e.toString());
    }

    if (!casoToUpdate) {
      throw new AppError(messages.notFound);
    }

    // Initialize the transaction
    try {
      transaction = await Caso.sequelize.transaction();
    } catch (e) {
      throw new AppError(messages.error);
    }

    let zipArray = [];
    let mediasArray = [];

    // Store the general medias and the zips in separate arrays
    await Promise.map(files, async singleFile => {

      if (singleFile.mimetype.includes('zip')) {
        zipArray.push(singleFile);
      }

      const mediasExtensions = ['png', 'jpg', 'jpeg', 'pdf', 'mp4'];

      if (mediasExtensions.includes(mimetypes.extension(singleFile.mimetype))) {
        mediasArray.push(singleFile);
      }
    });

    // Upload Medias
    if (mediasArray.length > 0) {
      await Promise.map(mediasArray, async singleFile => {

        let uploadFileName = path.basename(singleFile.path);

        // Upload Medias to Firebase
        try {
          filesUploadUrl = await FirebaseHelper.uploadFile(
            path.resolve(__dirname, '..', 'tmp', uploadFileName),
            `caso/${casoToUpdate.id}`,
            uploadFileName,
          );
        } catch (e) {
          throw new AppError(messages.uploadError, e.toString());
        }

        // Saves the uploaded medias into the database
        try {
          medias = await Media.create(
            {
              caso_id: casoToUpdate.id,
              url: filesUploadUrl,
              media_type_id: '1',
              thumbnail: '',
            },
            { transaction },
          );
        } catch (e) {
          if (transaction) await transaction.rollback();
          throw new AppError(messages.error.creatingMedia, e.toString());
        }
      });
    }

    const sequencesToBeUpdated = JSON.parse(sequencesToUpdate);

    await Promise.map(sequencesToBeUpdated, async sequence => {
      try {
        const seq = await Sequence.findOne({
          where: {
            id: sequence.id,
          },
        });

        if (!seq) {
          return;
        }

        await Sequence.update(
          {
            name: sequence.name,
            order: sequence.order,
          },
          {
            where: { id: sequence.id },
          },
          { transaction },
        );
      } catch (error) {
        throw new AppError(
          'Não foi possível atualizar sua sequência',
          error.toString(),
        );
      }
    });

    // Upload DCMs from .zips if exists
    // Creates the Sequences and Frames
    if (zipArray.length > 0) {
      await Promise.map(zipArray, async (singleFile, index) => {
        //TODO Implementar o upload dos DICONS para o OHIF Server

        const sequencesToBeCreated = JSON.parse(sequences);
        let sequence;

        // Decompress the zip file
        try {
          descompactedFiles = await decompress(
            singleFile.path,
            path.resolve(__dirname, '..', 'tmp', 'decompresseds'),
          );

          // Stores only the DCM files
          pathArray = descompactedFiles.filter(
            ({ type, path: filePath }) =>
              type === 'file' && filePath.includes('.dcm'),
          );

          if (pathArray.length === 0) {
            throw new AppError(
              'Envie um .zip com arquivos DICOM para continuar.',
            );
          }

          let sequenceOrderIncremental;

          if (sequencesToBeCreated[index].order === null) {
            sequenceOrderIncremental = i;
          } else {
            sequenceOrderIncremental = sequencesToBeCreated[index].order;
          }

          // Create the Sequence
          try {
            sequence = await Sequence.create(
              {
                name: sequencesToBeCreated[index].name,
                caso_id: casoToUpdate.id,
                order: sequenceOrderIncremental,
              },
              { transaction },
            );

            // sequencesCreated.push(sequence);
          } catch (e) {
            if (transaction) await transaction.rollback();
            throw new AppError(
              'Não foi possível criar a Sequência. Verifique os dados informados e tente novamente.',
              e.toString(),
            );
          }

          let studiesIntoOHIFServer = [];
          let formData = new FormData();

          for (const item of pathArray) {

            formData.append(
              'files[]',
              createReadStream(
                `${__dirname}/../tmp/decompresseds/${item.path}`,
              ),
            );
          }

          var config = {
            headers: formData.getHeaders(),
            maxContentLength: 100000000,
            maxBodyLength: 1000000000,
            auth: {
              username: process.env.DICOM_SERVER_USER,
              password: process.env.DICOM_SERVER_PASSWORD,
            }
          };

          try {

            const returnData = await axios.post(
              process.env.DICOM_SERVER_URL + 'instances/',
              formData,
              config,
            );

            // Busca todos os casos cadastrados no OHIF Server para obter o StudyInstanceId
            studiesIntoOHIFServer = await axios.get(
              process.env.DICOM_SERVER_URL + 'studies?expand',
            );
            studiesIntoOHIFServer = studiesIntoOHIFServer.data;
            let currentStudyIntoOHIFServer = studiesIntoOHIFServer.filter(
              v => v.ID == returnData.data.ParentStudy,
            )[0];

            const sequenceUpdated = await Sequence.update(
              {
                ohif_server_response: returnData.data,
                ohif_parent_study_id:
                  currentStudyIntoOHIFServer.MainDicomTags.StudyInstanceUID,
              },
              {
                where: { id: sequence.id },
                transaction,
              },
            );
          } catch (e) {
            throw new AppError(
              'Não foi possível enviar os DICOM`s para o OHIF Server.',
              e.toString(),
            );
          }
        } catch (e) {
          console.log(e);
          throw new AppError(
            'Não foi possível descompactar o arquivo enviado.',
            e.toString(),
          );
        }
      });
    }

    // Delete files
    if (filesToDelete) {
      try {
        filesToDelete.forEach(async file => {
          const toDelete = await Media.findOne({
            where: { id: file },
          });
          if (toDelete) {
            const deletedMedias = await Media.destroy({
              where: { id: toDelete.id },
            });
          }
        });
      } catch (e) {
        throw new AppError(messages.deleteMediaError, e.toString());
      }
    }

    // Delete tasks
    if (tasksToDelete) {
      try {
        tasksToDelete.forEach(async task => {

          const toDelete = await Task.findOne({
            where: { id: task },
          });

          const deletedTask = await Task.destroy({
            where: { id: toDelete.id },
          });
        });
      } catch (e) {
        throw new AppError(messages.deleteTaskError, e.toString());
      }
    }
    // Delete files
    if (filesToDelete) {
      try {
        filesToDelete.forEach(async file => {

          const toDelete = await Media.findOne({
            where: { id: file },
          });
          if (toDelete) {
            const deletedMedias = await Media.destroy({
              where: { id: toDelete.id },
            });
          }
        });
      } catch (e) {
        throw new AppError(messages.deleteMediaError, e.toString());
      }
    }

    // Delete Sequence
    if (sequenceToDelete) {
      try {
        sequenceToDelete.forEach(async sequence => {

          const toDelete = await Sequence.findOne({
            where: { id: sequence },
          });

          if (toDelete) {
            const deletedSequence = await Sequence.destroy({
              where: { id: toDelete.id },
            });
          }
        });
      } catch (e) {
        throw new AppError(messages.deleteTaskError, e.toString());
      }
    }

    const dataToUpdate = { name, description };

    // Update or create Tasks
    if (tasks) {
      // Parses the tasks so it can iterate through it
      const tasksToBeCreated = JSON.parse(tasks);

      // Create or Update the Tasks
      let i = 0;
      let createdTask = await Promise.map(tasksToBeCreated, async task => {

        i++;

        let singleTask;

        let data = {
          name: task.name,
          order: i,
          description: task.description,
          objective: task.objective,
          caso_id: casoToUpdate.id,
        };

        if (!!task.id) {
          data.id = task.id;

          singleTask = await Task.upsert(data, { transaction });
        } else {
          singleTask = await Task.create(data, { transaction });
        }

      });
    }
    // Update the found Caso
    try {
      const updateResponse = await Caso.update(
        dataToUpdate,
        {
          where: { id },
          attributes: ['name', 'description'],
          returning: true,
        },
        { transaction },
      );

      let updatedData = updateResponse.pop().shift();

      // await ImportDCMtoSql.execute();

      await transaction.commit();

      return response.json({
        message: 'Caso atualizado com sucesso',
        data: {
          id: updatedData.id,
          name: updatedData.name,
          description: updatedData.description,
        },
      });
    } catch (e) {
      if (transaction) await transaction.rollback();
      throw new AppError(
        'Não foi possível atualizar o caso selecionado.',
        e.toString(),
      );
    }
  }

  async uploadMedia(request, response) {
    const allowedMediaExtensions = ['png', 'jpg', 'jpeg', 'pdf', 'mp4'];
    let filesArrayFromRequest = [];
    let mediasToUploadArray = [];
    let currentCase = null;
    let filesUploadUrl = '';
    let transaction;
    let mediasInDatabase = [];

    try {
      filesArrayFromRequest = request.files.files || [];
      currentCase = await Caso.findByPk(request.params.id);

      // Initialize the transaction
      transaction = await Media.sequelize.transaction();

      // Filtra os anexos para realizar o upload somente do que é permitido.
      await Promise.map(filesArrayFromRequest, async singleFile => {
        if (
          allowedMediaExtensions.includes(
            mimetypes.extension(singleFile.mimetype),
          )
        ) {
          mediasToUploadArray.push(singleFile);
        }
      });

      // Upload dos arquivos
      if (mediasToUploadArray.length > 0) {
        await Promise.map(mediasToUploadArray, async singleFile => {
          let uploadFileName = path.basename(singleFile.path);
          const mimeType = mimetypes.lookup(singleFile.path);

          try {
            filesUploadUrl = await FirebaseHelper.uploadFile(
              path.resolve(__dirname, '..', 'tmp', uploadFileName),
              `caso/${currentCase.id}`,
              uploadFileName,
              mimeType,
            );
          } catch (e) {
            throw new AppError(
              'Não foi possível realizar o upload da mídia, verifique os dados e tente novamente.',
              e.toString(),
            );
          }

          try {
            let media = await Media.create(
              {
                caso_id: request.params.id,
                name: request.body.name,
                url: filesUploadUrl,
                media_type_id: '1',
                thumbnail: '',
              },
              { transaction },
            );

            mediasInDatabase.push(media);
          } catch (e) {
            if (transaction) await transaction.rollback();
            throw new AppError(
              'Não foi possível realizar o upload da mídia, verifique os dados e tente novamente.',
              e.toString(),
            );
          }
        });

        await transaction.commit();
      }
      // Upload dos arquivos

      return response.json({
        message: 'Caso atualizado com sucesso',
        data: {
          id: currentCase.id,
          name: currentCase.name,
          description: currentCase.description,
        },
      });
    } catch (e) {
      throw new AppError(
        'Não foi possível atualizar o caso selecionado.',
        e.toString(),
      );
    }
  }

  async getMedias(request, response) {
    const caseId = request.params.id;
    const groupedBy = request.query.grouped_by;
    let mediasToReturn = [];

    try {
      if (groupedBy) {
        mediasToReturn = await Media.findAll({
          raw: true,
          where: {
            caso_id: caseId,
          },
          attributes: [
            groupedBy,
            [Sequelize.fn('array_agg', Sequelize.col('id')), 'id'],
          ],
          group: [groupedBy],
          order: [[groupedBy, 'ASC']],
        });

        for (let i in mediasToReturn) {
          let currentMediaObjs = await Media.findAll({
            raw: true,
            where: {
              id: mediasToReturn[i].id,
            },
            attributes: ['id', ['url', 'fileUrl']],
            order: [['created_at', 'DESC']],
          });

          mediasToReturn[i].files = currentMediaObjs;

          delete mediasToReturn[i].id;
        }
      } else {
        mediasToReturn = await Media.findAll({
          raw: true,
          where: {
            caso_id: caseId,
          },
          order: [['created_at', 'DESC']],
        });
      }

      return response.json({
        message: 'Medias listadas com sucesso',
        medias: mediasToReturn,
      });
    } catch (e) {
      throw new AppError(
        'Não foi possível listar as medias deste caso.',
        e.toString(),
      );
    }
  }

  async deleteMedia(request, response) {
    const mediaId = request.params.id_media;
    const casoId = request.params.id;
    let currentMedia;
    let transaction;

    currentMedia = await Media.findOne({
      where: {
        id: mediaId,
        caso_id: casoId,
      },
    });

    if (currentMedia) {
      try {
        transaction = await Media.sequelize.transaction();
      } catch (e) {
        throw new AppError(
          'A mídia informada não pôde ser deletada. Verifique os dados e tente novamente',
        );
      }

      try {
        await Media.destroy(
          {
            where: { id: mediaId, caso_id: casoId },
          },
          { transaction },
        );

        transaction.commit();
        return response.json({ message: 'A mídia foi apagada com sucesso!' });
      } catch (e) {
        if (transaction) await transaction.rollback();
        throw new AppError(
          'A mídia informada não pôde ser deletada. Verifique os dados e tente novamente',
          e.toString(),
        );
      }
    } else {
      throw new AppError(
        'A mídia informada não existe. Verifique os dados e tente novamente',
        '',
      );
    }
  }

  async uploadDicons(request, response) {
    const { files } = request.files;
    // let studiesIntoOHIFServer = [];
    let studyInstanceId = '';
    const returnOfUploads = [];
    // let descompactedFiles;
    const zipArray = [];
    let transaction;
    const pathArrayAbsolute = [];
    let orthancPatient;
    let sequenceCreated;

    const currentCase = await Caso.findOne({
      where: {
        id: request.params.id,
      },
    });

    // Get the caso date formated for Orthanc API
    const year = currentCase.created_at.getFullYear().toString();
    const month = (currentCase.created_at.getMonth() + 1).toString();
    const day = currentCase.created_at.getDay().toString();
    const dicomDateFormated = year + month + day;

    const caso = {
      id: currentCase.id,
      name: currentCase.name,
      date: currentCase.created_at,
      dateFormated: dicomDateFormated,
    };

    const tmpPathName = caso.id.replace(/[^0-9a-zA-Z ]/g, '');

    try {
      transaction = await Sequence.sequelize.transaction();

      const currentSequence = await Sequence.findOne({
        where: { caso_id: caso.id },
      });
      if (currentSequence) {
        if (currentSequence.ohif_server_response.ParentPatient) {
          try {
            await axios({
              method: 'delete',
              url: `${process.env.DICOM_SERVER_URL}patients/${currentSequence.ohif_server_response.ParentPatient}`,
            });
          } catch (e) {
            // Nada a fazer, pois se o paciente não for apagado não gerará problemas.
          }
        }
      }

      await Promise.map(files, async singleFile => {
        if (singleFile.mimetype.includes('zip')) {
          zipArray.push(singleFile);
        }
      });

      if (zipArray.length > 0) {
        const jszipInstace = new JSZip();

        await PromiseBluebird.map(zipArray, async fileToUpload => {
          try {
            const filesPath = [];
            const relativePaths = [];

            const extractPath = path.resolve(
              __dirname,
              '..',
              'tmp',
              'decompresseds',
              tmpPathName,
            );

            fs.mkdirSync(extractPath);

            const fileContent = fs.readFileSync(fileToUpload.path);

            const result = await jszipInstace.loadAsync(fileContent);

            result.forEach((relativePath, fileObj) => {
              if (fileObj.unsafeOriginalName) {
                relativePaths.push(relativePath);
              }
            });

            await PromiseBluebird.map(relativePaths, async relativePath => {
              const fileName = path.basename(relativePath);
              const finalPathFileName = path.resolve(extractPath, fileName);

              await result
                .file(relativePath)
                .async('nodebuffer')
                .then(buff => {
                  fs.writeFileSync(finalPathFileName, buff);
                  filesPath.push(finalPathFileName);
                });

              result.remove(relativePath);
            });

            // const tmpDicomFolder = path.resolve(__dirname, "..", "tmp", "decompresseds", tmpPathName);

            // descompactedFiles = await decompress(
            //   fileToUpload.path,
            //   tmpDicomFolder,
            // );

            const refex = /[áàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ]/;

            // Check if files without extensions are dicoms
            filesPath.forEach(file => {
              if (refex.test(file)) {
                throw new AppError(
                  'O nome das pastas ou dos arquivos contem caracteres não permitidos.',
                );
              }
              // const filePathAbsolute = `${tmpDicomFolder}/${file.path}`;
              const fileIsDicom = DicomHelper.checkIfFileIsDicom(file);

              if (fileIsDicom) {
                pathArrayAbsolute.push(file);
              }
            });

            await PromiseBluebird.map(
              pathArrayAbsolute,
              async dicomPath => {
                // Anonymization
                DicomHelper.anonymizerDicom(dicomPath, caso);

                // Read Dicom
                const dicomBuffer = fs.readFileSync(dicomPath);
                const dicomDataSet = dicomParser.parseDicom(dicomBuffer);

                // Sempre será pego o id do ultimo frame que sempre é o mesmo para todo o caso.
                // TODO Precisamos descobrir como salvar todos os metadados, ler esta URL (https://rawgit.com/cornerstonejs/dicomParser/master/examples/dragAndDropDump/index.html);
                studyInstanceId = dicomDataSet.string('x0020000d');

                // Aqui são montadas as requisições para enviar para o OHIF DICOM SERVER os .dcm.
                const formData = new FormData();

                const config = {
                  headers: formData.getHeaders(),
                  maxContentLength: 100000000,
                  maxBodyLength: 1000000000,
                  auth: {
                    username: process.env.DICOM_SERVER_USER,
                    password: process.env.DICOM_SERVER_PASSWORD,
                  },
                };

                formData.append('files[]', createReadStream(dicomPath));

                // Upload to Orthanc
                try {
                  const returnData = await axios.post(
                    // process.env.DICOM_SERVER_URL + 'instances?pathOfFile='+ tmpPathName + '/'+ pathItem.path,
                    `${process.env.DICOM_SERVER_URL}instances?pathOfFile=${dicomPath}`,
                    formData,
                    config,
                  );
                  returnOfUploads.push(returnData);
                } catch (e) {
                  returnOfUploads.push(e);
                }

                // Get Orthanc patientID
                const dicomPatientID = dicomDataSet.string('x00100020');
                orthancPatient = await DicomHelper.requestOrthancPatient(
                  dicomPatientID,
                );
              },
              { concurrency: 20 },
            );
          } catch (e) {
            throw new AppError(
              'Não foi possível descompactar os DICOM`s para upload',
              JSON.stringify(e),
            );
          } finally {
            // Delete temporary files
            await fsExtra.remove(
              path.resolve(
                __dirname,
                '..',
                'tmp',
                'decompresseds',
                tmpPathName,
              ),
            );
          }
        });

        // Orthanc Anonymization
        const orthancPatientAnonymized = await DicomHelper.anonymizerDicomByOrthancPatientID(
          orthancPatient.ID,
          caso,
        );
        const study = await DicomHelper.getOrthancStudy(
          orthancPatientAnonymized.PatientID,
        );
        const studyInstanceUID = study.MainDicomTags.StudyInstanceUID;

        // Save into DB
        await Sequence.destroy({
          where: {
            caso_id: caso.id,
          },
          transaction,
        });

        sequenceCreated = await Sequence.create(
          {
            name: caso.name,
            caso_id: caso.id,
            order: 1,
            ohif_server_response: orthancPatientAnonymized,
            ohif_parent_study_id: studyInstanceUID,
          },
          {
            transaction,
          },
        );

        await transaction.commit();

        return response.json({
          message: "Dicom's enviados com sucesso!",
        });
      }
    } catch (e) {
      await transaction.rollback();
      throw new AppError(
        'Não foi possível realizar o upload dos DICOM`s para o Caso',
        JSON.stringify(e),
      );
    } finally {
      await Promise.map(files, async singleFile => {
        await fsExtra.remove(singleFile.path);
      });
    }
  }
}

export default new CasoController();
