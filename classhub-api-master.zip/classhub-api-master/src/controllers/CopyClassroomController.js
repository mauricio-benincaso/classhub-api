import { Promise } from 'bluebird';
import uuid from 'uuid-v4';
import lodash from 'lodash';
import { AppError } from '../errors';
import { ClassroomHelper } from '../helpers';
import {
  Caso,
  Classroom,
  Course,
  Frame,
  Media,
  Sequence,
  Task,
  UserCourse,
} from '../models';

class CopyClassroomController {
  async copy(request, response) {
    // copy the classroom to the new course based on the ids from the request
    const {
      body: { classrooms_id, course_id },
      sequelize,
    } = request;
    const user_id = sequelize.user.id;

    let classroomsArray;

    // turn classrooms_id into an array if it isn't already
    if (Array.isArray(classrooms_id)) {
      classroomsArray = classrooms_id;
    } else {
      classroomsArray = [classrooms_id];
    }

    Promise.map(classroomsArray || classrooms_id, async classroom_id => {
      // get the classroom and the agregated course, and caso, as well as the casos agreggated data
      const classroom = await Classroom.findOne({
        where: { id: classroom_id, user_id: sequelize.user.id },
        include: [
          {
            model: Course,
            as: 'courses',
            attributes: ['id', 'title'],
          },
          {
            model: Caso,
            as: 'casos',
            attributes: ['id', 'name', 'description'],
            include: [
              {
                model: Sequence,
                as: 'sequences',
                attributes: ['id', 'name', 'order'],
                include: [
                  {
                    model: Frame,
                    attributes: ['data', 'order', 'uri'],
                  },
                ],
              },
              {
                model: Task,
                attributes: ['id', 'name', 'description', 'objective', 'order'],
              },
              {
                model: Media,
                attributes: ['url', 'thumbnail', 'media_type_id'],
              },
            ],
          },
        ],
      });

      // if the classroom is not found, throw an error
      if (!classroom) {
        throw new AppError('A aula informada não existe para este usuário');
      }

      // get the course based on the id from the request
      const course = await Course.findOne({ where: { id: course_id } });

      // if the course is not found, throw an error
      if (!course) {
        throw new AppError('O curso informado não existe');
      }

      // get the usercourse to know if the user is already registered in the course
      const usercourse = await UserCourse.findOne({
        where: { course_id: course.id, user_id: sequelize.user.id },
      });

      // if the usercourse is not found, throw an error
      if (!usercourse) {
        throw new AppError('Você não está inscrito no curso informado');
      }

      // pass the classroom, the user and the course to the helper to copy the classroom
      await ClassroomHelper.copy(classroom, user_id, course_id);
    });

    return response
      .json({
        message: `Aula(s) copiada com sucesso`,
      })
      .status(200);
  }
}

export default new CopyClassroomController();
