import { AppError } from '../errors';
import { Classroom, User } from '../models';

class TransferClassroomController {
  async transfer(request, response) {
    const {
      params: { id, targetUserId },
    } = request;

    let classroom;

    try {
      classroom = await Classroom.findOne({ where: { id } });
    } catch (e) {
      throw new AppError(
        'Não foi possível encontrar a aula informada',
        e.toString(),
      );
    }

    if (!classroom) {
      throw new AppError('Não encontramos a aula informada');
    }

    let targetUser;
    try {
      // search for the target user and check if it's a teacher and if active: true
      targetUser = await User.findOne({
        where: { id: targetUserId },
      });
    } catch (e) {
      throw new AppError(
        'Não foi possível encontrar o usuário informado',
        e.toString(),
      );
    }

    if (!targetUser) {
      throw new AppError('Não encontramos o usuário informado');
    }

    // update classroom to the target user id
    try {
      classroom.update({
        user_id: targetUserId,
      });
    } catch (e) {
      throw new AppError(
        'Não foi possível atualizar a aula para o professor informado',
        e.toString(),
      );
    }

    return response.status(200).json({
      message: 'Aula transferida com sucesso!',
      data: {
        id: classroom.id,
        classroom: classroom.title,
        user_id: targetUser.id,
        user: targetUser.name,
      },
    });
  }
}

export default new TransferClassroomController();
