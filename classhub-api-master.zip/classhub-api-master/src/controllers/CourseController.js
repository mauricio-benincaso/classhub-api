import { Course, Classroom, UserCourse, User } from '../models';
import { AppError } from '../errors';
import { PaginateHelper, FirebaseHelper } from '../helpers';
import { Op } from 'sequelize';
import path from 'path';
import { Promise as BlueBirdPromise } from 'bluebird';

class CourseController {
  async index(request, response) {
    const {
      query: { page, pageSize, search },
      sequelize,
    } = request;
    let courses;
    let teacherCourses;
    let total_pages;

    const { offset, limit } = PaginateHelper.paginate(page, pageSize);

    // List all courses linked to the Teacher
    if (sequelize.user.roles.label == 'Professor') {
      if (!search) {
        try {
          teacherCourses = await UserCourse.findAll({
            where: { user_id: sequelize.user.id },
            attributes: ['course_id'],
          });

          // Gets all the courses Ids from an single user
          const listOfIds = teacherCourses.map(
            singleUser => singleUser.course_id,
          );

          courses = await BlueBirdPromise.map(listOfIds, async course_id => {
            let singleCourse = await Course.findOne({
              where: { id: course_id },
              attributes: ['id', 'title', 'created_at', 'thumbnail'],
              // attributes: ['id', 'title', 'description', 'created_at'],
            });

            return singleCourse;
          });

          if (!courses) {
            throw new AppError('Nenhum curso encontrado');
          }

          total_pages = PaginateHelper.getTotalPages(courses.length, pageSize);

          return response.json({
            message: 'Cursos listados',
            data: courses,
            courses_total: courses.length,
            current_page: page,
            total_pages,
          });
        } catch (e) {
          throw new AppError(
            'Não foi possível listar os cursos do banco de dados',
            e.toString(),
          );
        }

        // List all courses with search param
      } else {
        try {
          teacherCourses = await UserCourse.findAll({
            where: { user_id: sequelize.user.id },
            attributes: ['course_id'],
          });

          // Gets all the courses Ids from an single user
          const listOfIds = teacherCourses.map(
            singleUser => singleUser.course_id,
          );

          courses = [];

          await BlueBirdPromise.map(listOfIds, async course_id => {
            let singleCourse = await Course.findOne({
              where: { id: course_id, title: { [Op.iLike]: `%${search}%` } },
              attributes: ['id', 'title', 'created_at', 'thumbnail'],
              // attributes: ['id', 'title', 'description', 'created_at'],
            });

            if (singleCourse) {
              courses.push(singleCourse);
            }
          });

          if (!courses) {
            throw new AppError('Nenhum curso encontrado');
          }

          total_pages = PaginateHelper.getTotalPages(courses.length, pageSize);

          return response.json({
            message: 'Cursos listados',
            data: courses,
            courses_total: courses.length,
            current_page: page,
            total_pages,
          });
        } catch (e) {
          throw new AppError(
            'Não foi possível listar os cursos do banco de dados',
            e.toString(),
          );
        }
      }
      //List all courses
    } else if (sequelize.user.roles.label == 'Administrador') {
      if (!search) {
        try {
          courses = await Course.findAndCountAll({
            order: [['created_at', 'DESC']],
            offset,
            limit,
          });
        } catch (e) {
          throw new AppError(
            'Não foi possível listar os cursos do banco de dados',
            e.toString(),
          );
        }
      } else {
        try {
          courses = await Course.findAndCountAll({
            where: { title: { [Op.iLike]: `%${search}%` } },
          });
        } catch (e) {
          throw new AppError(
            'Não foi possível listar os cursos do banco de dados',
            e.toString(),
          );
        }
      }

      if (!courses) {
        throw new AppError('Nenhum curso encontrado');
      }

      total_pages = PaginateHelper.getTotalPages(courses.count, pageSize);

      return response.json({
        message: 'Cursos listados',
        data: courses.rows,
        courses_total: courses.count,
        current_page: page,
        total_pages,
      });
    }
  }

  async show(request, response) {
    const {
      params: { id },
    } = request;
    let course;

    try {
      course = await Course.findOne({
        where: { id },
        attributes: ['id', 'title', 'thumbnail'],
      });
    } catch (e) {
      throw new AppError('Não foi possível mostrar o curso selecionado');
    }

    if (!course) {
      throw new AppError('Curso não encontrado');
    }

    return response.json({
      message: 'Curso listado: ',
      data: course,
    });
  }

  async store(request, response) {
    const {
      // body: { title, description },
      body: { title },
      file,
    } = request;

    let uploadFile;
    let transaction;

    if (await Course.findOne({ where: { title } })) {
      throw new AppError(
        'Já existe um Curso com este nome, verifique os dados e tente novamente.',
      );
    }

    // Initialize the transaction
    try {
      transaction = await Course.sequelize.transaction();
    } catch (e) {
      if (transaction) await transaction.rollback();
      throw new AppError('Não foi possível inicializar a transaction.');
    }

    try {
      // Upload files for the thumbnail
      if (file) {
        const uploadFileName = path.basename(file.path);

        try {
          uploadFile = await FirebaseHelper.uploadFile(
            `src/tmp/${uploadFileName}`,
            `course/thumbnail`,
            uploadFileName,
          );
        } catch (e) {
          console.log(e);
          throw new AppError(
            'Não foi posssível realizar o upload da thumbnail.',
            e.toString(),
          );
        }
      }

      const createdCourse = await Course.create(
        {
          title,
          // description,
          thumbnail: uploadFile,
        },
        { transaction },
      );

      // create a users_course for all the masters users
      let masterUsers;
      try {
        masterUsers = await User.findAll({
          where: { master: true },
          transaction,
        });
      } catch (e) {
        throw new AppError(
          'Não foi possível listar os usuários do tipo master do banco de dados',
          e.toString(),
        );
      }
      try {
        await BlueBirdPromise.map(masterUsers, async master => {
          await UserCourse.create(
            {
              user_id: master.id,
              course_id: createdCourse.id,
            },
            { transaction },
          );
        });
      } catch (e) {
        throw new AppError(
          'Falha ao linkar o curso com o usuário do tipo master',
        );
      }

      await transaction.commit();

      return response.json({
        message: 'Curso criado com sucesso',
        data: {
          title: createdCourse.title,
          // description: createdCourse.description,
          thumbnail: createdCourse.thumbnail,
        },
      });
    } catch (e) {
      if (transaction) await transaction.rollback();

      console.log(e);
      throw new AppError('Não foi possível criar um Curso: ', e.toString());
    }
  }

  // TODO : dont allow to destroy a course if it has classrooms
  async destroy(request, response) {
    const {
      params: { id },
    } = request;

    const courseFound = await Course.findOne({
      where: { id: id.toString() },
      include: [{ model: User, as: 'users' }],
    });

    if (courseFound) {
      await Course.destroy({
        where: { id: id.toString() },
      });

      return response.json({
        message: 'Curso deletado',
      });
    } else {
      return response.json({
        message: 'Curso não encontrado.',
      });
    }
  }

  async update(request, response) {
    const {
      params: { id },
      // body: { title, description, thumbnail },
      body: { title, thumbnail },
      file,
    } = request;

    let uploadFile;
    let transaction;
    let course;

    // Find the course by Id
    try {
      course = await Course.findOne({
        where: { id },
        attributes: ['title'],
      });
    } catch (e) {
      throw new AppError(
        'Curso não encontrado ou você não tem permissão para acessar este recurso',
      );
    }

    // Initialize the transaction
    try {
      transaction = await Course.sequelize.transaction();
    } catch (e) {
      if (transaction) await transaction.rollback();
      throw new AppError('Não foi possível inicializar a transaction.');
    }

    // Upload files for the thumbnail
    if (file) {
      const uploadFileName = path.basename(file.path);

      try {
        uploadFile = await FirebaseHelper.uploadFile(
          `src/tmp/${uploadFileName}`,
          `course/thumbnail`,
          uploadFileName,
        );
      } catch (e) {
        if (transaction) await transaction.rollback();
        console.log(e);
        throw new AppError(
          'Não foi posssível realizar o upload da thumbnail.',
          e.toString(),
        );
      }
    }

    // const dataToUpdate = { title, description, thumbnail: uploadFile };
    const dataToUpdate = { title, thumbnail: uploadFile };

    try {
      const updateResponse = await Course.update(dataToUpdate, {
        where: { id },
        attributes: ['title', 'thumbnail'],
        // attributes: ['title', 'description', 'thumbnail'],
        returning: true,
      });

      const updatedData = updateResponse.pop().shift();

      return response.json({
        message: 'Curso atualizado com sucesso!',
        data: {
          title: updatedData.title,
          // description: updatedData.description,
          thumbnail: updatedData.thumbnail,
        },
      });
    } catch (e) {
      console.log(e);
      throw new AppError('Não foi possível atualizar o curso. ', e.toString());
    }
  }
}

export default new CourseController();
