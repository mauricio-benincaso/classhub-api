import { Caso, Classroom, Course, Role, User } from '../models';
import { AppError } from '../errors';
import { PaginateHelper } from '../helpers';
import uuid from 'uuid-v4';
import { Op } from 'sequelize';

class ClassroomController {
  async store(request, response) {
    const {
      user_id,
      sequelize,
      body: { title, course_id, teacher_id },
    } = request;

    let teacher;
    if (sequelize.user.roles.label == 'Administrador') {
      teacher = await User.findOne({
        where: { id: teacher_id || user_id },
        attributes: [
          'id',
          'name',
          'profile_picture',
          'email',
          'status',
          'role_id',
        ],
        include: [{ model: Role, as: 'roles' }],
      });

      if (!teacher || teacher.roles.label !== 'Professor') {
        throw new AppError(
          'O usuário informado não existe ou não é do tipo professor',
        );
      }
    }

    if (
      await Classroom.findOne({
        where: { title, user_id: teacher_id || user_id },
      })
    ) {
      throw new AppError(
        'Já existe uma Aula com este nome, verifique os dados e tente novamente',
      );
    }

    const id = uuid();
    const twilioHash = id + '_' + sequelize.user.id;

    try {
      const createdClassroom = await Classroom.create({
        user_id: teacher_id || user_id,
        title,
        course_id,
        hash: twilioHash,
      });

      return response.json({
        message: 'Aula criada com sucesso',
        data: {
          id: createdClassroom.id,
          user_id: teacher_id || user_id,
          title: createdClassroom.title,
          course_id: createdClassroom.course_id,
          hash: createdClassroom.hash,
        },
      });
    } catch (e) {
      throw new AppError('Não foi possível criar uma Aula ' + e.toString());
    }
  }

  async index(request, response) {
    const {
      query: { page, pageSize, search, course_id },
      sequelize,
    } = request;
    let classrooms;

    const { offset, limit } = PaginateHelper.paginate(page, pageSize);
    const includes = [
      {
        model: User,
        as: 'users',
        where: { status: true, deleted_at: null },
        attributes: ['name'],
      },
      { model: Course, attributes: ['title'], as: 'courses' },
      {
        model: Caso,
        as: 'casos',
        where: {
          deleted_at: null,
        },
        required: false,
      },
    ];

    let course_title;

    if (course_id) {
      course_title = await Course.findOne({
        where: { id: course_id },
        attributes: ['title'],
        raw: true,
      });
    }

    // List all Classrooms that are linked to the Teacher who made the request
    if (sequelize.user.roles.label == 'Professor') {
      // List all without the search params
      if (!search) {
        try {
          classrooms = await Classroom.findAndCountAll({
            where: { user_id: sequelize.user.id, course_id },
            attributes: [
              'id',
              'title',
              'user_id',
              'course_id',
              'created_at',
              'order',
            ],
            order: [['created_at', 'DESC']],
            include: includes,
            offset,
            limit,
          });

        } catch (e) {
          throw new AppError(
            'Não foi possível listar as aulas do banco de dados',
            e.toString(),
          );
        }
      } else {
        try {
          classrooms = await Classroom.findAndCountAll({
            where: { title: { [Op.iLike]: `%${search}%` } },
            attributes: [
              'id',
              'title',
              'user_id',
              'course_id',
              'created_at',
              'order',
              'hash',
            ],
            include: includes,
          });

        } catch (e) {
          throw new AppError(
            'Não foi possível buscar as aulas do banco de dados',
          );
        }
      }
    } else if (sequelize.user.roles.label == 'Administrador') {
      if (!search) {
        try {
          classrooms = await Classroom.findAndCountAll({
            order: [['created_at', 'DESC']],
            attributes: [
              'id',
              'title',
              'user_id',
              'course_id',
              'created_at',
              'order',
              'hash',
            ],
            include: [
              {
                model: User,
                as: 'users',
                where: { status: true, deleted_at: null },
                attributes: ['name', 'status'],
              },
              {
                model: Course,
                attributes: ['title'],
                as: 'courses',
                where: { deleted_at: null },
              },
              {
                model: Caso,
                as: 'casos',
                where: {
                  deleted_at: null,
                },
                required: false,
              },
            ],
            offset,
            limit,
          });
        } catch (e) {
          throw new AppError(
            'Não foi possível listar as Aulas do banco de dados.',
            e.toString(),
          );
        }
      } else {
        try {
          classrooms = await Classroom.findAndCountAll({
            where: { title: { [Op.iLike]: `%${search}%` } },
            attributes: [
              'id',
              'title',
              'user_id',
              'course_id',
              'created_at',
              'order',
              'hash',
            ],
            include: [
              {
                model: User,
                as: 'users',
                where: { status: true, deleted_at: null },
                attributes: ['name', 'status'],
              },
              { model: Course, attributes: ['title'], as: 'courses' },
              {
                model: Caso,
                as: 'casos',
                where: {
                  deleted_at: null,
                },
                required: false,
              },
            ],
          });
        } catch (e) {
          throw new AppError(
            'Não foi possível listar as Aulas do banco de dados',
            e.toString(),
          );
        }
      }
    }

    if (!classrooms) {
      throw new AppError('Nenhuma aula encontrada');
    }

    const total_pages = PaginateHelper.getTotalPages(
      classrooms.count,
      pageSize,
    );

    return response.json({
      message: 'Aulas listados com sucesso',
      data: classrooms.rows,
      classrooms_total: classrooms.count,
      course_id,
      course: course_title,
      current_page: page,
      total_pages,
    });
  }

  async show(request, response) {
    const {
      params: { id },
      sequelize,
    } = request;
    let classroom;

    if (!sequelize) {
      try {
        classroom = await Classroom.findOne({
          where: { id },
          attributes: [
            'id',
            'title',
            'user_id',
            'course_id',
            'created_at',
            'order',
            'hash',
          ],
          include: [
            {
              model: Caso,
              attributes: ['id', 'name', 'description'],
            },
          ],
        });
      } catch (e) {
        throw new AppError('Não foi possível buscar a aula', e.toString());
      }
    } else {
      try {
        classroom = await Classroom.findOne({
          where: { id, user_id: sequelize.user.id },
          attributes: [
            'id',
            'title',
            'user_id',
            'course_id',
            'created_at',
            'order',
            'hash',
          ],
          include: [
            {
              model: Caso,
              attributes: ['id', 'name', 'description'],
            },
          ],
        });

      } catch (e) {
        throw new AppError(
          'Não foi possível mostrar a aula selecionada',
          e.toString(),
        );
      }
    }

    if (!classroom) {
      throw new AppError('A aula não foi encontrada');
    }

    return response.json({
      message: 'Aula listada: ',
      data: classroom,
    });
  }

  async update(request, response) {
    const {
      user_id,
      params: { id },
      body: { title, order, teacher_id },
    } = request;

    let classroom;

    try {
      classroom = await Classroom.findOne({
        where: { id, user_id: teacher_id || user_id },
        attributes: ['title', 'order'],
      });
    } catch (e) {
      throw new AppError(
        'Aula não encontrada ou você não tem permissão para acessar este recurso.',
        e.toString(),
      );
    }

    const dataToUpdate = {
      title: title || classroom.title,
      order: order || classroom.order,
    };

    try {
      const updateResponse = await Classroom.update(dataToUpdate, {
        where: { id },
        attributes: ['title', 'order'],
        returning: true,
      });

      const updatedData = updateResponse.pop().shift();

      return response.json({
        message: 'Aula atualizada com sucesso!',
        data: {
          id: updatedData.id,
          title: updatedData.title,
          user_id: updatedData.userId,
          order: order || updatedData.order,
        },
      });
    } catch (e) {
      throw new AppError('Não foi possível atualizar a aula', e.toString());
    }
  }

  async destroy(request, response) {
    const {
      params: { id },
      body: { teacher_id },
      sequelize,
    } = request;

    if (sequelize.user.roles.label === 'Administrador') {
      if (!teacher_id) {
        throw new AppError('É necessário informar qual o professor da aula');
      }
      const classroomFound = await Classroom.findOne({
        where: { id: id.toString(), user_id: teacher_id },
      });

      if (classroomFound) {
        try {
          await classroomFound.destroy();
        } catch (e) {
          throw new AppError('Não foi possível excluir a aula', e.toString());
        }

        return response.json({
          message: 'Aula deletada.',
        });
      } else {
        throw new AppError('Aula não encontrada');
      }
    } else if (sequelize.user.roles.label === 'Professor') {
      const classroomFound = await Classroom.findOne({
        where: { id: id.toString(), user_id: sequelize.user.id },
      });

      if (classroomFound) {
        try {
          await classroomFound.destroy();
        } catch (e) {
          throw new AppError('Não foi possível excluir a aula', e.toString());
        }

        return response.json({
          message: 'Aula deletada.',
        });
      } else {
        throw new AppError('Aula não encontrada');
      }
    }
  }
}

export default new ClassroomController();
