import { Frame, Sequence } from '../models';
import { AppError } from '../errors';
import decompress from 'decompress';
import path from 'path';
import ConvertToJpeg from '../tools/ConvertToJpeg';
import { DicomParserHelper, FirebaseHelper } from '../helpers';

class SequenceController {
  async store(request, response) {
    const { body, file } = request;

    let sequence;
    let descompactedFiles;
    let pathArray = [];
    let transaction;

    // descomprimindo arquivo
    try {
      descompactedFiles = await decompress(
        file.path,
        path.resolve(__dirname, '..', 'tmp', 'decompresseds'),
      );
    } catch (e) {
      console.log(e);
      throw new AppError('Não foi possível descompactar', e.toString());
    }

    // separando apenas os arquivos DICOM
    pathArray = descompactedFiles.filter(
      ({ type, path: filePath }) =>
        type === 'file' && filePath.includes('.dcm'),
    );

    if (pathArray.length === 0) {
      throw new AppError('Envie um .zip com arquivos DICOM para continuar.');
    }

    try {
      transaction = await Sequence.sequelize.transaction();
    } catch (e) {
      if (transaction) await transaction.rollback();

      throw new AppError('Não foi possível inicializar a transaction.');
    }

    // criando sequencia
    try {
      sequence = await Sequence.create(body, { transaction });
    } catch (e) {
      if (transaction) await transaction.rollback();

      console.log(e);

      throw new AppError(
        'Não foi possível criar essa sequencia. Verifique os dados informados e tente novamente.',
        e.toString(),
      );
    }

    for (const item of pathArray) {
      let resultConversion;
      let resultParsed;
      let uploadUrl;

      let uploadFileName = path.basename(item.path);

      try {
        resultConversion = await ConvertToJpeg.execute(item.path);
      } catch (e) {
        if (transaction) await transaction.rollback();

        throw new AppError('Não foi possível converter o arquivo.');
      }

      try {
        resultParsed = DicomParserHelper.magicMaker(
          path.resolve(__dirname, '..', 'tmp', 'decompresseds', item.path),
        );
      } catch (e) {
        if (transaction) await transaction.rollback();

        throw new AppError('Não foi possível extrair dados do arquivo.');
      }

      try {
        uploadUrl = await FirebaseHelper.uploadFile(
          resultConversion,
          `sequence/${sequence.id}`,
          uploadFileName,
        );
      } catch (e) {
        console.log(e);
        throw new AppError(`Não foi possível realizar o upload`);
      }

      try {
        await Frame.create(
          {
            sequence_id: sequence.id,
            data: JSON.stringify(resultParsed),
            uri: uploadUrl,
          },
          { transaction },
        );
      } catch (e) {
        console.log(e);

        if (transaction) await transaction.rollback();

        throw new AppError('Não foi possível criar o frame.');
      }
    }

    await transaction.commit();

    return response.json(sequence);
  }

  async destroy(request, response) {
    const {
      params: { id },
    } = request;

    try {
      await Sequence.destroy({ where: { id } });
      return response.json({ message: 'Sequencia deletada!' });
    } catch (e) {
      console.log(e);
      throw new AppError('Não foi possível deletar a sequência.', e.toString());
    }
  }

  async update(request, response) {
    const {
      params: { id },
      body: { name },
    } = request;

    try {
      const updateResponse = await Sequence.update(
        { name },
        {
          where: { id },
          returning: true,
        },
      );

      return response.json({
        message: 'Sequencia atualizada com sucesso',
        data: updateResponse,
      });
    } catch (e) {
      console.log(e);
      throw new AppError(
        'Não foi possível atualizar a sequência selecionada. Verifique os dados informados e tente novamente',
        e.toString(),
      );
    }
  }

  /*
  async show(request, response) {
    const { sequenceId } = request.params;
    let sequence;

    try {
      sequence = await Sequence.findOne({
        where: { id: sequenceId },
        attributes: ['id', 'name'],
        include: [
          {
            model: Exam,
            as: 'exam',
            attributes: ['id', 'name'],
          },
          {
            model: Frame,
            attributes: ['id', 'name', 'src'],
          },
        ],
      });
    } catch (e) {
      console.log(e);
      throw new AppError('Não foi possível mostrar a sequência selecionada');
    }

    if (!sequence) {
      throw new AppError('A sequência não foi encontrada');
    }

    return response.render('../views/framesIndex', {
      exam: sequence.exam,
      sequence: { id: sequence.id, name: sequence.name },
      frames: sequence.frames,
    });
  }
  */
}
export default new SequenceController();
