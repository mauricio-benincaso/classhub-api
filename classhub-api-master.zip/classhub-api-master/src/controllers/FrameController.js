import { Exam, Frame, Sequence } from '../models';
import { AppError } from '../errors';

class FrameController {
  async show(request, response) {
    const { frameId } = request.params;
    let frame;

    try {
      frame = await Frame.findOne({
        where: { id: frameId },
        attributes: ['id', 'data', 'order', 'uri'],
        include: [
          {
            model: Sequence,
            as: 'sequence',
            attributes: ['name'],
          },
        ],
      });
    } catch (e) {
      console.log(e);
      throw new AppError('Não foi possível mostrar o frame selecionado');
    }

    if (!frame) {
      throw new AppError('O frame não foi encontrada');
    }

    const dataArray = JSON.parse(frame.data);

    const keysOfDataArray = Object.keys(dataArray);

    return response.render('../views/frameInfo', {
      frame: {
        id: frame.id,
        data: frame.data,
        order: frame.order,
        uri: frame.uri,
      },
      sequence: frame.sequence,
    });
  }
}
export default new FrameController();
