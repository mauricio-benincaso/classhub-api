import twilio, { jwt as jwtTwilio } from 'twilio';

import { Classroom, User } from '../models';
import { JwtHelper } from '../helpers';
import { AppError } from '../errors';

class ClassroomTwilioTokenController {
  async index(request, response) {
    const {
      headers: { authorization },
      query: { name = 'Participante' },
      params: { id },
    } = request;

    let decodedBearerToken;
    let databaseClassroom;
    let twilioChannels;
    let createdChannel;
    let databaseUser;

    try {
      databaseClassroom = await Classroom.findOne({ where: { id } });

      if (!databaseClassroom) {
        throw new AppError(
          'Esta aula não foi encontrada em nosso banco de dados',
        );
      }
    } catch (e) {
      throw new AppError(
        'Não foi possível verificar se a aula informada existe em nosso banco de dados',
      );
    }

    const twilioaccessToken = new jwtTwilio.AccessToken(
      process.env.TWILIO_ACCOUNT_SID,
      process.env.TWILIO_API_KEY,
      process.env.TWILIO_API_SECRET,
    );
    const twilioVideoGrant = new jwtTwilio.AccessToken.VideoGrant({
      room: databaseClassroom.hash,
    });
    const twilioChatGrant = new jwtTwilio.AccessToken.ChatGrant({
      serviceSid: process.env.TWILIO_CHAT_SERVICE_SID,
    });
    const twilioInstance = twilio(
      process.env.TWILIO_ACCOUNT_SID,
      process.env.TWILIO_AUTH_TOKEN,
    );

    try {
      twilioChannels = await twilioInstance.chat
        .services(process.env.TWILIO_CHAT_SERVICE_SID)
        .channels.list();
    } catch (e) {
      throw new AppError('Não foi possível capturar os canais de comunicação');
    }

    const existingChannel = twilioChannels.find(
      item => item.uniqueName === databaseClassroom.hash,
    );

    if (!existingChannel) {
      try {
        createdChannel = await twilioInstance.chat
          .services(process.env.TWILIO_CHAT_SERVICE_SID)
          .channels.create({
            sid: databaseClassroom.hash,
            uniqueName: databaseClassroom.hash,
            friendlyName: databaseClassroom.title,
          });
      } catch (e) {
        console.log(e);

        throw new AppError(
          'Não foi possível criar o canal de comunicação para esta aula',
        );
      }
    }

    twilioaccessToken.addGrant(twilioVideoGrant);
    twilioaccessToken.addGrant(twilioChatGrant);

    if (authorization) {
      const [, bearerToken] = authorization.split(' ');

      try {
        decodedBearerToken = JwtHelper.verify(bearerToken);
      } catch (e) {
        throw new AppError(
          'Não foi possível verificar o token do usuário informado',
        );
      }

      try {
        databaseUser = await User.findOne({
          where: { id: decodedBearerToken.id },
        });

        if (!databaseUser) {
          throw new AppError(
            'O usuário informado não existe em nosso banco de dados',
          );
        }
      } catch (e) {
        throw new AppError(
          'Não foi possível verificar se o usuário informado existe em nosso banco de dados',
        );
      }
    }

    if (databaseUser) {
      if (databaseUser.id === databaseClassroom.user_id) {
        twilioaccessToken.identity = `[PROFº DA AULA] - ${databaseUser.name}`;
      } else {
        twilioaccessToken.identity = name;
      }
    } else {
      twilioaccessToken.identity = name;
    }

    const twilioJwtToken = twilioaccessToken.toJwt();

    return response.json({
      data: {
        channel: existingChannel || createdChannel,
        identity: twilioaccessToken.identity,
        token: twilioJwtToken,
      },
      message: 'Dados capturados com sucesso',
    });
  }
}

export default new ClassroomTwilioTokenController();
