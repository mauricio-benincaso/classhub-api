import { VideoLesson } from '../models';
import { AppError } from '../errors';
import { FirebaseHelper, PaginateHelper } from '../helpers';
import path, { resolve } from 'path';
import extractFrames from 'ffmpeg-extract-frames';
import uuid from 'uuid-v4';

class VideoLessonController {
  async store(request, response) {
    const { body, file, user_id } = request;

    const { title } = body;

    let uploadVideo;
    let uploadThumbnail;

    let thumbnailName = uuid();

    let uploadVideoName = path.basename(file.path);

    // extract frames
    try {
      await extractFrames({
        input: file.path,
        output: resolve(
          __dirname,
          '..',
          'tmp',
          'thumbnail',
          `${thumbnailName}` + `.jpg`,
        ),
        offsets: [2000],
      });
    } catch (e) {
      console.log(e);
      throw new AppError('Não foi possível extrair o frame para a thumbnail');
    }

    // Upload
    try {
      uploadThumbnail = await FirebaseHelper.uploadFile(
        `./src/tmp/thumbnail/${thumbnailName}.jpg`,
        `thumbnail`,
        `${thumbnailName}`,
      );
      uploadVideo = await FirebaseHelper.uploadFile(
        `./src/tmp/video/${uploadVideoName}`,
        `video`,
        `${title}.mp4`,
        'video/mp4',
      );
    } catch (e) {
      console.log(e);
      throw new AppError(`Não foi possível realizar o upload.`);
    }

    let url = uploadVideo;
    let thumbnail = uploadThumbnail;

    try {
      await VideoLesson.create({
        title,
        url,
        thumbnail,
        user_id,
      });

      return response.json({
        message: 'Vídeo criado com sucesso ',
        data: { title, url, thumbnail, user_id },
      });
    } catch (e) {
      throw new AppError(
        'Não foi possível adicionar a vídeo-aula no banco de dados. Verifique os dados informados e tente novamente',
        e.toString(),
      );
    }
  }

  async update(request, response) {
    const {
      user_id,
      file,
      params: { id },
      body: { title },
    } = request;

    try {
      const { url, thumbnail } = await VideoLesson.findOne({
        where: { id: Number(id), user_id: user_id.toString() },
        attributes: ['url', 'thumbnail'],
      });
    } catch (e) {
      throw new AppError('Você não tem permissão para acessar esse conteúdo');
    }

    const dataToUpdate = { title };

    if (file) {
      let uploadVideoName = path.basename(file.path);

      let uploadVideo;
      let uploadThumbnail;
      let thumbnail = uuid();

      // extract frame
      try {
        await extractFrames({
          input: file.path,
          output: resolve(
            __dirname,
            '..',
            'tmp',
            'thumbnail',
            `${file.filename}.jpg`,
          ),
          offsets: [2000],
        });
      } catch (e) {
        console.log(e);
        throw new AppError('Não foi possível extrair o frame para a thumbnail');
      }

      // Update and upload new File
      try {
        uploadThumbnail = await FirebaseHelper.uploadFile(
          `./src/tmp/thumbnail/${file.filename}.jpg`,
          `thumbnail`,
          `${thumbnail}`,
        );
        uploadVideo = await FirebaseHelper.uploadFile(
          `./src/tmp/video/${file.filename}`,
          `video`,
          `${title}.mp4`,
          'video/mp4',
        );

        dataToUpdate.url = uploadVideo;
        dataToUpdate.thumbnail = uploadThumbnail;
      } catch (e) {
        console.log(e);
        throw new AppError(
          'Não foi possível atualizar o vídeo no banco de dados',
        );
      }
    }

    try {
      const updateResponse = await VideoLesson.update(dataToUpdate, {
        where: { id, user_id },
        returning: true,
      });

      return response.json({
        message: 'Vídeo atualizado com sucesso',
        data: updateResponse,
      });
    } catch (e) {
      throw new AppError('Não foi possível atualizar o vídeo', e.toString());
    }
  }

  async destroy(request, response) {
    const {
      user_id,
      params: { id },
    } = request;

    const videoFound = await VideoLesson.findOne({
      where: { id: Number(id), user_id: user_id.toString() },
    });

    if (videoFound) {
      await VideoLesson.destroy({
        where: { id: Number(id), user_id: user_id.toString() },
      });

      return response.json({ message: 'Vídeo deletado' });
    } else {
      return response.json({ message: 'Vídeo não encontrado' });
    }
  }

  async index(request, response) {
    let videos;
    let total_pages;

    const {
      query: { page, pageSize },
    } = request;

    const { offset, limit } = PaginateHelper.paginate(page, pageSize);

    try {
      videos = await VideoLesson.findAndCountAll({
        offset,
        limit,
      });
    } catch (e) {
      throw new AppError('Não foi possível listar os vídeos do banco de dados');
    }

    if (!videos) {
      throw new AppError('Nenhum vídeo encontrado');
    }

    total_pages = PaginateHelper.getTotalPages(videos.count, pageSize);

    return response.json({
      message: 'Vídeos listados com sucesso',
      data: videos.rows,
      videos_total: videos.count,
      current_page: page,
      total_pages,
    });
  }

  async show(request, response) {
    const {
      user_id,
      params: { id },
    } = request;
    const videoLesson = await VideoLesson.findOne({
      where: { id: Number(id), user_id: user_id.toString() },
      attributes: ['title', 'url', 'thumbnail', 'user_id'],
    });

    if (!videoLesson) {
      throw new AppError('Vídeo não encontrado');
    }

    return response.json({
      message: 'Vídeo listado:',
      data: videoLesson,
    });
  }
}

export default new VideoLessonController();
