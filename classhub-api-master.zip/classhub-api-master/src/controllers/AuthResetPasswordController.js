import { Token, User } from '../models';
import { AppError } from '../errors';
import { isBefore, parseISO } from 'date-fns';

class AuthResetPasswordController {
  async update(request, response) {
    const {
      body: { password },
      query: { token_code },
    } = request;

    const token = await Token.findOne({ where: { token_code } });

    if (!token) {
      return response.status(400).json({ message: 'Token inválido' });
    }

    const parsedtoken = token.token_expires;
    const now = new Date();

    if (isBefore(parsedtoken, new Date())) {
      return response.status(400).json({ message: 'Token expirou' });
    }

    const user = await User.findOne({ where: { id: token.user_id } });

    if (!user) {
      return response.status(400).json({
        message: 'Não foi possível criar uma nova senha para você.',
      });
    }

    if (user.status == false) {
      return response.status(400).json({
        message: 'Usuário inativo.',
      });
    }

    await user.update({ password });

    token.destroy();

    return response
      .status(200)
      .json({ message: 'Nova senha criada com sucesso' });
  }
}

export default new AuthResetPasswordController();
