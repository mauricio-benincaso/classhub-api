import { Task } from '../models';
import { AppError } from '../errors';
import { PaginateHelper } from '../helpers';
import { Op } from 'sequelize';

class TaskController {
  async index(request, response) {
    const {
      query: { page, pageSize, search, caso_id },
    } = request;
    let tasks;
    let total_pages;

    const { offset, limit } = PaginateHelper.paginate(page, pageSize);

    if (!search) {
      try {
        tasks = await Task.findAndCountAll({
          // order: [['order', 'DESC']],
          where: { caso_id },
          offset,
          limit,
          attributes: [
            'id',
            'name',
            'description',
            'objective',
            'order',
            'caso_id',
            'created_at',
          ],
        });
      } catch (e) {
        throw new AppError(
          'Não foi possível listar as tarefas do banco de dados',
          e.toString(),
        );
      }
    } else {
      try {
        tasks = await Task.findAndCountAll({
          where: {
            name: { [Op.iLike]: `%${search}%` },
            caso_id,
          },
          attributes: [
            'id',
            'name',
            'description',
            'objective',
            'order',
            'caso_id',
          ],
        });
      } catch (e) {
        throw new AppError(
          'Não foi possível buscar as tarefas do banco de dados',
        );
      }
    }

    if (!tasks) {
      throw new AppError('Nenhuma tarefa encontrada');
    }

    total_pages = PaginateHelper.getTotalPages(tasks.count, pageSize);

    let tasksToJson = JSON.parse(JSON.stringify(tasks, null, 4));

    return response.json({
      message: 'Tarefas listados com sucesso',
      tasks: tasks.rows,
      tasks_total: tasks.count,
      current_page: page,
      total_pages,
    });
  }

  async show(request, response) {
    const { id } = request.params;

    let task;

    try {
      task = await Task.findOne({
        where: { id },
        attributes: ['id', 'name', 'description', 'objective'],
      });
    } catch (e) {
      throw new AppError('Não foi possível mostrar a tarefa selecionada', e);
    }

    if (!task) {
      throw new AppError('Tarefa não encontrada');
    }

    return response.json({
      message: 'Task listada: ',
      data: task,
    });
  }

  async store(request, response) {
    const {
      body: { name, description, objective, order, caso_id },
    } = request;

    if (await Task.findOne({ where: { name } })) {
      throw new AppError(
        'Já existe uma Tarefa com este nome, verifique os dados e tente novamente',
      );
    }

    try {
      const createdTask = await Task.create({
        name,
        description,
        objective,
        caso_id,
        order,
      });

      return response.json({
        message: 'Task adicionado com sucesso',
        data: {
          caso_id,
          order: createdTask.order,
          name: createdTask.name,
          description: createdTask.description,
          objective: createdTask.objective,
        },
      });
    } catch (e) {
      throw new AppError('Não foi possível criar um Task ' + e);
    }
  }

  async destroy(request, response) {
    const {
      params: { id },
    } = request;

    try {
      await Task.destroy({ where: { id } });
      return response.json({ message: 'Task deletado.' });
    } catch (e) {
      console.log(e);
      throw new AppError(
        'Não foi possível deletar o task específico.',
        e.toString(),
      );
    }
  }

  async update(request, response) {
    const {
      params: { id },
      body: { name, description },
    } = request;

    try {
      const updateResponse = await Task.update(
        { name, description },
        {
          where: { id },
          returning: true,
        },
      );
      return response.json({
        message: 'Task atualizado com sucesso',
        data: updateResponse,
      });
    } catch (e) {
      console.log(e);
      throw new AppError(
        'Não foi possível atualizar o task selecionado.',
        e.toString(),
      );
    }
  }
}

export default new TaskController();
