import twilio, { jwt } from 'twilio';
import User from '../models/default/User.js';
import Classroom from '../models/default/Classroom.js';

class TwilioAccessTokenController {
  /** After generate a new AccessToken, using the provided credentials, returns the token in JWT format
   */
  async store(request, response) {
    const {
      // body: { cpf, name },
      body: { name },
      params: { classroom_id },
    } = request;
    const { AccessToken } = jwt;
    const { VideoGrant, ChatGrant } = AccessToken;

    // Substitute your Twilio AccountSid and ApiKey details
    const ACCOUNT_SID = process.env.TWILIO_ACCOUNT_SID;
    const API_KEY_SID = process.env.TWILIO_API_KEY;
    const API_KEY_SECRET = process.env.TWILIO_API_SECRET;
    const AUTH_TOKEN = process.env.TWILIO_AUTH_TOKEN;
    const CHAT_SERVICE_SID = process.env.TWILIO_CHAT_SERVICE_SID;

    // Create an Access Token
    const accessToken = new AccessToken(
      ACCOUNT_SID,
      API_KEY_SID,
      API_KEY_SECRET,
    );

    // Set the Identity of this token
    accessToken.identity = name;

    // Find the Classroom
    const classroom = await Classroom.findOne({
      where: { id: classroom_id },
      attributes: ['hash', 'title'],
    });

    // Grant access to Video
    const videoGrant = new VideoGrant();
    videoGrant.room = classroom.hash;

    // Grant access to Chat
    const chatGrant = new ChatGrant({
      serviceSid: process.env.TWILIO_CHAT_SERVICE_SID,
    });
    chatGrant.room = classroom.hash;

    accessToken.addGrant(videoGrant);
    accessToken.addGrant(chatGrant);

    const client = twilio(ACCOUNT_SID, AUTH_TOKEN);

    const channels = await client.chat
      .services(CHAT_SERVICE_SID)
      .channels.list();

    let channel = channels.find(
      chann => chann.friendlyName === classroom.title,
    );

    if (!channel) {
      channel = await client.chat.services(CHAT_SERVICE_SID).channels.create({
        sid: classroom.hash,
        uniqueName: classroom.hash,
        friendlyName: classroom.title,
      });
    }

    // Serialize the token as a JWT
    const createdToken = accessToken.toJwt();

    return response.json({ createdToken, channel });
  }
}
export default new TwilioAccessTokenController();
