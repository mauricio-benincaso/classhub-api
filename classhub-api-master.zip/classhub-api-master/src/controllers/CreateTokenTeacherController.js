import twilio, { jwt } from 'twilio';
import User from '../models/default/User.js';
import Classroom from '../models/default/Classroom.js';

//TODO ADJUST TO CREATE THE TEACHER CLASSROOM
class CreateTokenTeacherController {
  /** After generate a new AccessToken, using the provided credentials, returns the token in JWT format
   */
  async store(request, response) {
    const {
      params: { classroom_id },
      sequelize,
    } = request;
    const { AccessToken } = jwt;
    const { VideoGrant, ChatGrant } = AccessToken;

    // Substitute your Twilio AccountSid and ApiKey details
    const ACCOUNT_SID = process.env.TWILIO_ACCOUNT_SID;
    const API_KEY_SID = process.env.TWILIO_API_KEY;
    const API_KEY_SECRET = process.env.TWILIO_API_SECRET;
    const AUTH_TOKEN = process.env.TWILIO_AUTH_TOKEN;
    const CHAT_SERVICE_SID = process.env.TWILIO_CHAT_SERVICE_SID;

    // Create an Access Token
    const accessToken = new AccessToken(
      ACCOUNT_SID,
      API_KEY_SID,
      API_KEY_SECRET,
    );

    // Find the Classroom
    const classroom = await Classroom.findOne({
      where: { id: classroom_id },
      attributes: ['hash', 'title', 'user_id'],
    });

    // Set classroom teacher
    if (sequelize.user.id === classroom.user_id) {
      accessToken.identity = `[PROFº DA AULA] - ${sequelize.user.name}`;
    } else {
      accessToken.identity = `[PROFº AUXILIAR] - ${sequelize.user.name}`;
    }

    // Grant access to Video
    const videoGrant = new VideoGrant();
    videoGrant.room = classroom.hash;

    // Grant access to Chat
    const chatGrant = new ChatGrant({
      serviceSid: CHAT_SERVICE_SID,
    });

    accessToken.addGrant(chatGrant);
    accessToken.addGrant(videoGrant);

    const client = twilio(ACCOUNT_SID, AUTH_TOKEN);

    const channels = await client.chat
      .services(CHAT_SERVICE_SID)
      .channels.list();

    let channel = channels.find(
      chann => chann.friendlyName === classroom.title,
    );

    if (!channel) {
      channel = await client.chat.services(CHAT_SERVICE_SID).channels.create({
        sid: classroom.hash,
        uniqueName: classroom.hash,
        friendlyName: classroom.title,
      });
    }

    // Serialize the token as a JWT
    const createdToken = accessToken.toJwt();

    return response.json({
      message: `Token criado com sucesso para ${accessToken.identity}`,
      createdToken,
      channel,
    });
  }
}
export default new CreateTokenTeacherController();
