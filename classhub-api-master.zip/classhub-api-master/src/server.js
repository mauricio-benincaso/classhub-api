import dotenv from 'dotenv';

dotenv.config();

import { serverHttp } from './http';
import './websocket';

serverHttp.listen(process.env.SERVER_PORT, () => {
  console.log(`✅ Server started on port ${process.env.SERVER_PORT}`);
});
