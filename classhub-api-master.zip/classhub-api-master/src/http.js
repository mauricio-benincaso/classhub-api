import dotenv from 'dotenv';

dotenv.config();

import { Server } from 'socket.io';
import http from 'http';
import app from './App';

const serverHttp = http.createServer(app);

const io = new Server(serverHttp, {
  cors: {
    origin: '*',
  },
});

export { serverHttp, io };
