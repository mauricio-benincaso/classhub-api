import DefaultDatabase from './default';

export { DefaultDatabase };
