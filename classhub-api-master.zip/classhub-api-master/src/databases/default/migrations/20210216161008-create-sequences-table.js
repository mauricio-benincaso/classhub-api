module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('sequences', {
      id: {
        type: Sequelize.UUID,
        allowNull: false,
        autoIncrement: false,
        primaryKey: true,
      },
      name: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      caso_id: {
        type: Sequelize.UUID,
        allowNull: false,
        references: { model: 'casos', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE',
      },
      created_at: {
        type: Sequelize.DATE,
        allowNull: false,
      },
      updated_at: {
        type: Sequelize.DATE,
        allowNull: false,
      },
      deleted_at: {
        type: Sequelize.DATE,
        allowNull: true,
      },
    });
  },
  down: queryInterface => {
    return queryInterface.dropTable('sequences');
  },
};
