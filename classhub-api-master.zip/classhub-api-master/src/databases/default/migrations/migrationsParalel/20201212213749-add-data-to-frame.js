module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.addColumn('frames', 'data', {
      type: Sequelize.TEXT,
      allowNull: true,
    });
  },
  down: queryInterface => {
    return queryInterface.removeColumn('frames', 'data');
  },
};
