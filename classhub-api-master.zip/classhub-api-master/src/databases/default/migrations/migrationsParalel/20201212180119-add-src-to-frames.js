module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.addColumn('frames', 'src', {
      type: Sequelize.STRING,
      allowNull: false,
    });
  },
  down: queryInterface => {
    return queryInterface.removeColumn('frames', 'src');
  },
};
