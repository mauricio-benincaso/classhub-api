module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction(transaction => {
      return Promise.all([
        queryInterface.addColumn(
          'sequences',
          'order',
          { type: Sequelize.INTEGER, allowNull: false },
          { transaction },
        ),
      ]);
    });
  },
  down: queryInterface => {
    return queryInterface.sequelize.transaction(transaction => {
      return Promise.all([
        queryInterface.removeColumn('sequences', 'order', { transaction }),
      ]);
    });
  },
};
