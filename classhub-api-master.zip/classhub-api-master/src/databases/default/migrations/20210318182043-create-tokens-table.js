const uuid = require('uuid-v4');

module.exports = {
  up: (queryInterface, Sequelize) => {
     return queryInterface.createTable('tokens', {
      id: {
        allowNull: false,
        autoIncrement: false,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true,
        type: Sequelize.UUID
      },
      user_id: {
        type: Sequelize.UUID,
        allowNull: false,
        references: { model: 'users', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE',
      },
      token_code: {
        type: Sequelize.UUID,
        allowNull: false,
      },
      token_expires: {
        type: Sequelize.DATE,
        allowNull: false,
        deafultValue: Date.now() + 40000,
      },
      created_at: {
        type: Sequelize.DATE,
        allowNull: false,
      },
      updated_at: {
        type: Sequelize.DATE,
        allowNull: false,
      },
      deleted_at: {
        type: Sequelize.DATE,
        allowNull: true,
      },
    });
  },
  down: (queryInterface, Sequelize) => {
   return queryInterface.dropTable('tokens');
  }
};