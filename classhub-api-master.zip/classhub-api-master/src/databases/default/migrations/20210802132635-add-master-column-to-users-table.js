module.exports = {
  up: async (queryInterface, Sequelize) => {
    queryInterface.addColumn('users', 'master', {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
      allowNull: false,
    });
  },

  down: async (queryInterface, Sequelize) => {
    return queryInterface.removeColumn('users', 'master');
  },
};
