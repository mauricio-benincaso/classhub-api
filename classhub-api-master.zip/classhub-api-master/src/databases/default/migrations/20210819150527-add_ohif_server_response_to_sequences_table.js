'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    queryInterface.addColumn('sequences', 'ohif_server_response', {
      type: Sequelize.JSON,
      defaultValue: "{}",
      allowNull: false,
    });
  },

  down: async (queryInterface, Sequelize) => {
    return queryInterface.removeColumn('sequences', 'ohif_server_response');
  }
};
