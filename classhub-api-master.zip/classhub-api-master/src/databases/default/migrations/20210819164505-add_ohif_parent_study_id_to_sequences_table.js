'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    queryInterface.addColumn('sequences', 'ohif_parent_study_id', {
      type: Sequelize.STRING,
      defaultValue: "",
      allowNull: false,
    });
  },

  down: async (queryInterface, Sequelize) => {
    return queryInterface.removeColumn('sequences', 'ohif_parent_study_id');
  }
};
