module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.changeColumn('courses', 'description', {
      type: Sequelize.STRING,
      allowNull: true,
    });
  },
  down: queryInterface => {
    return queryInterface.removeColumn('courses', 'description');
  },
};
