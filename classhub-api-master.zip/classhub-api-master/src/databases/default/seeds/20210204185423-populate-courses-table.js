const bcrypt = require('bcrypt');

module.exports = {
  up: async queryInterface => {
    return queryInterface.bulkInsert('courses', [
      {
        id: '0dea9a58-c512-4afe-a59e-e14069bced72',
        title: 'Curso 02',
        thumbnail: 'fileteste.jpg',
        // description: 'Curso para realizaçao de exame por imagem',
        created_at: '2021-04-19T17:36:17.925Z',
        updated_at: '2021-04-19T17:36:17.925Z',
        deleted_at: null,
      },
      {
        id: 'f4f85768-dde1-476c-afdb-6b3c4c7b1572',
        title: 'Curso 01',
        thumbnail: 'fileteste.jpg',
        // description: 'Curso para realizaçao de exame por imagem',
        created_at: '2021-04-19T17:35:58.936Z',
        updated_at: '2021-04-19T17:35:58.936Z',
        deleted_at: null,
      },
    ]);
  },
  down: async queryInterface => {
    return queryInterface.bulkDelete('courses', null, {});
  },
};
