module.exports = {
  up: async queryInterface => {
    return queryInterface.bulkInsert('media_types', [
      {
        name: 'jpg',
        label: 'Imagem',
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        name: 'mp4',
        label: 'Video',
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        name: 'pdf',
        label: 'PDF',
        created_at: new Date(),
        updated_at: new Date(),
      },
    ]);
  },
  down: async queryInterface => {
    return queryInterface.bulkDelete('media_types', null, {});
  },
};
