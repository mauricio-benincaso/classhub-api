const bcrypt = require('bcrypt');

module.exports = {
  up: async queryInterface => {
    return queryInterface.bulkInsert('user_courses', [
      {
        id: '219656fd-b3a0-465f-92e4-639ce2992d67',
        user_id: '61cd2be5-48d0-4563-bb23-b0bf7291106d',
        course_id: '0dea9a58-c512-4afe-a59e-e14069bced72',
        created_at: '2021-04-19T17:34:00.925Z',
        updated_at: '2021-04-19T17:34:00.925Z',
        deleted_at: null,
      },
      {
        id: '53e0f16a-9492-44d1-b5b5-7bc4bbe22c63',
        user_id: '61cd2be5-48d0-4563-bb23-b0bf7291106d',
        course_id: 'f4f85768-dde1-476c-afdb-6b3c4c7b1572',
        created_at: '2021-04-19T17:36:17.925Z',
        updated_at: '2021-04-19T17:36:17.925Z',
        deleted_at: null,
      },
    ]);
  },
  down: async queryInterface => {
    return queryInterface.bulkDelete('user_courses', null, {});
  },
};
