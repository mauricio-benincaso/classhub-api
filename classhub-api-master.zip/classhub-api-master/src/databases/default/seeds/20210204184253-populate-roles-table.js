module.exports = {
  up: async queryInterface => {
    return queryInterface.bulkInsert('roles', [
      {
        name: 'teacher',
        label: 'Professor',
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        name: 'adm',
        label: 'Administrador',
        created_at: new Date(),
        updated_at: new Date(),
      },
    ]);
  },
  down: async queryInterface => {
    return queryInterface.bulkDelete('roles', null, {});
  },
};
