const bcrypt = require('bcrypt');

module.exports = {
  up: async queryInterface => {
    return queryInterface.bulkInsert('users', [
      {
        id: '64253f40-b42d-4daa-81ed-2a9089e64778',
        name: 'Dev Softmakers',
        email: 'dev@softmakers.com.br',
        password: bcrypt.hashSync(
          '!123Qwer',
          parseInt(process.env.BCRYPT_SALT),
        ),
        role_id: 2,
        status: true,
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        id: '9cca81e5-b898-4060-ba33-b868b7dd8549',
        name: 'Teste Dev Softmakers',
        email: 'testedev@softmakers.com.br',
        password: bcrypt.hashSync(
          '!123Qwer',
          parseInt(process.env.BCRYPT_SALT),
        ),
        role_id: 2,
        status: true,
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        id: '61cd2be5-48d0-4563-bb23-b0bf7291106d',
        name: 'Active Teacher Softmakers',
        email: 'teacher@softmakers.com.br',
        password: bcrypt.hashSync(
          '!123Qwer',
          parseInt(process.env.BCRYPT_SALT),
        ),
        role_id: 1,
        status: true,
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        id: 'fbe6907e-fc9d-4548-9389-1907a1f4188a',
        name: 'TEACHER Dev Softmakers',
        email: 'testeteacher@softmakers.com.br',
        password: bcrypt.hashSync(
          '!123Qwer',
          parseInt(process.env.BCRYPT_SALT),
        ),
        role_id: 1,
        status: false,
        created_at: new Date(),
        updated_at: new Date(),
      },
    ]);
  },
  down: async queryInterface => {
    return queryInterface.bulkDelete('users', null, {});
  },
};
