import { Sequelize } from 'sequelize';

import { defaultDatabaseConfig } from '../../config';
import {
  Course,
  Sequence,
  Caso,
  Classroom,
  Frame,
  // Exam,
  Role,
  User,
  VideoLesson,
  Token,
  Task,
  Media,
  MediaType,
  UserCourse,
} from '../../models';

const models = [
  Course,
  Sequence,
  Caso,
  Classroom,
  Frame,
  Role,
  // Exam,
  User,
  VideoLesson,
  Token,
  Task,
  Media,
  MediaType,
  UserCourse,
];

class DefaultDatabase {
  constructor() {
    this.init();
    this.associate();
  }

  init() {
    this.connection = new Sequelize(defaultDatabaseConfig);
    this.connection
      .authenticate()
      .then(() => {
        console.log(
          `✅ Connection successfully with default database on port ${process.env.DB_PORT}`,
        );
      })
      .catch((e) => {
        console.log(
          `🚨 Connection unsuccessfully with default database on port ${process.env.DB_PORT}`,
          e
        );
      });

    models.map(model => model.init(this.connection));
  }

  associate() {
    models.forEach(model => {
      if (model.associate) {
        model.associate(this.connection.models);
      }
    });
  }
}

export default new DefaultDatabase();
