const bcrypt = require('bcrypt');

module.exports = {
  up: async queryInterface => {
    return queryInterface.bulkInsert('classrooms', [
      {
        name: 'Aula 01',
        // course_id: 1,
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        name: 'Aula 02',
        // course_id: 1,
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        name: 'Aula 03',
        // course_id: 1,
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        name: 'Aula 01',
        // course_id: 2,
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        name: 'Aula 02',
        // course_id: 2,
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        name: 'Aula 03',
        // course_id: 2,
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        name: 'Aula 01',
        // course_id: 3,
        created_at: new Date(),
        updated_at: new Date(),
      },
    ]);
  },
  down: async queryInterface => {
    return queryInterface.bulkDelete('classrooms', null, {});
  },
};
