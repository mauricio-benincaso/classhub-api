const bcrypt = require('bcrypt');

module.exports = {
  up: async queryInterface => {
    return queryInterface.bulkInsert('courses', [
      {
        title: 'Curso de ressonancia',
        description: 'Ressonancia magnetica - 01',
        thumbnail: 'imageRM.01',
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        title: 'Curso de ultrassom',
        description: 'Ultrassonografia - 01',
        thumbnail: 'imageUltrassom.01',
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        title: 'Curso TESTE',
        description: 'TESTE',
        thumbnail: 'teste.01',
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        title: 'Curso de Tomografia Computadorizada',
        description: 'Curso de Tomografia Computadorizada',
        thumbnail: 'https://www.itnonline.com/sites/default/files/field/image/Neusoft_Essence.jpg',
        created_at: new Date(),
        updated_at: new Date(),
      },
    ]);
  },
  down: async queryInterface => {
    return queryInterface.bulkDelete('courses', null, {});
  },
};
