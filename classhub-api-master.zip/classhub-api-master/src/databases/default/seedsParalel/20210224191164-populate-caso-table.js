const bcrypt = require('bcrypt');

module.exports = {
  up: async queryInterface => {
    return queryInterface.bulkInsert('casos', [
      {
        name: 'Caso teste 01',
        description: 'Caso de teste ressonancia magnetica - 01 dcm',
        classroom_id: 1,
        created_at: new Date(),
        updated_at: new Date(),
      },
    ]);
  },
  down: async queryInterface => {
    return queryInterface.bulkDelete('casos', null, {});
  },
};
