import { Model, DataTypes } from 'sequelize';
import Sequence from './Sequence';

class Exam extends Model {
  static init(connection) {
    super.init(
      {
        name: DataTypes.STRING,
      },
      {
        sequelize: connection,
        name: {
          singular: 'exam',
          plural: 'exams',
        },
      },
    );

    return this;
  }

  static associate() {
    this.hasMany(Sequence);
  }
}

export default Exam;
