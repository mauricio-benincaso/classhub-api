import { Model, DataTypes } from 'sequelize';
import Media from './Media';

class MediaType extends Model {
  static init(connection) {
    super.init(
      {
        name: DataTypes.STRING,
        label: DataTypes.STRING,
      },
      {
        sequelize: connection,
      },
    );

    return this;
  }

  static associate() {
    this.hasMany(Media);
  }
}

export default MediaType;
