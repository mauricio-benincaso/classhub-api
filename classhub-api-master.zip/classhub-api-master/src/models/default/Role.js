import { Model, DataTypes } from 'sequelize';

import User from './User';

class Role extends Model {
  static init(connection) {
    super.init(
      {
        name: DataTypes.STRING,
        label: DataTypes.STRING,
      },
      {
        sequelize: connection,
        name: {
          singular: 'role',
          plural: 'roles',
        },
      },
    );

    return this;
  }

  static associate() {
    this.hasMany(User);
  }
}

export default Role;
