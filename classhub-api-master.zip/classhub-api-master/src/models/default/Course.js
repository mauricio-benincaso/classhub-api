import { Model, DataTypes } from 'sequelize';
import uuid from 'uuid-v4';

import Classroom from './Classroom';
import User from './User';
import UserCourse from './UserCourse';

class Course extends Model {
  static init(connection) {
    super.init(
      {
        title: DataTypes.STRING,
        thumbnail: DataTypes.STRING,
        description: DataTypes.STRING,
      },
      {
        sequelize: connection,
        name: {
          singular: 'course',
          plural: 'courses',
        },
      },
    );
    Course.beforeCreate((course, _) => {
      course.setDataValue('id', uuid());
    });

    return this;
  }

  static associate() {
    this.hasMany(Classroom);
    this.belongsToMany(User, {
      foreignKey: 'course_id',
      through: 'user_courses',
      as: 'users',
    });
  }
}
export default Course;
