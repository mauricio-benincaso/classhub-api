import { Model, DataTypes } from 'sequelize';
import uuid from 'uuid-v4';
import Caso from './Caso';
import MediaType from './MediaType';

class Media extends Model {
  static init(connection) {
    super.init(
      {
        url: DataTypes.STRING,
        thumbnail: DataTypes.STRING,
        name: DataTypes.STRING,
        caso_id: DataTypes.UUID,
        media_type_id: DataTypes.INTEGER,
      },
      {
        sequelize: connection,
        tableName: 'medias',
      },
    );

    Media.beforeCreate((media, _) => {
      return (media.id = uuid());
    });
    return this;
  }

  static associate() {
    this.belongsTo(MediaType, { foreignKey: 'media_type_id', as: 'mediatype' });
    this.belongsTo(Caso, { foreignKey: 'caso_id', as: 'caso' });
  }
}

export default Media;
