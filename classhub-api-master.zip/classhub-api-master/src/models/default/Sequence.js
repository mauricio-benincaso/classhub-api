import { Model, DataTypes } from 'sequelize';
import Caso from './Caso';
import Frame from './Frame'; 

import uuid from 'uuid-v4';

class Sequence extends Model {
  static init(connection) {
    super.init(
      {
        name: DataTypes.STRING,
        caso_id: DataTypes.UUID,
        order: DataTypes.INTEGER,
        ohif_server_response: DataTypes.JSON,
        ohif_parent_study_id: DataTypes.STRING
      },
      {
        sequelize: connection,
        name: {
          singular: 'sequence',
          plural: 'sequences',
        },
        scopes: {
          withCaso: {include: [{model: Caso}]}
        }
      },
    );

    Sequence.beforeCreate((sequence, _ ) => {
      return sequence.id = uuid();
    });

    return this;
  }

  
  static associate() {
    this.hasMany(Frame);
    this.belongsTo(Caso, { foreignKey: 'caso_id', as: 'caso' });
  }
}

export default Sequence;
