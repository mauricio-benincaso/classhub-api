import { Model, DataTypes } from 'sequelize';
import uuid from 'uuid-v4';

import Caso from './Caso';

class Task extends Model {
  static init(connection) {
    super.init(
      {
        name: DataTypes.STRING,
        description: DataTypes.TEXT,
        objective: DataTypes.TEXT,
        order: DataTypes.INTEGER,
        caso_id: DataTypes.UUID,
      },
      {
        sequelize: connection,
        name: {
          singular: 'task',
          plural: 'tasks',
        },
        scopes: {
          withCaso: { include: [{ model: Caso }] },
        },
      },
    );

    Task.beforeCreate((task, _) => {
      return (task.id = uuid());
    });

    return this;
  }

  static associate() {
    this.belongsTo(Caso, { foreignKey: 'caso_id', as: 'casos' });
  }
}

export default Task;
