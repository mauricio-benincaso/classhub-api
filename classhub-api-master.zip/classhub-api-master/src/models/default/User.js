import { DataTypes, Model } from 'sequelize';
import uuid from 'uuid-v4';
import { Course } from '.';
import { Token } from '..';
import { BcryptHelper } from '../../helpers';
import Classroom from './Classroom';
import Role from './Role';

class User extends Model {
  static init(connection) {
    super.init(
      {
        name: DataTypes.STRING,
        email: DataTypes.STRING,
        password: DataTypes.STRING,
        role_id: DataTypes.INTEGER,
        status: DataTypes.BOOLEAN,
        profile_picture: DataTypes.STRING,
        master: DataTypes.BOOLEAN,
      },

      {
        sequelize: connection,
        name: {
          singular: 'user',
          plural: 'users',
        },
        hooks: {
          beforeSave: instance => {
            if (instance.password) {
              instance.password = BcryptHelper.hash(instance.password);
            }
          },
        },
        scopes: {
          withoutPassword: {
            attributes: { exclude: ['password'] },
          },
        },
      },
    );

    User.beforeCreate((user, _) => {
      user.setDataValue('id', uuid());
    });

    return this;
  }

  static associate() {
    this.hasMany(Classroom);
    this.hasOne(Token);
    this.belongsTo(Role, { foreignKey: 'role_id', as: 'roles' });
    this.belongsToMany(Course, {
      foreignKey: 'user_id',
      through: 'user_courses',
      as: 'courses',
    });
  }

  validatePassword(password) {
    return BcryptHelper.compare(password, this.password);
  }
}

export default User;
