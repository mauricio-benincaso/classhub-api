import { Model, DataTypes } from 'sequelize';
import uuid from 'uuid-v4';

import Classroom from './Classroom';
import Media from './Media';
import Task from './Task';
import Sequence from './Sequence';

class Caso extends Model {
  static init(connection) {
    super.init(
      {
        name: DataTypes.STRING,
        description: DataTypes.TEXT,
        classroom_id: DataTypes.UUID,
      },
      {
        sequelize: connection,
        name: {
          singular: 'caso',
          plural: 'casos',
        },
        scopes: {
          withClassroom: { include: [{ model: Classroom }] },
        },
      },
    );

    Caso.beforeCreate((caso, _) => {
      return (caso.id = uuid());
    });
    return this;
  }

  static associate() {
    this.hasMany(Task);
    this.hasMany(Media);
    this.hasMany(Sequence);
    this.belongsTo(Classroom, { foreignKey: 'classroom_id', as: 'classrooms' });
  }
}

export default Caso;
