import { Model, DataTypes } from 'sequelize';
import Sequence from './Sequence';

import uuid from 'uuid-v4';

class Frame extends Model {
  static init(connection) {
    super.init(
      {
        sequence_id: DataTypes.UUID,
        data: DataTypes.TEXT,
        order: DataTypes.INTEGER,
        uri: DataTypes.TEXT,
      },
      {
        sequelize: connection,
      },
    );

    Frame.beforeCreate((frame, _ ) => {
      return frame.id = uuid();
    });
    return this;
  }

  static associate() {
    this.belongsTo(Sequence, { foreignKey: 'sequence_id', as: 'sequence' });
  }
}

export default Frame;
