import { Model, DataTypes } from 'sequelize';
import uuid from 'uuid-v4';

import User from './User';

class Token extends Model {
  static init(connection) {
    super.init(
      {
        token_code: DataTypes.UUID,
        user_id: DataTypes.UUID,
        token_expires: DataTypes.DATE,
      },
      {
        sequelize: connection,
        name: {
          singular: 'token',
          plural: 'tokens',
        },
        scopes: {
          withUser: { include: [{ model: User }] },
        },
      },
    );

    Token.beforeCreate((token, _) => {
      return (token.id = uuid());
    });
    return this;
  }

  static associate() {
    this.belongsTo(User, { foreignKey: 'user_id', as: 'users' });
  }
}

export default Token;
