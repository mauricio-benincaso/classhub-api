import { Model, DataTypes } from 'sequelize';
import uuid from 'uuid-v4';

import Caso from './Caso';
import Course from './Course';
import User from './User';

class Classroom extends Model {
  static init(connection) {
    super.init(
      {
        title: DataTypes.STRING,
        user_id: DataTypes.UUID,
        course_id: DataTypes.UUID,
        order: DataTypes.INTEGER,
        hash: DataTypes.STRING,
      },
      {
        sequelize: connection,
        name: {
          singular: 'classroom',
          plural: 'classrooms',
        },
        scopes: {
          withUser: { include: [{ model: User }] },
        },
      },
    );

    Classroom.beforeCreate((classroom, _) => {
      classroom.setDataValue('id', uuid());
    });

    return this;
  }

  static associate() {
    this.hasMany(Caso);
    this.belongsTo(User, { foreignKey: 'user_id', as: 'users' });
    this.belongsTo(Course, { foreignKey: 'course_id', as: 'courses' });
  }
}

export default Classroom;
