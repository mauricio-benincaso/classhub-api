import { DataTypes, Model } from 'sequelize';
import uuid from 'uuid-v4';
import Course from './Course';
import User from './User';

class UserCourse extends Model {
  static init(connection) {
    super.init(
      {
        id: {
          type: DataTypes.UUID,
          primaryKey: true,
        },
        user_id: DataTypes.UUID,
        course_id: DataTypes.UUID,
      },

      {
        sequelize: connection,
        name: {
          singular: 'user_course',
          plural: 'user_courses',
        },
      },
    );

    UserCourse.beforeCreate((user_course, _) => {
      // user_course.id = uuid();
      user_course.setDataValue('id', uuid());
      // return user_course.id;
    });

    return this;
  }
}

export default UserCourse;
