import { Model, DataTypes } from 'sequelize';

import uuid from 'uuid-v4';

class VideoLesson extends Model {
  static init(connection) {
    super.init(
    {
        title: DataTypes.STRING,
        url: DataTypes.STRING,
        thumbnail: DataTypes.STRING,
        user_id: DataTypes.UUID,
      },
      {
        sequelize: connection,
        name: {
          singular: 'videoLesson',
          plural: 'videoLessons',
        },
      },
    );

    VideoLesson.beforeCreate((videoLesson, _ ) => {
      return videoLesson.id = uuid();
    });

    return this;
  }

};

export default VideoLesson;
