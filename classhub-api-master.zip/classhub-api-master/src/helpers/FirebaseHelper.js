import * as firebaseAdmin from 'firebase-admin';
import uuid from 'uuid-v4';

import serviceAccountKey from '../config/google-service-account.json';

class FirebaseHelper {
  initialize() {
    firebaseAdmin.initializeApp({
      credential: firebaseAdmin.credential.cert(serviceAccountKey),
      storageBucket: 'rm-api-c344e.appspot.com',
    });
  }

  uploadFile(file, destination = null, fileName, contentType = 'image/jpeg') {
    return new Promise((resolve, reject) => {
      const finalPath = (destination ? `${destination}/` : '') + fileName;
      const token = uuid();
      const bucket = firebaseAdmin.storage().bucket();

      bucket
        .upload(file, {
          destination: finalPath,
          uploadType: 'media',
          metadata: {
            contentType,
            metadata: {
              firebaseStorageDownloadTokens: token,
            },
          },
        })
        .then(result => {
          const finalUrl = `https://firebasestorage.googleapis.com/v0/b/${
            bucket.name
          }/o/${encodeURIComponent(result[0].name)}?alt=media&token=${token}`;
          resolve(finalUrl);
        })
        .catch(e => {
          reject(e);
        });
    });
  }
}

export default new FirebaseHelper();
