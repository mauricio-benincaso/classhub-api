import dicomParser from 'dicom-parser';
import fs from 'fs';
import { AppError } from '../errors';

class DicomParserHelper {
  static dumpDataSet(instance) {
    const json = JSON.stringify(instance, undefined, 2);
    return json;
  }

  magicMaker(filePath) {
    // Invoke the paresDicom function and get back a DataSet object with the contents
    const file = fs.readFileSync(filePath);

    let dataSet;
    try {
      const start = new Date().getTime();
      dataSet = dicomParser.parseDicom(file);

      const options = {
        omitPrivateAttibutes: false,
        maxElementLength: 128,
      };

      const instance = dicomParser.explicitDataSetToJS(dataSet, options);

      // Here we call dumpDataSet to recursively iterate through the DataSet and create an array
      // of strings of the contents.

      const output = DicomParserHelper.dumpDataSet(instance);

      // Combine the array of strings into one string and add it to the DOM

      const end = new Date().getTime();
      const time = end - start;
      if (dataSet.warnings.length > 0) {
        //   console.log(
        //     ` 'Status: Warnings encountered while parsing file (parsed in ${time} ms)'`,
        //   );
        const arr = [];
        dataSet.warnings.forEach(function(warning) {
          arr.append(warning);
        });
      } else {
        const pixelData = dataSet.elements.x7fe00010;
        if (pixelData) {
          // console.log(`Status: Ready (parsed in ${time} ms)`);
        } else {
          // console.log(
          //   `Status: Ready - no pixel data found (parsed in ${time} ms)`,
          // );
        }
      }

      return output;
    } catch (e) {
      throw new AppError(`Não foi possivel criar o frame  ${e.toString()}`);
    }
  }
}

export default new DicomParserHelper();
