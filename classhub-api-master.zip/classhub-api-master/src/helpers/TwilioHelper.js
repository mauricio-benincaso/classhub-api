import twilio from 'twilio';

class TwilioHelper {
  constructor() {
    this.client = twilio(
      process.env.TWILIO_ACCOUNT_SID,
      process.env.TWILIO_AUTH_TOKEN,
    );
  }

  requestCode(to, channelConfiguration = null) {
    return new Promise((resolve, reject) => {
      this.client.verify
        .services(process.env.TWILIO_SERVICE_SID)
        .verifications.create(
          channelConfiguration
            ? { to, channel: 'email', channelConfiguration }
            : { to, channel: 'email' },
        )
        .then(result => {
          resolve(result);
        })
        .catch(error => {
          reject(error);
        });
    });
  }

  checkCode(to, code) {
    return new Promise((resolve, reject) => {
      this.client.verify
        .services(process.env.TWILIO_SERVICE_SID)
        .verificationChecks.create({ to, code })
        .then(result => {
          resolve(result);
        })
        .catch(error => {
          reject(error);
        });
    });
  }
}

export default new TwilioHelper();
