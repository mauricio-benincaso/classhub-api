import { Promise } from 'bluebird';
import uuid from 'uuid-v4';
import { AppError } from '../errors';
import { Caso, Classroom, Frame, Media, Sequence, Task } from '../models';

// helper to copy a classroom based on the given parameters
class ClassroomHelper {
  /**
   * @param {Classroom} classroom - object with the agregated data of the classroom
   * @param {string} user - the id of the user for whom the classroom is being copied
   * @param {string} course - the id of the course the classroom will be copied to
   * @returns {Promise<Classroom>} - the classroom with the new id
   */
  async copy(classroom, user, course) {
    const { user_id, casos, title, order } = classroom;
    const twilioHash = `${uuid()}_${user_id !== user ? user : user_id}`;

    const classroomData = {
      course_id: course,
      hash: twilioHash,
      user_id: user,
      order,
      title,
    };
    let createdClassroom;

    // if the classroom is going to be created for the same course for the same user add string '- copy' to the title
    if (classroom.course_id === course && user === user_id) {
      classroomData.title = `${classroom.title} - copy`;
    }

    // if the course already has a classroom with the same title, add string '- copy' to the title
    if (
      (await Classroom.findOne({
        where: {
          title: classroomData.title,
          course_id: course,
        },
      })) ||
      (await Classroom.findOne({
        where: {
          title: classroomData.title,
          course_id: classroomData.course_id,
        },
      }))
    ) {
      classroomData.title = `${classroomData.title} - copy`;
    }

    try {
      createdClassroom = await Classroom.create(classroomData);
    } catch (e) {
      throw new AppError('Falha ao copiar a aula', e.toString());
    }

    // create a copy of the casos and its contents
    if (casos) {
      Promise.map(casos, async caso => {
        let createdCaso;
        try {
          createdCaso = await Caso.create({
            name: caso.name,
            description: caso.description,
            classroom_id: createdClassroom.id,
          });
        } catch (e) {
          throw new AppError('Falha ao copiar o caso', e.toString());
        }
        // copy the tasks of the caso
        if (caso.tasks) {
          caso.tasks.map(async task => {
            try {
              await Task.create({
                name: task.name,
                description: task.description,
                order: task.order,
                objective: task.objective,
                caso_id: createdCaso.id,
              });
            } catch (e) {
              throw new AppError('Falha ao copiar a tarefa', e.toString());
            }
          });
        }
        // copy the medias of the caso
        if (caso.Media) {
          caso.Media.map(async media => {
            try {
              await Media.create({
                url: media.url ? media.url : '',
                caso_id: createdCaso.id,
                thumbnail: media.thumbnail ? media.thumbnail : '',
                media_type_id: media.media_type_id ? media.media_type_id : 1,
              });
            } catch (e) {
              throw new AppError('Falha ao copiar a mídia', e.toString());
            }
          });
        }
        // copy the sequences and frames for each caso
        if (caso.sequences) {
          caso.sequences.map(async sequence => {
            let createdSequence;
            try {
              createdSequence = await Sequence.create({
                name: sequence.name,
                caso_id: createdCaso.id,
                order: sequence.order,
              });
            } catch (e) {
              throw new AppError('Falha ao copiar a sequência', e.toString());
            }
            // copy the frames of the sequence
            if (sequence.Frames) {
              sequence.Frames.map(async frame => {
                try {
                  await Frame.create({
                    sequence_id: createdSequence.id,
                    order: frame.order,
                    data: frame.data,
                    uri: frame.uri,
                  });
                } catch (e) {
                  throw new AppError(
                    'Falha ao copiar a sequência',
                    e.toString(),
                  );
                }
              });
            }
          });
        }
      }).catch(e => {
        throw new AppError('Falha ao copiar os casos', e.toString());
      });
    }
  }
}

export default new ClassroomHelper();
