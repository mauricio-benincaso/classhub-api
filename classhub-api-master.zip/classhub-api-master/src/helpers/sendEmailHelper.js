const nodemailer = require('nodemailer');
const handlebars = require('handlebars');
const fs = require('fs');
const path = require('path');

const sendEmailHelper = async (email, subject, payload, template) => {

  try {

    const source = fs.readFileSync(path.join(__dirname, template), 'utf8');
    const compiledTemplate = handlebars.compile(source);
  
    return new Promise((resolve, reject) => {
      const transport = nodemailer.createTransport({
        host: process.env.EMAIL_HOST,
        port: process.env.EMAIL_PORT,
        auth: {
          user: process.env.EMAIL_USER,
          pass: process.env.EMAIL_PASSWORD,
        },
      });
  
      const options = () => {
        return {
          from: process.env.FROM_EMAIL,
          to: email,
          subject: `${process.env.CLIENT_NAME} - Recuperar senha`,
          html: compiledTemplate(payload),
        };
      };
  
      transport
        .sendMail(options())
        .then(info => {
          console.log(`✅ Email send: ${info.messageId}`);
          resolve({
            statusCode: 200,
            log: "",
          });
        })
        .catch(error => {
          console.log(`🚨 sendMailError: \n${JSON.stringify(error)}\n`);
          reject({
            statusCode: 500,
            log: JSON.stringify(error),
          });
        });
    });
    
  } catch (error) {
    console.log(`🚨 sendEmailHelper: \n${JSON.stringify(error)}\n`);
    return {
      status: 500,
      log: JSON.stringify(error),
    };
  }

};

module.exports = sendEmailHelper;
