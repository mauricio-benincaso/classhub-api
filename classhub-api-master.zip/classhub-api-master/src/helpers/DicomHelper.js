import fs from 'fs';
import dcmjs from 'dcmjs';
import dicomParser from 'dicom-parser';
import axios from 'axios';

// Setting a default UID Root value
// http://dicom.nema.org/dicom/2013/output/chtml/part05/chapter_9.html
// http://dicom.nema.org/dicom/2013/output/chtml/part05/chapter_B.html

const countryCodeMemberBody = "076";
const organizationID = "99104"; // Convert "ch" to decimal: https://onlinestringtools.com/convert-string-to-decimal
const defaultUIDRoot = "1.2." + countryCodeMemberBody + "." + organizationID;
const orthancIdentifiers = [
  {
    "tag": "x00100020",
    "keyword": "PatientID",
  },
  {
    "tag": "x0020000d",
    "keyword": "StudyInstanceUID",
  },
  {
    "tag": "x0020000e",
    "keyword": "SeriesInstanceUID",
  },
  {
    "tag": "x00080018",
    "keyword": "SOPInstanceUID",
  },
];
const DICOM_SERVER_AUTH = `${process.env.DICOM_SERVER_USER}:${process.env.DICOM_SERVER_PASSWORD}`;
const DICOM_SERVER_AUTH_BASE64 = Buffer.from(DICOM_SERVER_AUTH).toString('base64');

class DicomHelper {

  createUIDSufixFromDicomPath(dicomPath) {
    try {

      // Read Dicom
      let arrayBuffer = fs.readFileSync(dicomPath).buffer;
      let dicomDict = dcmjs.data.DicomMessage.readFile(arrayBuffer);
      let dataSet = dcmjs.data.DicomMetaDictionary.naturalizeDataset(dicomDict.dict);

      // Create a default UID Sufix from SeriesInstanceUID
      let defaultUIDSufix = dataSet.SeriesInstanceUID.split('');

      // Remove all '.' from array
      defaultUIDSufix.forEach((sufix, index) => {
        if (sufix == '.') {
          defaultUIDSufix.splice(index, 1);
        }
      });

      // Check if array length is 24
      let difference = 24 - defaultUIDSufix.length;

      if (difference < 0) {
        defaultUIDSufix.splice(Math.abs(difference), Math.abs(difference));
      }
      if (difference > 0) {

        while (difference) {
          let nextSufix = (parseInt(defaultUIDSufix[difference]) + 1).toString();
          defaultUIDSufix.push(nextSufix);
          difference--;
        }

      }

      // Basic crypt numbers 
      defaultUIDSufix.forEach((sufix, index) => {
        if (parseInt(sufix) < 9) {
          const cryptSufix = parseInt(sufix) + 1;
          defaultUIDSufix[index] = cryptSufix;
        } else {
          defaultUIDSufix[index] = 1;
        }
      });

      // Convert sufix list to string
      defaultUIDSufix = defaultUIDSufix.join("");

      return defaultUIDSufix;

    } catch (createUIDSufixError) {
      console.log("\ncreateUIDSufixError: ", createUIDSufixError);
      return {
        "error": createUIDSufixError,
      };
    }
  }

  createUIDSufixFromCasoId(casoId) {
    try {

      let uidSufix = casoId.split('-').join('').split('');
      
      // Check if array length is 24
      let difference = 24 - uidSufix.length;
      
      if (difference < 0) {
        uidSufix.splice(0, Math.abs(difference));
      }
      if (difference > 0) {
        
        while (difference) {
          let nextSufix = uidSufix[difference] + "1";
          uidSufix.push(nextSufix);
          difference--;
        }
        
      }

      // Convert sufix list to string
      uidSufix = uidSufix.join("");

      return uidSufix;

    } catch (createUIDSufixError) {
      console.log("\ncreateUIDSufixError: ", createUIDSufixError);
      return {
        "error": createUIDSufixError,
      };
    }
  }

  createDefaultUID(dicomPath) {
    try {

      return defaultUIDRoot + "." + this.createUIDSufixFromDicomPath(dicomPath);

    } catch (createUIDError) {
      console.log("\ncreateUIDError: ", createUIDError);
      return {
        "error": createUIDError,
      }
    }
  }

  createPatientID(defaultUID) {

    try {

      let uid = defaultUID.split('.');
      let patientID = uid[uid.length - 1].split('');
      
      // Check if array length is 6
      let difference = 6 - patientID.length;

      if (difference < 0) {
        patientID.splice(0, Math.abs(difference));
      }
      if (difference > 0) {
        while (difference) {
          let nextSufix = (parseInt(patientID[difference]) + 1).toString();
          patientID.push(nextSufix);
          difference--;
        }
      }

      patientID = patientID.join('');

      return patientID;
      
    } catch (createPatientIDError) {
      console.log("\ncreatePatientIDError: ", createPatientIDError);
      return {
        "error": createPatientIDError,
      };
    }

  }

  createSeriesInstanceUID(defaultUID) {
    try {

      let uid = defaultUID.split('.');
      let uidSufix = uid[uid.length - 1].split('');
      uidSufix[uidSufix.length - 1] = uidSufix[uidSufix.length - 2];

      let seriesInstanceUID = uid.splice(0, 4).join('.') + '.' + uidSufix.join('');

      return seriesInstanceUID;

    } catch (createSeriesInstanceUIDError) {

      console.log("\ncreateSeriesInstanceUIDError: ", createSeriesInstanceUIDError);
      return {
        "error": createSeriesInstanceUIDError,
      };

    }
  }

  createSOPInstanceUID(defaultUID) {
    try {

      let uid = defaultUID.split('.');
      let uidSufix = uid[uid.length - 1].split('');
      uidSufix[uidSufix.length - 1] = uidSufix[uidSufix.length - 3];

      let sopInstanceUID = uid.splice(0, 4).join('.') + '.' + uidSufix.join('');

      return sopInstanceUID;

    } catch (createSOPInstanceUIDError) {

      console.log("\ncreateSOPInstanceUIDError: ", createSOPInstanceUIDError);
      return {
        "error": createSOPInstanceUIDError,
      };

    }
  }

  checkOrthancIdentifiersExist(dicomPath) {

    try {

      // Read Dicom
      let arrayBuffer = fs.readFileSync(dicomPath).buffer;
      let dicomDict = dcmjs.data.DicomMessage.readFile(arrayBuffer);
      let dataSet = dcmjs.data.DicomMetaDictionary.naturalizeDataset(dicomDict.dict);

      // Check if all identifiers exist
      if (
        dataSet.PatientID == undefined ||
        dataSet.StudyInstanceUID == undefined ||
        dataSet.SeriesInstanceUID == undefined ||
        dataSet.SOPInstanceUID == undefined
      ) {
        return this.checkOrthancIdentifiersExistDetails(dicomPath);
      }

      return true;
    
    } catch (checkOrthancIdentifiersError) {
      console.log("\ncheckOrthancIdentifiersError: ", checkOrthancIdentifiersError);
      return {
        "error": checkOrthancIdentifiersError,
      };

    }

  }

  checkOrthancIdentifiersExistDetails(dicomPath) {
    try {

      let dicomFileAsBuffer = fs.readFileSync(dicomPath);
      let dataSet = dicomParser.parseDicom(dicomFileAsBuffer);
      
      orthancIdentifiers.map((element, index) => {

        let tag = dataSet.string(element.tag);
        orthancIdentifiers[index]["value"] = tag;

      });

      return orthancIdentifiers;
    
    } catch (error) {
      console.log("\ncheckOrthancIdentifiersDetails_error: ", error);
      return {
        "error": error,
      };
    }
  }

  anonymizerDicom(dicomPath, caso) {
    try {
      
      // Read Dicom
      let arrayBuffer = fs.readFileSync(dicomPath).buffer;
      let dicomDict = dcmjs.data.DicomMessage.readFile(arrayBuffer);
      let dataSet = dcmjs.data.DicomMetaDictionary.naturalizeDataset(dicomDict.dict);
      const defaultUID = defaultUIDRoot + '.' + this.createUIDSufixFromCasoId(caso.id);
    
      // Create Orthanc Identifiers
      if (dataSet.StudyInstanceUID == undefined) {
        dataSet.StudyInstanceUID = defaultUID;
      }
      if (dataSet.SeriesInstanceUID == undefined) {
        dataSet.SeriesInstanceUID = this.createSeriesInstanceUID(defaultUID);
      }
      if (dataSet.SOPInstanceUID == undefined) {
        dataSet.SOPInstanceUID = this.createSOPInstanceUID(defaultUID);
      }
      // if (dataSet.PatientID == undefined) {
      //   dataSet.PatientID = this.createPatientID(defaultUID);
      // }

      // Anonymizer - Anothers Tags
      dataSet.PatientID = caso.id.replace(/[^0-9a-zA-Z ]/g, '') + "1";
      dataSet.StudyID = (
        caso.id.split('-')[4] + 
        caso.id.split('-')[3] + 
        caso.id.split('-')[3] + 
        caso.id.split('-')[2] + 
        caso.id.split('-')[1] + 
        caso.id.split('-')[0]
      );
      dataSet.PatientName = caso.name;
      dataSet.StudyDate = caso.dateFormated;
      dataSet.SeriesDate = caso.dateFormated;
      dataSet.ContentDate = caso.dateFormated;
      dataSet.AcquisitionDate = caso.dateFormated;
      dataSet.PatientBirthDate = caso.dateFormated;
      dataSet.InstitutionName = "ClassHub";
      dataSet.InstitutionAddress = "classhub.com.br";
      dataSet.InstitutionCodeSequence = organizationID;
      dataSet.ReferringPhysicianName = "ClassHub";
      
      // Save Dicom on Array Buffer
      dicomDict.dict = dcmjs.data.DicomMetaDictionary.denaturalizeDataset(dataSet);
      let new_file_WriterBuffer = dicomDict.write();
      fs.writeFileSync(dicomPath, Buffer.from(new_file_WriterBuffer));
      
    } catch (createOrthancIdentifiersError) {
      console.log("\ncreateOrthancIdentifiersError: ", createOrthancIdentifiersError);
      return {
        "error": createOrthancIdentifiersError 
      };
    }
  }

  async requestOrthancPatient(dicomPatientID) {
    try {

      // Config
      const config = {
        method: 'POST',
        url: process.env.DICOM_SERVER_URL + 'tools/lookup',
        headers: { 
          'Authorization': `Basic ${DICOM_SERVER_AUTH_BASE64}`,
          'Content-Type': 'text/plain'
        },
        data: dicomPatientID
      };

      // Request
      const patientID = await axios(config)
      .then((response) => {
        return response.data[0];
      }).catch(error => {
        console.log("\nRequest failed:", error);
        return false;
      });

      return patientID;
      
    } catch (error) {
      console.log("\ngetOrthancIDByTagValue_error: ", error);
      return {
        "error": error
      };
    }
  }

  async getOrthancStudy(orthancPatientID) {
    try {

      // Config
      const config = {
        method: 'GET',
        url: process.env.DICOM_SERVER_URL + 'patients/' + orthancPatientID + '/studies',
        headers: { 
          'Authorization': `Basic ${DICOM_SERVER_AUTH_BASE64}`,
          'Content-Type': 'text/plain'
        }
      };

      // Request
      const study = await axios(config)
      .then((response) => {
        return response.data[0]; 
      }).catch(error => {
        console.log("\nRequest failed:", error);
        return false;
      });

      return study;
      
    } catch (error) {
      console.log("\ngetOrthancStudyIDError", error);
      return {
        "error": error
      };
    }
  }

  async deleteOrthancPatient(orthancPatientID) {
    try {

      // Config
      const config = {
        method: 'delete',
        url: process.env.DICOM_SERVER_URL + 'patients/' + orthancPatientID,
        headers: { 
          'Authorization': `Basic ${DICOM_SERVER_AUTH_BASE64}`,
        },
        data: ''
      };

      const deleted = await axios(config)
      .then(response => {
        return response.data;
      }).catch(error => {
        console.log("\nDelete request failed:", error);
        return false;
      });

      return deleted;

    } catch (error) {
      console.log("\ndeleteOrthancPacient: ", error);
      throw error;
    }
  }

  async editOrthancPatient(orthancPatientID, tags = {}) {
    try {

      const data = JSON.stringify({
        "Replace": tags,
        "Force": true
      });

      // Config
      const config = {
        method: 'POST',
        url: process.env.DICOM_SERVER_URL + 'patients/' + orthancPatientID + '/modify',
        headers: { 
          'Authorization': `Basic ${DICOM_SERVER_AUTH_BASE64}`,
          'Content-Type': 'application/json'
        },
        data: data
      };

      // Request
      const edited = await axios(config)
      .then((response) => {
        return response.data;
      }).catch(error => {
        console.log("\nRequest failed:", error);
        return false;
      });

      return edited;

    } catch (error) {
      console.log("\neditOrthancPatientError: ", error);
      return {
        "error": error
      };
    }
  }

  async anonymizerDicomByOrthancPatientID(orthancPatientID, caso) {
    try {
      
      // Anonymizer and Edit Patient
      const newTags = {
        "PatientName": caso.name + " - Anonymized",
        "PatientBirthDate": caso.dateFormated,
        "PatientID": caso.id.replace(/[^0-9a-zA-Z ]/g, ''),
      };
      
      const anonymized = await this.editOrthancPatient(orthancPatientID, newTags);

      // Delete Old Patient
      await this.deleteOrthancPatient(orthancPatientID);

      return anonymized;

    } catch (error) {
      console.log("\nanonymizerDicomByOrthancPatientIDError: ", error);
      return {
        "error": error
      };
    }
  }

  checkIfFileIsDicom(dicomPath) {

    try {

      // Read Dicom
      let arrayBuffer = fs.readFileSync(dicomPath).buffer;
      let dicomDict = dcmjs.data.DicomMessage.readFile(arrayBuffer);
      let dataSet = dcmjs.data.DicomMetaDictionary.naturalizeDataset(dicomDict.dict);

      return true;
    
    } catch (checkIfFileIsDicomError) {
      console.log(`⚠️ Error: checkIfFileIsDicom.\n${checkIfFileIsDicomError}`);
      return false;
    }

  }

}

export default new DicomHelper();
