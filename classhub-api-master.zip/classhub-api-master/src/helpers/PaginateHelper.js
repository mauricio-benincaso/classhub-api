class PaginateHelper {
  paginate(page, pageSize) {
    if (page == null) {
      page = 1;
    }
    if (pageSize == null) {
      pageSize = 10;
    }

    const offset = (page - 1) * pageSize;
    const limit = pageSize;
    return { offset, limit };
  }

  getTotalPages(elementsQuantity, pageSize) {
    const total_pages =
      pageSize > elementsQuantity ? 1 : Math.ceil(elementsQuantity / pageSize);
    return total_pages;
  }
}

export default new PaginateHelper();
