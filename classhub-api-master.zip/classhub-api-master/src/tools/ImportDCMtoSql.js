import util from 'util';
import child_process from 'child_process';

class ImportDCMtoSql {
  async execute() {
    const exec = util.promisify(child_process.exec);

    try {
      await exec('yarn dicom:import');

      console.log('Sucesso ao importar os DCMs');
    } catch (error) {
      throw error;
    }
  }
}

export default new ImportDCMtoSql();
