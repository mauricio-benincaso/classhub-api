import dotenv from 'dotenv';
import path from 'path';
import util from 'util';
import child_process from 'child_process';
import { v4 as uuidv4 } from 'uuid';

dotenv.config();
class ConvertToJpeg {
  async execute(pathToFile) {
    const exec = util.promisify(child_process.exec);
    const outputPath = `${path.resolve(__dirname, '..', 'tmp', 'conversions')}`;
    const fileName = uuidv4();

    try {
      await exec(
        `${process.env.PYTHON_TYPE} ./Dcm_to_Img_Single.py -i ${path.resolve(
          __dirname,
          '..',
          'tmp',
          'decompresseds',
          pathToFile,
        )} -o ${outputPath} -f ${fileName}`,
      );

      return path.resolve(outputPath, `${fileName}.jpg`);
    } catch (e) {
      throw e;
    }
  }
}

export default new ConvertToJpeg();
