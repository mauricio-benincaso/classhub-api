const multerConfig = require('./multer');
const defaultDatabaseConfig = require('./databases/default');
module.exports = {
  defaultDatabaseConfig,
  multerConfig,
};
