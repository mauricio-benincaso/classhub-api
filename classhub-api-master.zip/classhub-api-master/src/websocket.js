import { io } from './http';

// All lists follow this object pattern

// {
//   "roomSid": String,
//   "participant": Object,
//   "date": String,
// }

let teachersRequests = [];
let classroomsScreens = [];
let classroomsScreensPending = [];
let classroomsScreensAuthorized = [];
let classroomsScreensNotAuthorized = [];

const checkIfTeacher = (participant) => {

  if (participant.identity.startsWith('[PROF')) {
    return true;
  } else {
    return false;
  }

}

const checkIfParticipantExists = (list, roomSid, participant) => {
  if (list.length > 0) {

    let exist = [];

    list.map((item, index) => {
      if (
        item.roomSid === roomSid &&
        item.participant.sid === participant.sid
      ) {
        exist.push(index);
      }
    });

    if (exist.length > 0) {
      return exist;
    } else {
      return false;
    }

  } else {
    return false;
  }
}

const checkIfRoomExists = (list, roomSid) => {
  if (list.length > 0) {

    let exist = [];

    list.map((item, index) => {
      if ( item.roomSid == roomSid ) {
        exist.push(index);
      }
    });

    if (exist.length > 0) {
      return exist;
    } else {
      return false;
    }

  } else {
    return false;
  }
}

const addItem = (list, roomSid, participant) => {

  let alreadyExists = list.filter((item, index) => {
    if (
      item.roomSid === roomSid &&
      item.participant.sid === participant.sid
    ) {
      return index;
    }
  });

  if (alreadyExists.length > 0) {
    list[alreadyExists[0]] = {
      "roomSid": roomSid,
      "participant": participant,
      "date": getDateNow(),
    }
  } else {
    list.push({
      "roomSid": roomSid,
      "participant": participant,
      "date": getDateNow(),
    });
  }

  return list;
}

const filterRoom = (list, roomSid) => {
  if (list.length > 0) {

    const listNew = list.filter((item) => {
      if (roomSid !== item.roomSid) {
        return item;
      }
    });

    return listNew;
  }

  return list;
}

const filterParticipant = (list, roomSid, participant) => {
  if (list.length > 0) {

    const listNew = list.filter((item) => {
      if (
        roomSid !== item.roomSid ||
        participant.sid !== item.participant.sid
      ) {
        return item;
      }
    });

    return listNew;
  }

  return list;
}

const getDateNow = () => {

  const today = new Date();
  const yyyy = today.getFullYear();
  let mm = today.getMonth() + 1; // Months start at 0!
  let dd = today.getDate();

  if (dd < 10) dd = '0' + dd;
  if (mm < 10) mm = '0' + mm;

  const dateNow = `${yyyy}/${mm}/${dd}`;

  return dateNow;

}

io.on('connection', (socket) => {

  // Main

  console.log('✅ [Socket] Client connected: ', socket.id);

  socket.on('disconnect', () => {
    console.log('✂️ Client disconnected', socket.id);
  });

  // Classrooms Screens

  socket.on('addClassroomScreen', (roomSid, participant) => {

    console.log(`[Socket] ${socket.id} request addClassroomScreen`);

    if (checkIfTeacher(participant)) {

      classroomsScreens = addItem(classroomsScreens, roomSid, participant);
      io.emit('classroomsScreens', classroomsScreens);

    } else {

      const onAuthorized = checkIfParticipantExists(classroomsScreensAuthorized, roomSid, participant);

      if (onAuthorized) {

        classroomsScreens = addItem(classroomsScreens, roomSid, participant);
        io.emit('classroomsScreens', classroomsScreens);

      } else {

        const onPending = checkIfParticipantExists(classroomsScreensPending, roomSid, participant);

        if (!onPending) {
          classroomsScreensPending = addItem(classroomsScreensPending, roomSid, participant);
          io.emit('classroomsScreensPending', classroomsScreensPending);
        }
      }
    }
  });

  socket.on('delClassroomScreen', (roomSid, participant) => {

    console.log(`[Socket] ${socket.id} request delClassroomScreen`);

    const onClassroomsScreens = checkIfRoomExists(classroomsScreens, roomSid);

    if (onClassroomsScreens !== false && participant !== null) {

      const classroomScreen = classroomsScreens[onClassroomsScreens[0]];

      if (
        classroomScreen.participant.sid == participant.sid ||
        checkIfTeacher(participant)
      ) {

        classroomsScreens = filterRoom(classroomsScreens, roomSid);
        io.emit('classroomsScreens', classroomsScreens);

        teachersRequests = filterParticipant(teachersRequests, roomSid, participant);
        io.emit('teachersRequests', teachersRequests);

        classroomsScreensPending = filterParticipant(classroomsScreensPending, roomSid, participant);
        io.emit('classroomsScreensPending', classroomsScreensPending);

        classroomsScreensAuthorized = filterParticipant(classroomsScreensAuthorized, roomSid, participant);
        io.emit('classroomsScreensAuthorized', classroomsScreensAuthorized);

        classroomsScreensNotAuthorized = filterParticipant(classroomsScreensNotAuthorized, roomSid, participant);
        io.emit('classroomsScreensNotAuthorized', classroomsScreensNotAuthorized);

      }
    }

  });

  // Pending

  socket.on('getClassroomsScreensPending', () => {

    console.log(`[Socket] ${socket.id} request getClassroomsScreensPending`);
    io.emit('classroomsScreensPending', classroomsScreensPending);

  });

  socket.on('delClassroomScreenPending', (roomSid, participant) => {

    console.log(`[Socket] ${socket.id} request delClassroomScreenPending`);

    classroomsScreensPending = filterParticipant(classroomsScreensPending, roomSid, participant);
    io.emit('classroomsScreensPending', classroomsScreensPending);

  });

  // Not Authorized

  socket.on('addClassroomScreenNotAuthorized', (roomSid, participant) => {

    console.log(`[Socket] ${socket.id} request addClassroomScreenNotAuthorized`);

    if (classroomsScreensNotAuthorized.length > 0) {

      classroomsScreensNotAuthorized = addItem(classroomsScreensNotAuthorized, roomSid, participant);
      io.emit('classroomsScreensNotAuthorized', classroomsScreensNotAuthorized);

      // classroomsScreensNotAuthorized.map((participantInner) => {
      //   if (participantInner.sid == participant.sid) {
      //     classroomsScreensNotAuthorized.push(participant);
      //     io.emit('classroomsScreensNotAuthorized', classroomsScreensNotAuthorized);
      //   }
      // });

    } else {
      classroomsScreensNotAuthorized.push({
        "roomSid": roomSid,
        "participant": participant,
        "date": getDateNow(),
      })
      io.emit('classroomsScreensNotAuthorized', classroomsScreensNotAuthorized);
    }

  });

  socket.on('delClassroomScreenNotAuthorized', (roomSid, participant) => {

    console.log(`[Socket] ${socket.id} request delClassroomScreenNotAuthorized`);

    classroomsScreensNotAuthorized = filterParticipant(classroomsScreensNotAuthorized, roomSid, participant);
    io.emit('classroomsScreensNotAuthorized', classroomsScreensNotAuthorized);

  });

  // Authorized

  socket.on('addClassroomScreenAuthorized', (roomSid, participant) => {

    console.log(`[Socket] ${socket.id} request addClassroomScreenAuthorized`);

    if (classroomsScreensAuthorized.length > 0) {

      const onAuthorized = checkIfParticipantExists(classroomsScreensAuthorized, roomSid, participant);

      if (!onAuthorized) {
        classroomsScreensAuthorized = addItem(classroomsScreensAuthorized, roomSid, participant);
        io.emit('classroomsScreens', classroomsScreens);
      }

    } else {
      classroomsScreensAuthorized.push({
        "roomSid": roomSid,
        "participant": participant,
        "date": getDateNow(),
      });
    }

    io.emit('classroomsScreensAuthorized', classroomsScreensAuthorized);

  });

  socket.on('delClassroomScreenAuthorized', (roomSid, participant) => {

    console.log(`[Socket] ${socket.id} request delClassroomScreenAuthorized`);

    classroomsScreensAuthorized = filterParticipant(classroomsScreensAuthorized, roomSid, participant);
    io.emit('classroomsScreensAuthorized', classroomsScreensAuthorized);

  });

  // Teachers Requests

  socket.on('addTeacherRequests', (roomSid, participant) => {

    console.log(`[Socket] ${socket.id} request addTeacherRequests`);

    if (teachersRequests.length > 0) {

      const requested = checkIfParticipantExists(teachersRequests, roomSid, participant);

      if (!requested) {

        teachersRequests = addItem(teachersRequests, roomSid, participant);
        const authorized = checkIfParticipantExists(classroomsScreensAuthorized, roomSid, participant);

        if (!authorized) {
          classroomsScreensAuthorized = addItem(classroomsScreensAuthorized, roomSid, participant);
          io.emit('classroomsScreensAuthorized', classroomsScreensAuthorized);
        }
      }

    } else {
      teachersRequests.push({
        "roomSid": roomSid,
        "participant": participant,
        "date": getDateNow(),
      });
    }

    io.emit('teachersRequests', teachersRequests);

  });

  socket.on('delTeacherRequests', (roomSid, participant) => {

    console.log(`[Socket] ${socket.id} request delTeacherRequests`);

    teachersRequests = filterParticipant(teachersRequests, roomSid, participant);
    io.emit('teachersRequests', teachersRequests);

  });


});
