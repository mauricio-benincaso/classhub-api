import { check, param } from 'express-validator';

import { VideoLesson } from '../models';

const videoLessonMiddleware = {
  storeRules: [
    check('title')
      .exists()
      .isString()
      .withMessage('Insira um titulo válido')
      .isLength({ min: 4, max: 255 })
      .withMessage('Insira um título válido entre 4 e 255 caracteres'),
  ],

  updateRules: [
    check('title')
      .exists()
      .isString()
      .withMessage('Insira um titulo válido')
      .isLength({ min: 4, max: 255 })
      .withMessage('Insira um título válido entre 4 e 255 caracteres'),
    check('id')
      .custom(id => {
        return new Promise((resolve, reject) => {
          VideoLesson.count({ where: { id } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('O vídeo não existe em nosso banco de dados.'),
  ],

  destroyRules: [
    check('id')
      .custom(id => {
        return new Promise((resolve, reject) => {
          VideoLesson.count({ where: { id } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('O vídeo informado não existe em nosso banco de dados.'),
  ],

  showRules: [
    check('id')
      .custom(id => {
        return new Promise((resolve, reject) => {
          VideoLesson.count({ where: { id } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('O vídeo informado não existe em nosso banco de dados.'),
  ],
};

export default videoLessonMiddleware;
