import { validationResult } from 'express-validator';
import AppError from '../errors/AppError';

const expressValidatorMiddleware = {
  result: (req, res, next) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      throw new AppError(
        'Verifique os dados informados e tente novamente.',
        errors.array(),
      );
    }
    return next();
  },
};

export default expressValidatorMiddleware;
