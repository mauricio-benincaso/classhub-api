import { check } from 'express-validator';

const authVerifyRecoverCodeMiddleware = {
  storeRules: [
    check('email')
      .exists()
      .withMessage('Informe o seu email.')
      .isEmail()
      .withMessage('Informe um email válido'),
    check('code')
      .exists()
      .withMessage('Informe o código de verificação.')
      .isLength({ min: 4, max: 4 })
      .withMessage('O código possui deve ter 4 caracteres.'),
  ],
};

export default authVerifyRecoverCodeMiddleware;
