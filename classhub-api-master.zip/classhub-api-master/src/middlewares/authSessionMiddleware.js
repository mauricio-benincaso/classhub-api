import { check } from 'express-validator';

const authSessionMiddleware = {
  storeRules: [
    check('email')
      .exists()
      .withMessage('Informe o seu email.')
      .isEmail()
      .withMessage('Informe um email válido'),
    check('password')
      .exists()
      .withMessage('Informe a sua senha.')
      .isLength({ min: 4, max: 16 })
      .withMessage('A sua senha deve ter entre 4 e 16 caracteres.'),
  ],
};

export default authSessionMiddleware;
