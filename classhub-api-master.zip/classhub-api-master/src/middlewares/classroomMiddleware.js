import { response } from 'express';
import { check, checkSchema, param } from 'express-validator';
import { AppError } from '../errors';

import { Classroom } from '../models';

const classroomMiddleware = {
  storeRules: [
    check('title')
      .exists()
      .isString()
      .withMessage('Insira um título válido')
      .isLength({ min: 4, max: 255 })
      .withMessage('Insira um título válido entre 4 e 255 caracteres'),
  ],

  updateRules: [
    check('title')
      .exists()
      .isString()
      .withMessage('Insira um título válido')
      .isLength({ min: 4, max: 255 })
      .withMessage('Insira um título válido entre 4 e 255 caracteres'),
    check('id')
      .custom(id => {
        return new Promise((resolve, reject) => {
          Classroom.count({ where: { id } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('A aula não existe em nosso banco de dados.')
      .custom(async (classroom_id, { req }) => {
        return new Promise(async (resolve, reject) => {
          const classroom = await Classroom.findOne({
            where: {
              user_id: req.body.teacher_id ? req.body.teacher_id : req.user_id,
            },
            attributes: ['user_id'],
          });
          if (classroom) {
            if (req.body.teacher_id === classroom.user_id) {
              resolve();
            } else if (req.user_id === classroom.user_id) {
              resolve();
            } else {
              reject();
            }
          } else {
            reject();
          }
        });
      })
      .withMessage(
        'Você não tem permissão para atualizar esse conteúdo ou não está enviando os dados do professor corretamente',
      ),
  ],

  destroyRules: [
    check('id')
      .custom(id => {
        return new Promise((resolve, reject) => {
          Classroom.count({ where: { id } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('A aula não existe em nosso banco de dados.')
      .custom(async (classroom_id, { req }) => {
        return new Promise(async (resolve, reject) => {
          const classroom = await Classroom.findOne({
            where: { id: classroom_id },
          });

          if (classroom) {
            resolve();
          } else {
            reject();
          }
        });
      })
      .withMessage('Você não tem permissão para deletar esse conteúdo'),
  ],

  showRules: [
    check('id')
      .exists()
      .withMessage('Informe o ID da aula para acessar seu conteúdo.')
      .isUUID()
      .withMessage('Informe um ID válido para acessar o conteúdo.'),
  ],
};

export default classroomMiddleware;
