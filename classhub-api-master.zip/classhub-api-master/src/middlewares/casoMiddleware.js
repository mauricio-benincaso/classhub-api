import { check } from 'express-validator';

import { Caso, Classroom } from '../models';

const casoMiddleware = {
  storeRules: [
    check('name')
      .exists()
      .isString()
      .withMessage('Insira um nome válido')
      .isLength({ min: 4, max: 255 })
      .withMessage('Insira um nome válido entre 4 e 255 caracteres'),
    check('classroom_id')
      .exists()
      .withMessage('Informe o identificador da aula.')
      .custom(classroomId => {
        return new Promise((resolve, reject) => {
          Classroom.count({ where: { id: classroomId } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('A aula informada não existe em nosso banco de dados.'),
  ],

  destroyRules: [
    check('id')
      .custom(id => {
        return new Promise((resolve, reject) => {
          Caso.count({ where: { id } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('O caso informado não existe em nosso banco de dados.')
      .custom(async (user_id, { req }) => {
        return new Promise(async (resolve, reject) => {
          if (req.user_id == user_id) {
            resolve();
          } else {
            reject();
          }
        });
      })
      .withMessage('Você não tem permissão para acessar esse conteúdo'),
  ],

  updateRules: [
    check('name')
      .exists()
      .isString()
      .withMessage('Insira um nome válido')
      .isLength({ min: 4, max: 255 })
      .withMessage('Insira um nome válido entre 4 e 255 caracteres'),
    check('description')
      .exists()
      .isString()
      .isLength({ min: 4 })
      .withMessage('Insira uma descrição válida'),
    check('id')
      .custom(id => {
        return new Promise((resolve, reject) => {
          Caso.count({ where: { id } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('O caso informado não existe em nosso banco de dados.')
      .custom(async (user_id, { req }) => {
        return new Promise(async (resolve, reject) => {
          if (req.user_id == user_id) {
            resolve();
          } else {
            reject();
          }
        });
      })
      .withMessage('Você não tem permissão para acessar esse conteúdo'),
  ],

  /**
   * [
   *     {
   *         'name': STRING,
   *         'files:' Array of Files (.pdf, .jpeg, .jpg, .png ou .mp4)
   *     }
   * ]
   */
  uploadMediaRules: [
    check('id')
      .custom(id => {
        return new Promise((resolve, reject) => {
          Caso.count({ where: { id } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('O caso informado não existe em nosso banco de dados.'),
  ],
};

export default casoMiddleware;
