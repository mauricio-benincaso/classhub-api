import { check } from 'express-validator';

import { Course } from '../models';

const courseMiddleware = {
  storeRules: [
    check('title')
      .exists()
      .isString()
      .withMessage('Insira um título válido')
      .isLength({ min: 4, max: 255 })
      .withMessage('Insira um título válido entre 4 e 255 caracteres'),
    // check('description')
    //   .exists()
    //   .isString()
    //   .withMessage('Insira uma descrição válida')
    //   .isLength({ min: 4, max: 255 })
    //   .withMessage('Insira uma descrição válida entre 4 e 255 caracteres'),
  ],

  showRules: [
    check('id')
      .exists()
      .isString()
      .withMessage(
        'O identificador não pode ficar vazio, informe o identificador do curso',
      )
      .custom(id => {
        return new Promise((resolve, reject) => {
          Course.count({ where: { id } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('O curso informado não existe em nosso banco de dados.'),
  ],

  destroyRules: [
    check('id')
      .custom(id => {
        return new Promise((resolve, reject) => {
          Course.count({ where: { id } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('O curso informado não existe em nosso banco de dados.'),
  ],

  updateRules: [
    check('title')
      .exists()
      .isString()
      .withMessage('Insira um título válido')
      .isLength({ min: 4, max: 255 })
      .withMessage('Insira um título válido entre 4 e 255 caracteres'),
    check('id')
      .custom(id => {
        return new Promise((resolve, reject) => {
          Course.count({ where: { id } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('O curso não existe em nosso banco de dados.'),
  ],
};

export default courseMiddleware;
