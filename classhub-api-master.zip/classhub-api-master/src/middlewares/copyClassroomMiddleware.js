import { check } from 'express-validator';
import { Classroom, Course, User } from '../models';

const copyClassroomMiddleware = {
  storeRules: [
    check('course_id')
      .exists()
      .custom(course_id => {
        return new Promise((resolve, reject) => {
          const course = Course.findOne({ where: { id: course_id } });
          if (course) {
            resolve();
          } else {
            reject();
          }
        });
      })
      .withMessage('Informe um ID de curso válido'),
  ],
};

export default copyClassroomMiddleware;
