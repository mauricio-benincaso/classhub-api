import { check } from 'express-validator';

const authRequestRecoverCodeMiddleware = {
  storeRules: [
    check('email')
      .exists()
      .withMessage('Informe o seu email.')
      .isEmail()
      .withMessage('Informe um email válido'),
  ],
};

export default authRequestRecoverCodeMiddleware;
