import { AppError } from '../errors';
import { JwtHelper } from '../helpers';
import { Classroom, Role, User } from '../models';

export default async (request, response, next) => {
  const {
    headers: { authorization },
    query: { twilioTokenCode },
    params: { id },
  } = request;

  const messages = {
    error: 'Você não tem permissão para acessar este recurso.',
  };

  if (authorization || twilioTokenCode) {
    if (authorization) {
      const [, token] = authorization.split(' ');
      let decodedToken;
      try {
        decodedToken = JwtHelper.verify(token);
      } catch (e) {
        console.log(e);
        throw new AppError(messages.error, null, 401);
      }

      try {
        const user = await User.findOne({
          where: { id: decodedToken.id },
          include: { model: Role, as: 'roles' },
        });

        request.user_id = decodedToken.id;

        if (user) {
          request.sequelize = { user };

          if (user.status == false) {
            throw new AppError(messages.error, null, 401);
          }

          return next();
        } else {
          throw new AppError(messages.error, null, 401);
        }
      } catch (e) {
        console.log(e);
        throw new AppError(messages.error, null, 401);
      }
    } else if (twilioTokenCode) {
      // const [, userFromToken] = twilioTokenCode.split('');
      let decodedTwilioCode;
      try {
        decodedTwilioCode = JwtHelper.decode(twilioTokenCode);
      } catch (e) {
        console.log(e);
        throw new AppError(messages.error, null, 401);
      }

      const validateRules = ['jti', 'grants', 'iat', 'exp', 'iss', 'sub'];

      const tokenHasKeys = validateRules.every(
        rule => Object.keys(decodedTwilioCode).indexOf(rule) > -1,
      );

      const room = decodedTwilioCode.grants.video.room;

      let foundClassroom;
      try {
        foundClassroom = await Classroom.findOne({
          where: { id, hash: room },
        });
      } catch (e) {
        console.log(e);
        throw new AppError(messages.error, null, 401);
      }

      if (!foundClassroom) {
        throw new AppError(messages.error, null, 401);
      }
      next();
    }
  } else {
    throw new AppError(messages.error, null, 401);
  }
};
