import { AppError } from '../errors';
import { JwtHelper } from '../helpers';
import { Role, User } from '../models';

export default async (request, response, next) => {
  const {
    headers: { authorization },
  } = request;

  const messages = {
    error: 'Você não tem permissão para acessar este recurso',
  };

  if (authorization) {
    const [, token] = authorization.split(' ');

    let decodedToken;

    try {
      decodedToken = JwtHelper.verify(token);
    } catch (e) {
      console.log(e);
      throw new AppError(messages.error, null, 401);
    }

    try {
      const user = await User.findOne({
        where: { id: decodedToken.id },
        include: { model: Role, as: 'roles' },
      });

      request.user_id = decodedToken.id;

      if (user) {
        request.sequelize = { user };

        if (user.status == false) {
          throw new AppError(messages.error, null, 401);
        }

        return next();
      } else {
        throw new AppError(messages.error, null, 401);
      }
    } catch (e) {
      console.log(e);
      throw new AppError(messages.error, null, 401);
    }
  } else {
    throw new AppError(messages.error, null, 401);
  }
};
