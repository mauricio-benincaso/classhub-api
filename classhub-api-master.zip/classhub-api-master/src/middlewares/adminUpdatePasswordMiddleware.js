import { checkSchema } from 'express-validator';

const adminUpdateUserPasswordMiddleware = {
  updateRules: checkSchema({
    password: {
      in: ['body'],
      exists: { errorMessage: 'Informe a sua senha' },
      isStrongPassword: {
        errorMessage:
          'A senha informada não atende todos os requisitos.',
        options: {
          minLength: 8,
          maxLength: 32,
          minNumbers: 1,
          minLowercase: 1,
          minUppercase: 1,
          minSymbols: 1,
          minUppercase: 1,
        },
      },
      trim: true,
    },
    password_confirmation: {
      in: ['body'],
      exists: { errorMessage: 'Informe a sua confirmação de senha' },
      trim: true,
      custom: {
        options: (value, { req }) => {
          return new Promise((resolve, reject) => {
            const {
              body: { password },
            } = req;

            if (value !== password) {
              reject(new Error('As senhas informadas não coincidem'));
            } else {
              resolve();
            }
          });
        },
      },
    },
  }),
};

export default adminUpdateUserPasswordMiddleware;
