import { check } from 'express-validator';

const authForgotPasswordMiddleware = {
  storeRules: [
    check('email')
      .exists()
      .withMessage('Informe seu email para recuperação')
      .isEmail()
      .withMessage('Informe um email válido'),
  ],
};

export default authForgotPasswordMiddleware;
