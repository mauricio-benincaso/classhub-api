import { check } from 'express-validator';

const twilioTokenMiddleware = {
  storeRules: [
    check('name')
      .exists()
      .withMessage('Informe o seu nome para prosseguir.')
      .isString()
      .isLength({ min: 5, max: 80 })
      .withMessage('Informe o seu nome completo para prosseguir')
      .toUpperCase(),
    // check('cpf')
    //   .exists()
    //   .withMessage('Informe o seu CPF para prosseguir.')
    //   .isString()
    //   .isLength()
    //   .isLength({ min: 11, max: 11 })
    //   .withMessage('Informe um CPF válido para prosseguir.'),
  ],
};

export default twilioTokenMiddleware;
