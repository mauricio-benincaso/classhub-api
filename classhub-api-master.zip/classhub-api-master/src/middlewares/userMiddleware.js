import { response } from 'express';
import { check, param, checkSchema, body } from 'express-validator';
import { AppError } from '../errors';

import { Role, User } from '../models';

const userMiddleware = {
  storeRules: [
    check('name')
      .exists()
      .isString()
      .withMessage('Insira um nome válido')
      .isLength({ min: 3, max: 255 })
      .withMessage('Insira um nome válido entre 3 e 255 caracteres'),
    check('email')
      .exists()
      .isEmail()
      .withMessage('Insira um email válido'),
    check('status').isBoolean(),
  ],

  updateRules: [
    check('id')
      .custom(async (id, { req }) => {
        return new Promise(async (resolve, reject) => {
          User.count({ where: { id } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('O usuário não existe em nosso banco de dados.'),
  ],

  destroyRules: [
    check('id')
      .custom(async (id, { req }) => {
        return new Promise(async (resolve, reject) => {
          User.count({ where: { id } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('O usuário não existe em nosso banco de dados.'),
  ],
};

export default userMiddleware;
