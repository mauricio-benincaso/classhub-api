import { check } from 'express-validator';

import { Caso, Task } from '../models';

const taskMiddleware = {
  storeRules: [
    check('name')
      .exists()
      .isString()
      .withMessage('Insira um título válido')
      .isLength({ min: 4, max: 255 })
      .withMessage('Insira um título válido entre 4 e 255 caracteres'),
    check('order')
      .exists()
      .isNumeric()
      .withMessage('Insira uma ordem válida'),
    check('description')
      .exists()
      .isString()
      .withMessage('Insira uma descrição válida'),
    check('objective')
      .exists()
      .withMessage('Insira um objetivo válido'),
    check('caso_id')
      .exists()
      .withMessage('Informe o identificador do caso.')
      .custom(casoId => {
        return new Promise((resolve, reject) => {
          Caso.count({ where: { id: casoId } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('O caso informado não existe em nosso banco de dados.'),
  ],

  destroyRules: [
    check('id')
      .custom(id => {
        return new Promise((resolve, reject) => {
          Task.count({ where: { id } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('A tarefa informada não existe em nosso banco de dados.')
      .custom(async (user_id, { req }) => {
        return new Promise(async (resolve, reject) => {
          if (req.user_id == user_id) {
            resolve();
          } else {
            reject();
          }
        });
      })
      .withMessage('Você não tem permissão para acessar esse conteúdo'),
  ],

  updateRules: [
    check('name')
      .exists()
      .isString()
      .withMessage('Insira um título válido')
      .isLength({ min: 4, max: 255 })
      .withMessage('Insira um título válido entre 4 e 255 caracteres'),
    check('description')
      .exists()
      .isString()
      .isLength({ min: 4 })
      .withMessage('Insira uma descrição válida'),
    check('objective')
      .exists()
      .withMessage('Insira um objetivo válido'),
    check('id')
      .custom(id => {
        return new Promise((resolve, reject) => {
          Task.count({ where: { id } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('O caso informado não existe em nosso banco de dados.'),
    // .custom(async (user_id, { req }) => {
    //   return new Promise(async (resolve, reject) => {
    //     if (req.user_id == user_id) {
    //       resolve();
    //     } else {
    //       reject();
    //     }
    //   });
    // })
    // .withMessage('Você não tem permissão para acessar esse conteúdo'),
  ],
};

export default taskMiddleware;
