import { check } from 'express-validator';

import { Caso, Sequence } from '../models';

const sequenceMiddleware = {
  storeRules: [
    check('name')
      .exists()
      .isString()
      .isLength({ min: 4 })
      .withMessage(
        'Insira um nome para a sequência válido, com no mínimo 4 (quatro) caracteres',
      ),
    check('caso_id')
      .exists()
      .withMessage(
        'O identificador do caso não pode ficar vazio, informe o identificador do caso não pode ficar',
      )
      .isNumeric()
      .withMessage('O identificador do caso deve ser um valor numerico')
      .custom(casoId => {
        return new Promise((resolve, reject) => {
          Caso.count({ where: { id: casoId } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('O caso informado não existe em nosso banco de dados.'),
  ],

  destroyRules: [
    check('id')
      .custom(id => {
        return new Promise((resolve, reject) => {
          Sequence.count({ where: { id } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('A sequência informada não existe em nosso banco de dados.'),
  ],

  updateRules: [
    check('name')
      .exists()
      .isString()
      .withMessage('Insira um nome válido')
      .isLength({ min: 4, max: 255 })
      .withMessage('Insira um nome válido entre 4 e 255 caracteres'),
    check('id')
      .custom(id => {
        return new Promise((resolve, reject) => {
          Sequence.count({ where: { id } })
            .then(quantity => {
              if (quantity > 0) {
                resolve();
              } else {
                reject();
              }
            })
            .catch(() => reject());
        });
      })
      .withMessage('A sequência informada não existe em nosso banco de dados.'),
  ],
};

export default sequenceMiddleware;
