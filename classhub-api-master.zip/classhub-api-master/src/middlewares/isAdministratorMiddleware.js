import { AppError } from '../errors';

const isAdministratorMiddleware = {
  check: async (request, response, next) => {
    const { sequelize } = request;

    const messages = {
      error: 'Você não tem permissão para acessar este recurso.',
    };

    if (sequelize.user.roles.label !== 'Administrador') {
      throw new AppError(messages.error, null, 401);
    }

    return next();
  },
};

export default isAdministratorMiddleware;
