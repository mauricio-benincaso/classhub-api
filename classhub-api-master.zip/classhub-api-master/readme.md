# ClassHub (API)

A server side from Classhub project for Cetrus company by SoftMakers. Made with Node, Express &amp; 💙.

<br>

## 📌 - Engines

Specific versions of engines, libraries, frameworks, plugins and other versioned tools.

- **Node**: v14.18.0
- **NPM**: 6.14.15
- **Yarn**: 1.22.5
- **Python**: 2.7.16

<br>

## ⚙️ - Install

- Create a database (*classhub_api* for exemple)

- Install dependencies:

	```bash
  yarn install
  ```

- Run database migrations and seeds

	```bash
	yarn sequelize db:migrate
	```

	```bash
	yarn sequelize db:seed:all
	```

- Create your .env file from .env.example

- Create your Google Service Account file from config/google-service-account.exemple.json

<br>

## ▶️ - Run

- Run script via yarn with nodemon

  ```bash
  yarn start
  ```

<br>

## 🚀 - Deploy

- Build app via yarn script

	```bash
	yarn build
	```

- Start/restart app with pm2

	```bash
	pm2 start dist/server.js --name classhub-api-hml
	```
