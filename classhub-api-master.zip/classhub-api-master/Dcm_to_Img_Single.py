# This program is written by Abubakr Shafique (abubakr.shafique@gmail.com)
import os
import cv2 as cv
import numpy as np
import pydicom as PDCM
import sys, getopt

# TODO: Melhorar o script

def Dicom_to_Image(Path):
    DCM_Img = PDCM.read_file(Path)

    rows = DCM_Img.get(0x00280010).value #Get number of rows from tag (0028, 0010)
    cols = DCM_Img.get(0x00280011).value #Get number of cols from tag (0028, 0011)

    Instance_Number = int(DCM_Img.get(0x00200013).value) #Get actual slice instance number from tag (0020, 0013)

    Window_Center = int(DCM_Img.get(0x00281050).value) #Get window center from tag (0028, 1050)
    Window_Width = int(DCM_Img.get(0x00281051).value) #Get window width from tag (0028, 1051)

    Window_Max = int(Window_Center + Window_Width / 2)
    Window_Min = int(Window_Center - Window_Width / 2)

    if (DCM_Img.get(0x00281052) is None):
        Rescale_Intercept = 0
    else:
        Rescale_Intercept = int(DCM_Img.get(0x00281052).value)

    if (DCM_Img.get(0x00281053) is None):
        Rescale_Slope = 1
    else:
        Rescale_Slope = int(DCM_Img.get(0x00281053).value)

    New_Img = np.zeros((rows, cols), np.uint8)
    Pixels = DCM_Img.pixel_array

    for i in range(0, rows):
        for j in range(0, cols):
            Pix_Val = Pixels[i][j]
            Rescale_Pix_Val = Pix_Val * Rescale_Slope + Rescale_Intercept

            if (Rescale_Pix_Val > Window_Max): #if intensity is greater than max window
                New_Img[i][j] = 255
            elif (Rescale_Pix_Val < Window_Min): #if intensity is less than min window
                New_Img[i][j] = 0
            else:
                New_Img[i][j] = int(((Rescale_Pix_Val - Window_Min) / (Window_Max - Window_Min)) * 255) #Normalize the intensities

    return New_Img, Instance_Number

def main(argv):
    outputPath = ''
    inputPath = ''
    fileName = ''
    try:
        opts, args = getopt.getopt(argv,"i:o:f:",["iPath=","oPath=","fName="])
        # print("TESTE", opts)
    except getopt.GetoptError:
        # print ('test.py -i <iPath> -o <oPath>')
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print ('test.py -i <iPath> -o <oPath>')
            sys.exit()
        elif opt in ("-i", "--iPath"):
            inputPath = arg
            print("print path:", opt)
        elif opt in ("-o", "--oPath"):
         outputPath = arg
        elif opt in ("-f", "--fName"):
         fileName = arg
    print ('Path file "', inputPath)
    print ('Out file "', outputPath)
    print ('File name "', fileName)

    Output_Image, Instance_Number = Dicom_to_Image(inputPath)

    if os.path.isdir(outputPath) is False:
        os.mkdir(outputPath)

    cv.imwrite(outputPath + '/' + fileName + '.jpg', Output_Image)

if __name__ == "__main__":
   print(sys.argv)
   main(sys.argv[1:])
